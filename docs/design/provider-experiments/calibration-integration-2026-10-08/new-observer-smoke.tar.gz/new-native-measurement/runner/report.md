# Resource calibration measurements

Experimental measurements; no production policy change.

| Case | Eligible for fitting | Charged Source | Charged Core | Wall on/off median seconds | Peak RSS on/off KiB |
| --- | --- | ---: | ---: | --- | --- |
| resource_width-width1 | True | 111611 | 11811 | 0.24 / 0.29 | 45580 / 45956 |

Each six-owner work vector, phase boundary RSS, median/min/max, observer overhead, failures, models, residuals and held-out coverage is in `summary.json`.

CPU summaries preserve GNU time's target measurements and separately report wrapper-inclusive child user/system/total CPU seconds from native-precision `RUSAGE_CHILDREN` deltas. The latter include GNU time and reaped descendants, exclude Python runner CPU, and measure no individual compiler phase. Raw cumulative before/after CPU readings and deltas are retained in each run. Older evidence without these fields stays missing.

Models use each case's maximum observed admission charge. Held-out cases remain excluded from fitting even when eligible. Charges include precharged capacity and are not machine instruction counts. The simple model uses source nodes; the enriched model uses named immutable graph features. A fitted model is provisional: its envelope is twice the sum of its fitted value and training-only positive residual cushion, with a finite cap. Rank or sample insufficiency prevents an allowance estimate.

- resolution: size rank-insufficient; complexity rank-insufficient.
- source-checking: size rank-insufficient; complexity rank-insufficient.
- module-linking: size rank-insufficient; complexity rank-insufficient.
- linked-interface: size rank-insufficient; complexity rank-insufficient.
- final-elaboration: size rank-insufficient; complexity rank-insufficient.
- independent-effect-core: size rank-insufficient; complexity rank-insufficient.

External time excludes builds; each observation has a fresh process.
GNU time target user/system CPU seconds and process peak RSS remain separate measurements; printed CPU precision may round short runs to zero.
Wrapper-inclusive child CPU uses serial RUSAGE_CHILDREN before/after deltas in seconds, retaining native platform precision without decimal rounding.
These child CPU deltas include GNU time and reaped target descendants, exclude Python runner CPU, and do not isolate individual compiler phases.
Child accounting requires descendants to be waited for; a killed wrapper can omit orphaned descendants after timeout. Failed runs remain evidence, not model inputs.
CPU is scheduled processor time, separate from wall duration, structural work units and allocation counts; threaded child CPU can exceed wall duration.
Boundary RSS is not a phase peak; process peak RSS is cumulative.
Phase wall sums can overlap with containing phases; do not sum them into pipeline time.
Missing or aborted work endpoints are absent, never zero.
Envelopes use each case maximum raw work, preserving fresh-process capacity variation.
GNU time wall and CPU values have centisecond resolution; phase timers have finer resolution.
Both observer modes retain feature-enabled budget override machinery.
Controls use the same executable and finite diagnostic allowance as observation-on.
Models exclude failed, uncontrolled and held-out cases from fitting.
Family growth must be reviewed before adopting any empirical envelope.
