type Option<A> =
None
| Some(A)

interface Keep<A> {
keep : A -> A
}

impl Keep<Int> {
keep value = value
}

impl Keep<Option<A>> where Keep<A> {
keep None = None
keep (Some(value)) = Some(keep value)
}

main : Unit -> Int
main () = {
let value : Option<Int> = Some(42)
let kept : Option<Int> = keep value
42
}
