type Option<A> =
None
| Some(A)

identity<A> : A -> A
identity value = value

probe : Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Int>>>>>>>>>>>>>>>> -> Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Int>>>>>>>>>>>>>>>>
probe value = identity value

main : Unit -> Int
main () = {
let value : Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Int>>>>>>>>>>>>>>>> = Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(42))))))))))))))))
let kept : Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Int>>>>>>>>>>>>>>>> = probe value
42
}
