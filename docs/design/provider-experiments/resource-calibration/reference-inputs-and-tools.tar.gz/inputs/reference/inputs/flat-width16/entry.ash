identity0 : Int -> Int
identity0 value = value

identity1 : Int -> Int
identity1 value = value

identity2 : Int -> Int
identity2 value = value

identity3 : Int -> Int
identity3 value = value

identity4 : Int -> Int
identity4 value = value

identity5 : Int -> Int
identity5 value = value

identity6 : Int -> Int
identity6 value = value

identity7 : Int -> Int
identity7 value = value

identity8 : Int -> Int
identity8 value = value

identity9 : Int -> Int
identity9 value = value

identity10 : Int -> Int
identity10 value = value

identity11 : Int -> Int
identity11 value = value

identity12 : Int -> Int
identity12 value = value

identity13 : Int -> Int
identity13 value = value

identity14 : Int -> Int
identity14 value = value

identity15 : Int -> Int
identity15 value = value

main : Unit -> Int
main () = {
let ignored0 = identity0 42
let ignored1 = identity1 42
let ignored2 = identity2 42
let ignored3 = identity3 42
let ignored4 = identity4 42
let ignored5 = identity5 42
let ignored6 = identity6 42
let ignored7 = identity7 42
let ignored8 = identity8 42
let ignored9 = identity9 42
let ignored10 = identity10 42
let ignored11 = identity11 42
let ignored12 = identity12 42
let ignored13 = identity13 42
let ignored14 = identity14 42
let ignored15 = identity15 42
42
}
