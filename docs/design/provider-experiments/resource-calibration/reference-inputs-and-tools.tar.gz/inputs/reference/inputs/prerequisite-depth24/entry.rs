enum Option<T> { None, Some(T) }
use self::Option::{None, Some};

trait Keep: Sized {
    fn keep(value: Self) -> Self;
}

impl Keep for i64 {
    fn keep(value: Self) -> Self { value }
}

impl<T: Keep> Keep for Option<T> {
    fn keep(value: Self) -> Self {
        match value {
            None => None,
            Some(inner) => Some(T::keep(inner)),
        }
    }
}

pub fn run() -> i64 {
    let value: Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<i64>>>>>>>>>>>>>>>>>>>>>>>> = Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(Some(42i64))))))))))))))))))))))));
    let _kept: Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<Option<i64>>>>>>>>>>>>>>>>>>>>>>>> = Keep::keep(value);
    42
}
