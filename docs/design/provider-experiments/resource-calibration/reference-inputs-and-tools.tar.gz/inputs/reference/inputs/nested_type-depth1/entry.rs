enum Option<T> { None, Some(T) }
use self::Option::{None, Some};

fn identity<T>(value: T) -> T { value }

fn probe(value: Option<i64>) -> Option<i64> { identity(value) }

pub fn run() -> i64 {
    let value: Option<i64> = Some(42i64);
    let _kept: Option<i64> = probe(value);
    42
}
