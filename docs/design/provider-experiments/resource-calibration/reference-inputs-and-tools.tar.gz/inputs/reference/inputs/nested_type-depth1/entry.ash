type Option<A> =
None
| Some(A)

identity<A> : A -> A
identity value = value

probe : Option<Int> -> Option<Int>
probe value = identity value

main : Unit -> Int
main () = {
let value : Option<Int> = Some(42)
let kept : Option<Int> = probe value
42
}
