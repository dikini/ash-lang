enum Option<T> { None, Some(T) }
use self::Option::{None, Some};

fn identity<T>(value: T) -> T { value }

fn probe(value: Option<Option<Option<Option<i64>>>>) -> Option<Option<Option<Option<i64>>>> { identity(value) }

pub fn run() -> i64 {
    let value: Option<Option<Option<Option<i64>>>> = Some(Some(Some(Some(42i64))));
    let _kept: Option<Option<Option<Option<i64>>>> = probe(value);
    42
}
