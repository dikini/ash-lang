#![allow(dead_code, unused_imports)]

#[path = "/tmp/ash-resource-reference-cases-20261008/inputs/flat-width0/entry.rs"]
mod case0;

#[path = "/tmp/ash-resource-reference-cases-20261008/inputs/flat-width16/entry.rs"]
mod case1;

#[path = "/tmp/ash-resource-reference-cases-20261008/inputs/flat-width64/entry.rs"]
mod case2;

#[path = "/tmp/ash-resource-reference-cases-20261008/inputs/flat-width128/entry.rs"]
mod case3;

#[path = "/tmp/ash-resource-reference-cases-20261008/inputs/nested_type-depth1/entry.rs"]
mod case4;

#[path = "/tmp/ash-resource-reference-cases-20261008/inputs/nested_type-depth4/entry.rs"]
mod case5;

#[path = "/tmp/ash-resource-reference-cases-20261008/inputs/nested_type-depth16/entry.rs"]
mod case6;

#[path = "/tmp/ash-resource-reference-cases-20261008/inputs/nested_type-depth24/entry.rs"]
mod case7;

#[path = "/tmp/ash-resource-reference-cases-20261008/inputs/nested_type-depth32/entry.rs"]
mod case8;

#[path = "/tmp/ash-resource-reference-cases-20261008/inputs/prerequisite-depth1/entry.rs"]
mod case9;

#[path = "/tmp/ash-resource-reference-cases-20261008/inputs/prerequisite-depth4/entry.rs"]
mod case10;

#[path = "/tmp/ash-resource-reference-cases-20261008/inputs/prerequisite-depth16/entry.rs"]
mod case11;

#[path = "/tmp/ash-resource-reference-cases-20261008/inputs/prerequisite-depth24/entry.rs"]
mod case12;

#[path = "/tmp/ash-resource-reference-cases-20261008/inputs/prerequisite-depth32/entry.rs"]
mod case13;

fn main() {
    assert_eq!(case0::run(), 42, "flat-width0");
    assert_eq!(case1::run(), 42, "flat-width16");
    assert_eq!(case2::run(), 42, "flat-width64");
    assert_eq!(case3::run(), 42, "flat-width128");
    assert_eq!(case4::run(), 42, "nested_type-depth1");
    assert_eq!(case5::run(), 42, "nested_type-depth4");
    assert_eq!(case6::run(), 42, "nested_type-depth16");
    assert_eq!(case7::run(), 42, "nested_type-depth24");
    assert_eq!(case8::run(), 42, "nested_type-depth32");
    assert_eq!(case9::run(), 42, "prerequisite-depth1");
    assert_eq!(case10::run(), 42, "prerequisite-depth4");
    assert_eq!(case11::run(), 42, "prerequisite-depth16");
    assert_eq!(case12::run(), 42, "prerequisite-depth24");
    assert_eq!(case13::run(), 42, "prerequisite-depth32");
}
