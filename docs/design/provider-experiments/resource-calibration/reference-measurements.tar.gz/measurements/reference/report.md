# Ash/Rust frontend reference

Paired semantic structures; distinct compiler boundaries. No optimization or allowance change.

| Pair | Held out | Ash child CPU median s | Rust child CPU median s | Ash/Rust peak RSS KiB | Source predicted/actual | Core predicted/actual |
| --- | --- | ---: | ---: | --- | --- | --- |
| flat-width0 | False | 0.009198999999999985 | 0.03151100000000001 | 12388 / 58532 | n/a | n/a |
| flat-width16 | False | 0.010016999999999998 | 0.03348899999999999 | 12740 / 62484 | n/a | n/a |
| flat-width64 | False | 0.013559000000000015 | 0.03537500000000002 | 13156 / 63244 | n/a | n/a |
| flat-width128 | False | 0.027306000000000052 | 0.05006999999999995 | 14232 / 64012 | n/a | n/a |
| nested_type-depth1 | False | 0.00759399999999999 | 0.03265000000000001 | 12844 / 63292 | 673 / 673 | 748 / 748 |
| nested_type-depth4 | False | 0.007550000000000057 | 0.03764499999999993 | 13324 / 63244 | 1714 / 1714 | 1975 / 1975 |
| nested_type-depth16 | False | 0.010386000000000117 | 0.03719400000000006 | 13536 / 63592 | 8578 / 8578 | 11923 / 11923 |
| nested_type-depth24 | True | 0.018346000000000084 | 0.04616700000000007 | 13460 / 63856 | 15554 / 15554 | 23035 / 23035 |
| nested_type-depth32 | True | 0.014539999999999775 | 0.03576400000000024 | 13620 / 63692 | 24450 / 24450 | 37731 / 37731 |
| prerequisite-depth1 | False | 0.007998999999999978 | 0.04062300000000019 | 14540 / 69896 | 2536 / 2536 | 1266 / 1266 |
| prerequisite-depth4 | False | 0.012738999999999945 | 0.04128400000000021 | 14820 / 70020 | 3949 / 3949 | 3378 / 3378 |
| prerequisite-depth16 | False | 0.013303999999999983 | 0.04523800000000011 | 14920 / 70108 | 14101 / 14101 | 25956 / 25956 |
| prerequisite-depth24 | True | 0.01871299999999998 | 0.03728200000000004 | 15200 / 70412 | 24869 / 24869 | 53568 / 53568 |
| prerequisite-depth32 | True | 0.02391999999999994 | 0.036906000000000105 | 15568 / 70464 | 38837 / 38837 | 91228 / 91228 |

Median/min/max for both CPU measurements, wall and peak RSS, all six Ash ledgers, phase endpoints, source hashes, failures and raw logs are retained in JSON.

- Pairs match named semantic structures, not compiler work or pipeline stages.
- Budget means the frozen typical charged-cost prediction; work means observed charged cost. The diagnostic refusal limit is a separate finite ceiling.
- Ash timings include checking, independent Core validation and evaluation; Rust metadata emission includes its own analyses and encoding.
- Rust structural work counters are unavailable; none are estimated from CPU time.
- GNU time target CPU/peak RSS and high-precision wrapper-inclusive child CPU/wall are distinct measurements.
- RUSAGE_CHILDREN includes GNU time and waited-for target descendants, excludes Python runner CPU; timeout orphan accounting may be incomplete.
- Wall is monotonic elapsed seconds, CPU is scheduled processor seconds; native precision is platform dependent, values are not decimal-rounded.
- Wrapper wall and child CPU share the same process interval; compiler threads may consume more aggregate CPU seconds than elapsed seconds.
- The width-zero startup control is reported raw; no noisy subtraction of CPU/RSS is treated as measured semantic work.
- All four charge curves were frozen before dispatch; there is no fitting or coefficient update.
- Depths 24/32 are held-out extrapolations; prediction misses remain visible.
