"""Audit the two completed local calibration receipts, without running Ash."""
import datetime
import hashlib
import json
import math
from pathlib import Path
import statistics

BASE=Path('/tmp')
RESULT=Path.cwd()/'docs/design/provider-experiments/resource-calibration'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
out={'rounds':{},'cpu_precision_sqlite':[]}
for name in ['complete','cpu']:
    root=BASE/f'ash-resource-calibration-{name}-20261008'
    records=[json.loads(x) for x in (root/'runs.jsonl').read_text().splitlines()]
    summary=json.loads((root/'summary.json').read_text())
    manifest=json.loads((root/'run-manifest.json').read_text())
    frozen=json.loads((root/'frozen-training-models.json').read_text())
    assert len(records)==352 and len(summary['cases'])==44
    assert sum(not r['warmup'] for r in records)==264
    assert all(r['valid'] and not r['issues'] and r['exit_code']==0 for r in records)
    assert not summary['failures']
    assert sha(root/'resource_calibration.py')==manifest['runner_sha256']
    assert sha(root/'resource_calibration_cases.py')==manifest['manifest']['generator_sha256']
    for r in records:
        assert r['executable_sha256']==r['executable_sha256_after']==sha(Path(r['argv'][0]))
        assert r['inputs_before']==r['inputs_after']
        for key in ['stdout','stderr','time_record']:
            assert sha(Path(r[key]['path']))==r[key]['sha256'],(r['case'],key)
        if name=='cpu':
            cpu=r['wrapper_inclusive_child_cpu']
            assert all(math.isfinite(cpu[k]) and cpu[k]>=0 for k in ['user_seconds','system_seconds','total_seconds'])
            for k in ['user_seconds','system_seconds']:
                assert cpu[k]==cpu['after'][k]-cpu['before'][k]
            assert cpu['total_seconds']==cpu['user_seconds']+cpu['system_seconds']
    stamp=datetime.datetime.fromisoformat(frozen['created_utc'].replace('Z','+00:00'))
    assert all(datetime.datetime.fromisoformat(r['started_utc'].replace('Z','+00:00'))>stamp for r in records if r['held_out'])
    comparisons=0
    for phase,models in summary['models'].items():
        for kind,model in models.items():
            if 'coefficients' not in model: continue
            old=frozen['models'][phase][kind]
            assert model['coefficients']==old['coefficients']
            assert model['training_positive_residual_cushion']==old['training_positive_residual_cushion']
            assert model['nonnegative_fit_converged']
            assert model['training_coverage']==1
            comparisons+=1
    assert comparisons==24
    out['rounds'][name]={'case_count':44,'raw_count':len(records),'measured_count':264,'warmup_count':88,'failure_count':0,'frozen_model_pairs':comparisons,'frozen_before_all_heldout':True,'log_input_artifact_hashes_verified':True}
    if name=='cpu':
        for case in summary['cases']:
            if case['family']!='sqlite': continue
            raw=[r for r in records if r['case']==case['id'] and not r['warmup'] and r['mode']=='off']
            target_cpu=[r['external_time']['user_seconds']+r['external_time']['system_seconds'] for r in raw]
            on=[r for r in records if r['case']==case['id'] and not r['warmup'] and r['mode']=='on']
            fractions={phase:statistics.median(r['observation']['phases'][phase]['wall_ns']/r['observation']['phases']['pipeline']['wall_ns'] for r in on) for phase in ['source-checking','independent-effect-core','final-elaboration','evaluation']}
            out['cpu_precision_sqlite'].append({'case':case['id'],'process_off':case['process']['off'],'gnu_target_cpu_median_seconds':statistics.median(target_cpu),'phase_on_wall_ns':case['phase_wall_ns'],'phase_on_median_fraction_of_pipeline':fractions,'observer_overhead':case['observer_overhead'],'admission_charges':case['work']})
(RESULT/'analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS: 704 completed fresh-process receipts, all raw hashes and 48 frozen model pairs')
