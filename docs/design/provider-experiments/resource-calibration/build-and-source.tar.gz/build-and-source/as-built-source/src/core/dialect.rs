//! Closed assembly of the named pure Ash Core dialect.

use std::{
    collections::{HashMap, HashSet},
    error::Error,
    fmt,
    sync::{
        Arc, OnceLock,
        atomic::{AtomicU32, Ordering},
    },
};

fn empty_registry() -> &'static Arc<ResolvedRegistry> {
    static EMPTY: OnceLock<Arc<ResolvedRegistry>> = OnceLock::new();
    EMPTY.get_or_init(|| Arc::new(ResolvedRegistry::new(Vec::new(), Vec::new())))
}

fn empty_method_evidence() -> &'static Arc<MethodEvidenceCatalog> {
    static EMPTY: OnceLock<Arc<MethodEvidenceCatalog>> = OnceLock::new();
    EMPTY.get_or_init(|| Arc::new(MethodEvidenceCatalog::default()))
}

use super::{
    binding::BindingNode,
    data::{ConstructorNode, CoreMatchArm, CorePattern, CorePatternKind, MatchNode, TupleNode},
    function::{ApplicationNode, FunctionNode},
    literal::{BooleanNode, IntegerNode, UnitNode},
    primitive::{Primitive, PrimitiveNode},
    recursion::{RecursiveBindingMember, RecursiveBindingNode},
    type_ops::{
        LocalNominalScopeNode, NewtypeConversionDirection, NewtypeConversionNode,
        TypeAbstractionNode, TypeApplicationNode,
    },
    variable::{TypedBinder, VariableNode},
};
use crate::{
    integer::Integer,
    interface::{
        EvidenceNode, EvidenceNodeId, EvidenceSelection, ImplMethodId, InterfaceApplication,
        MethodId, RequirementId,
    },
    module::ModuleId,
    resolved::{BinderId, ResolvedRegistry},
    source::{GeneratedReason, Origin, Span, discard_origin_iteratively},
    types::{
        EffectRow, EffectRowVariable, IterativeTypeOwner, Kind, Type, TypeVariableId,
        TypeWorkBudget, charge_effect_row_cells, charge_kinded_type_parameters,
        clone_effect_row_with_budget, clone_kinded_type_parameters_with_budget,
        clone_type_with_budget, discard_type_iteratively, replace_type_iteratively,
        same_type_with_budget, substitute_type_variables_with,
    },
};

#[derive(Debug)]
#[cfg_attr(test, derive(Clone))]
pub(crate) struct MethodEvidenceMethod {
    pub(crate) id: MethodId,
    pub(crate) interface_parameters: Box<[TypeVariableId]>,
    pub(crate) inherited_parameters: Box<[crate::resolved::InheritedOwnerParameter]>,
    pub(crate) parameters: Box<[(TypeVariableId, Kind)]>,
    pub(crate) value_type: Type,
}

impl Drop for MethodEvidenceMethod {
    fn drop(&mut self) {
        discard_type_iteratively(std::mem::replace(&mut self.value_type, Type::Unit));
    }
}

#[derive(Debug)]
#[cfg_attr(test, derive(Clone))]
pub(crate) struct MethodEvidenceCatalog {
    lexical_owners: Vec<MethodEvidenceLexicalOwner>,
    methods: Vec<MethodEvidenceMethod>,
    implementation_owners: Vec<MethodEvidenceImplementationOwner>,
    domains: Vec<MethodEvidenceDomain>,
    occurrences: Vec<MethodEvidenceOccurrence>,
    final_occurrence_owners: Vec<crate::interface::FinalOccurrenceOwner>,
    adapters: Vec<MethodEvidenceAdapter>,
    concrete_sources: Vec<MethodEvidenceConcreteSource>,
    expectations: Vec<MethodEvidenceExpectation>,
}

#[derive(Debug)]
#[cfg_attr(test, derive(Clone))]
pub(crate) struct MethodEvidenceLexicalOwner {
    pub(crate) resource: Option<MethodEvidenceResourceOwner>,
    pub(crate) source_parameters: Box<[TypeVariableId]>,
    pub(crate) source: crate::interface::LexicalEvidenceId,
    pub(crate) method: MethodId,
    pub(crate) binder: BinderId,
    pub(crate) application: InterfaceApplication,
    pub(crate) captures: Box<[BinderId]>,
}

/// Lexical dictionary ownership is distinct from native resource policy.
#[derive(Debug, Eq, PartialEq)]
#[cfg_attr(test, derive(Clone))]
pub(crate) enum MethodEvidenceResourceOwner {
    Builtin(crate::resolved::ResourceAcquisition),
    Provider(ProviderEvidenceOwner),
}

#[derive(Debug, Eq, PartialEq)]
#[cfg_attr(test, derive(Clone))]
pub(crate) struct ProviderEvidenceOwner {
    pub(crate) definition: crate::resolved::ResourceDefinitionId,
    pub(crate) family: crate::types::NominalTypeId,
    pub(crate) identity: TypeVariableId,
    pub(crate) arguments: Box<[crate::types::KindedArgument]>,
}

impl Drop for ProviderEvidenceOwner {
    fn drop(&mut self) {
        for argument in std::mem::take(&mut self.arguments).into_vec() {
            crate::types::discard_kinded_argument_iteratively(argument);
        }
    }
}

impl MethodEvidenceResourceOwner {
    pub(crate) fn builtin(&self) -> Option<crate::resolved::ResourceAcquisition> {
        match self {
            Self::Builtin(acquisition) => Some(*acquisition),
            Self::Provider(_) => None,
        }
    }
}

impl Default for MethodEvidenceCatalog {
    fn default() -> Self {
        Self::new(
            Vec::new(),
            Vec::new(),
            Vec::new(),
            Vec::new(),
            Vec::new(),
            Vec::new(),
            Vec::new(),
        )
    }
}

#[derive(Debug)]
#[cfg_attr(test, derive(Clone))]
pub(crate) struct MethodEvidenceImplementationOwner {
    pub(crate) implementation: ImplMethodId,
    pub(crate) binder: BinderId,
    pub(crate) head_type_parameter_count: usize,
    pub(crate) source_parameters: Box<[(TypeVariableId, Kind)]>,
    pub(crate) application: InterfaceApplication,
}

#[derive(Debug)]
#[cfg_attr(test, derive(Clone))]
pub(crate) struct MethodEvidenceDomain {
    pub(crate) source_parameters: Box<[(TypeVariableId, Kind)]>,
    pub(crate) owner: MethodEvidenceOwner,
    pub(crate) requirement: RequirementId,
    pub(crate) requirement_position: u32,
    pub(crate) method: MethodId,
    pub(crate) method_position: u32,
    pub(crate) application: InterfaceApplication,
}

#[derive(Debug)]
#[cfg_attr(test, derive(Clone))]
pub(crate) struct MethodEvidenceOccurrence {
    pub(crate) slot: usize,
    pub(crate) scope: Option<MethodEvidenceOwner>,
    pub(crate) scope_binder: Option<BinderId>,
    pub(crate) target_owner: Option<MethodEvidenceOwner>,
    pub(crate) target_requirement: Option<RequirementId>,
    pub(crate) checked_method: Option<MethodId>,
    pub(crate) checked_application: InterfaceApplication,
    pub(crate) method_arguments: Box<[Type]>,
    pub(crate) checked_value_type: Option<Type>,
    pub(crate) selection: EvidenceSelection,
}

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub(crate) enum MethodEvidenceOwner {
    Global(BinderId),
    Implementation(ImplMethodId),
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum MethodEvidenceExpectedRole {
    LexicalCaptureUse {
        owner: usize,
        ordinal: usize,
    },
    LexicalOwner {
        owner: usize,
    },
    LexicalUse {
        owner: usize,
        selection_node: EvidenceNodeId,
    },
    ImplementationOwner {
        owner: usize,
    },
    Domain {
        domain: usize,
    },
    Application {
        domain: usize,
        producer: usize,
    },
    Instantiation {
        producer: usize,
    },
    Adapter {
        adapter: usize,
    },
    AdapterEdge {
        adapter: usize,
        ordinal: usize,
    },
}

#[derive(Debug)]
#[cfg_attr(test, derive(Clone))]
pub(crate) struct MethodEvidenceAdapter {
    pub(crate) selection_node: EvidenceNodeId,
    pub(crate) implementation: ImplMethodId,
    pub(crate) binder: BinderId,
    pub(crate) source_parameters: Box<[TypeVariableId]>,
    pub(crate) head_arguments: Box<[Type]>,
    pub(crate) prerequisites: Box<[MethodEvidenceAdapterEdge]>,
}

#[derive(Debug)]
#[cfg_attr(test, derive(Clone))]
pub(crate) struct MethodEvidenceAdapterEdge {
    pub(crate) owner: MethodEvidenceOwner,
    pub(crate) requirement: RequirementId,
    pub(crate) method: MethodId,
    pub(crate) application: InterfaceApplication,
    pub(crate) interface_parameters: Box<[TypeVariableId]>,
    pub(crate) method_parameters: Box<[(TypeVariableId, Kind)]>,
    pub(crate) value_type: Type,
    pub(crate) producer: MethodEvidenceExpectedProducer,
}

#[derive(Debug)]
#[cfg_attr(test, derive(Clone))]
pub(crate) struct MethodEvidenceConcreteSource {
    pub(crate) occurrence: usize,
    pub(crate) selection_node: EvidenceNodeId,
    pub(crate) implementation: ImplMethodId,
    pub(crate) binder: BinderId,
    pub(crate) head_arguments: Box<[Type]>,
    pub(crate) prerequisites: Box<[MethodEvidenceConcretePrerequisite]>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct MethodEvidenceConcretePrerequisite {
    pub(crate) selection_node: EvidenceNodeId,
    pub(crate) method: MethodId,
    pub(crate) scope_position: Option<usize>,
}

impl Drop for MethodEvidenceConcreteSource {
    fn drop(&mut self) {
        for argument in std::mem::take(&mut self.head_arguments).into_vec() {
            discard_type_iteratively(argument);
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum MethodEvidenceExpectedProducer {
    Authenticated(usize),
    Monomorphic {
        selection_node: EvidenceNodeId,
        producer_scope_position: Option<usize>,
        producer: MethodEvidenceProducer,
    },
}

impl Drop for MethodEvidenceAdapter {
    fn drop(&mut self) {
        for argument in std::mem::take(&mut self.head_arguments).into_vec() {
            discard_type_iteratively(argument);
        }
        for mut edge in std::mem::take(&mut self.prerequisites).into_vec() {
            discard_type_iteratively(std::mem::replace(&mut edge.value_type, Type::Unit));
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub(crate) enum MethodEvidenceProducer {
    Lexical {
        source: crate::interface::LexicalEvidenceId,
    },
    Abstract {
        requirement: RequirementId,
    },
    Adapter {
        implementation: ImplMethodId,
    },
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct MethodEvidenceExpectation {
    pub(crate) occurrence: Option<usize>,
    pub(crate) method: MethodId,
    pub(crate) role: MethodEvidenceExpectedRole,
}

impl Drop for MethodEvidenceOccurrence {
    fn drop(&mut self) {
        for argument in std::mem::take(&mut self.method_arguments).into_vec() {
            discard_type_iteratively(argument);
        }
        if let Some(ty) = self.checked_value_type.take() {
            discard_type_iteratively(ty);
        }
    }
}

struct IterativeTypeMap(HashMap<TypeVariableId, Type>);

impl Drop for IterativeTypeMap {
    fn drop(&mut self) {
        for (_, ty) in self.0.drain() {
            discard_type_iteratively(ty);
        }
    }
}

struct IterativeArgumentBuffer(Vec<crate::types::KindedArgument>);
impl IterativeArgumentBuffer {
    fn into_boxed_slice(mut self) -> Box<[crate::types::KindedArgument]> {
        std::mem::take(&mut self.0).into_boxed_slice()
    }
}
impl Drop for IterativeArgumentBuffer {
    fn drop(&mut self) {
        for argument in self.0.drain(..) {
            crate::types::discard_kinded_argument_iteratively(argument);
        }
    }
}

impl MethodEvidenceCatalog {
    fn lookup_work(&self) -> Option<usize> {
        self.methods
            .len()
            .checked_add(self.lexical_owners.len())
            .and_then(|work| work.checked_add(self.implementation_owners.len()))
            .and_then(|work| work.checked_add(self.domains.len()))
            .and_then(|work| work.checked_add(self.occurrences.len()))
            .and_then(|work| work.checked_add(self.adapters.len()))
            .and_then(|work| work.checked_add(self.concrete_sources.len()))
            .and_then(|work| work.checked_add(self.expectations.len()))
    }

    pub(crate) const fn method_count(&self) -> usize {
        self.methods.len()
    }

    pub(crate) const fn occurrence_count(&self) -> usize {
        self.occurrences.len()
    }

    pub(crate) const fn implementation_owner_count(&self) -> usize {
        self.implementation_owners.len()
    }

    pub(crate) fn new(
        methods: Vec<MethodEvidenceMethod>,
        implementation_owners: Vec<MethodEvidenceImplementationOwner>,
        domains: Vec<MethodEvidenceDomain>,
        occurrences: Vec<MethodEvidenceOccurrence>,
        adapters: Vec<MethodEvidenceAdapter>,
        concrete_sources: Vec<MethodEvidenceConcreteSource>,
        expectations: Vec<MethodEvidenceExpectation>,
    ) -> Self {
        Self {
            lexical_owners: Vec::new(),
            methods,
            implementation_owners,
            domains,
            occurrences,
            final_occurrence_owners: Vec::new(),
            adapters,
            concrete_sources,
            expectations,
        }
    }

    pub(crate) fn implementation_owner(
        &self,
        implementation: ImplMethodId,
    ) -> Option<&MethodEvidenceImplementationOwner> {
        self.implementation_owners
            .binary_search_by_key(&implementation, |owner| owner.implementation)
            .ok()
            .and_then(|index| self.implementation_owners.get(index))
    }

    pub(crate) fn set_lexical_owners(&mut self, owners: Vec<MethodEvidenceLexicalOwner>) {
        self.lexical_owners = owners;
    }

    pub(crate) fn lexical_owners(&self) -> &[MethodEvidenceLexicalOwner] {
        &self.lexical_owners
    }

    pub(crate) fn lexical_owner(
        &self,
        source: crate::interface::LexicalEvidenceId,
        method: MethodId,
    ) -> Option<&MethodEvidenceLexicalOwner> {
        self.lexical_owners
            .iter()
            .find(|owner| owner.source == source && owner.method == method)
    }

    pub(crate) fn implementation_owners(&self) -> &[MethodEvidenceImplementationOwner] {
        &self.implementation_owners
    }

    pub(crate) fn methods(&self) -> &[MethodEvidenceMethod] {
        &self.methods
    }

    pub(crate) fn method(&self, id: MethodId) -> Option<&MethodEvidenceMethod> {
        self.methods
            .binary_search_by_key(&id, |method| method.id)
            .ok()
            .and_then(|index| self.methods.get(index))
    }

    pub(crate) fn domains(&self) -> &[MethodEvidenceDomain] {
        &self.domains
    }

    pub(crate) fn occurrence(&self, slot: usize) -> Option<&MethodEvidenceOccurrence> {
        self.occurrences
            .binary_search_by_key(&slot, |occurrence| occurrence.slot)
            .ok()
            .and_then(|index| self.occurrences.get(index))
    }

    pub(crate) fn occurrences(&self) -> &[MethodEvidenceOccurrence] {
        &self.occurrences
    }

    /// Attaches readonly allocation pins for the complete supplied fresh-key
    /// set. This checks storage coverage only: independent specialization
    /// validation must derive those keys from original occurrence certificates.
    pub(crate) fn attach_final_occurrence_owners(
        &mut self,
        owners: Vec<crate::interface::FinalOccurrenceOwner>,
        fresh_keys: &[usize],
        work: &mut TypeWorkBudget,
    ) -> Result<(), crate::core::ValidationError> {
        let invalid =
            || crate::core::ValidationError::new(crate::core::ValidationReason::Registry, None);
        let resource =
            || crate::core::ValidationError::new(crate::core::ValidationReason::Resource, None);
        if !self.final_occurrence_owners.is_empty() || owners.len() != fresh_keys.len() {
            return Err(invalid());
        }
        if owners.is_empty() {
            return Ok(());
        }
        work.charge(
            fresh_keys
                .len()
                .checked_mul(4)
                .and_then(|cells| cells.checked_add(self.occurrences.len()))
                .ok_or_else(resource)?,
        )
        .map_err(|()| resource())?;
        let mut coverage = HashMap::new();
        coverage
            .try_reserve(fresh_keys.len())
            .map_err(|_| resource())?;
        for key in fresh_keys {
            if coverage.insert(*key, 0u8).is_some() {
                return Err(invalid());
            }
        }
        for owner in &owners {
            let seen = coverage.get_mut(&owner.storage_id()).ok_or_else(invalid)?;
            if *seen != 0 {
                return Err(invalid());
            }
            *seen = 1;
        }
        for occurrence in &self.occurrences {
            if let Some(seen) = coverage.get_mut(&occurrence.slot) {
                if *seen != 1 {
                    return Err(invalid());
                }
                *seen = 3;
            }
        }
        if coverage.values().any(|seen| *seen != 3) {
            return Err(invalid());
        }
        self.final_occurrence_owners = owners;
        Ok(())
    }

    pub(crate) fn final_occurrence_owners(&self) -> &[crate::interface::FinalOccurrenceOwner] {
        &self.final_occurrence_owners
    }

    pub(crate) fn adapters(&self) -> &[MethodEvidenceAdapter] {
        &self.adapters
    }

    pub(crate) fn concrete_sources(&self) -> &[MethodEvidenceConcreteSource] {
        &self.concrete_sources
    }

    pub(crate) fn expectations(&self) -> &[MethodEvidenceExpectation] {
        &self.expectations
    }
}

/// Compare emitted rows with independently reconstructed imported facts. The
/// selection plans are immutable staged inputs: exact plan/root identity is
/// required in addition to every independently derived catalog row.
pub(crate) fn same_imported_method_evidence_catalog(
    left: &MethodEvidenceCatalog,
    right: &MethodEvidenceCatalog,
    work: &mut TypeWorkBudget,
) -> Result<bool, ()> {
    fn ids<T: PartialEq>(a: &[T], b: &[T], work: &mut TypeWorkBudget) -> Result<bool, ()> {
        work.charge(a.len())?;
        Ok(a.len() == b.len() && a.iter().zip(b).all(|(a, b)| a == b))
    }
    fn types(a: &[Type], b: &[Type], work: &mut TypeWorkBudget) -> Result<bool, ()> {
        work.charge(a.len())?;
        if a.len() != b.len() {
            return Ok(false);
        }
        for (a, b) in a.iter().zip(b) {
            if !same_type_with_budget(a, b, work)? {
                return Ok(false);
            }
        }
        Ok(true)
    }
    fn parameters(
        a: &[(TypeVariableId, Kind)],
        b: &[(TypeVariableId, Kind)],
        work: &mut TypeWorkBudget,
    ) -> Result<bool, ()> {
        work.charge(a.len())?;
        if a.len() != b.len() {
            return Ok(false);
        }
        for ((a, ak), (b, bk)) in a.iter().zip(b) {
            if a != b || !crate::types::same_kind_with_charge(ak, bk, || work.charge(1))? {
                return Ok(false);
            }
        }
        Ok(true)
    }
    fn app(
        a: &InterfaceApplication,
        b: &InterfaceApplication,
        work: &mut TypeWorkBudget,
    ) -> Result<bool, ()> {
        work.charge(1)?;
        if a.interface() != b.interface() {
            return Ok(false);
        }
        work.charge(a.arguments().len())?;
        if a.arguments().len() != b.arguments().len() {
            return Ok(false);
        }
        let type_work = work;
        for (left, right) in a.arguments().iter().zip(b.arguments()) {
            match (left, right) {
                (
                    crate::types::KindedArgument::TypeArg(left),
                    crate::types::KindedArgument::TypeArg(right),
                ) => {
                    if !same_type_with_budget(left, right, type_work)? {
                        return Ok(false);
                    }
                }
                _ => {
                    if !crate::types::same_kinded_argument_with_budget(left, right, type_work)? {
                        return Ok(false);
                    }
                }
            }
        }
        Ok(true)
    }
    work.charge(
        left.lookup_work()
            .ok_or(())?
            .checked_add(right.lookup_work().ok_or(())?)
            .ok_or(())?,
    )?;
    if !left.lexical_owners.is_empty()
        || !right.lexical_owners.is_empty()
        || left.methods.len() != right.methods.len()
        || left.implementation_owners.len() != right.implementation_owners.len()
        || left.domains.len() != right.domains.len()
        || left.occurrences.len() != right.occurrences.len()
        || left.adapters.len() != right.adapters.len()
        || left.concrete_sources.len() != right.concrete_sources.len()
        || left.expectations.len() != right.expectations.len()
    {
        return Ok(false);
    }
    for (a, b) in left.methods.iter().zip(&right.methods) {
        work.charge(
            a.inherited_parameters
                .len()
                .saturating_add(b.inherited_parameters.len()),
        )?;
        if a.id != b.id
            || a.inherited_parameters != b.inherited_parameters
            || !ids(&a.interface_parameters, &b.interface_parameters, work)?
            || !parameters(&a.parameters, &b.parameters, work)?
            || !same_type_with_budget(&a.value_type, &b.value_type, work)?
        {
            return Ok(false);
        }
    }
    for (a, b) in left
        .implementation_owners
        .iter()
        .zip(&right.implementation_owners)
    {
        if a.implementation != b.implementation
            || a.binder != b.binder
            || a.head_type_parameter_count != b.head_type_parameter_count
            || !parameters(&a.source_parameters, &b.source_parameters, work)?
            || !app(&a.application, &b.application, work)?
        {
            return Ok(false);
        }
    }
    for (a, b) in left.domains.iter().zip(&right.domains) {
        if !parameters(&a.source_parameters, &b.source_parameters, work)?
            || a.owner != b.owner
            || a.requirement != b.requirement
            || a.requirement_position != b.requirement_position
            || a.method != b.method
            || a.method_position != b.method_position
            || !app(&a.application, &b.application, work)?
        {
            return Ok(false);
        }
    }
    for (a, b) in left.occurrences.iter().zip(&right.occurrences) {
        if a.slot != b.slot
            || a.scope != b.scope
            || a.scope_binder != b.scope_binder
            || a.target_owner != b.target_owner
            || a.target_requirement != b.target_requirement
            || a.checked_method != b.checked_method
            || !app(&a.checked_application, &b.checked_application, work)?
            || !types(&a.method_arguments, &b.method_arguments, work)?
            || a.selection != b.selection
        {
            return Ok(false);
        }
        match (&a.checked_value_type, &b.checked_value_type) {
            (None, None) => {}
            (Some(a), Some(b)) if same_type_with_budget(a, b, work)? => {}
            _ => return Ok(false),
        }
    }
    for (a, b) in left.adapters.iter().zip(&right.adapters) {
        if a.selection_node != b.selection_node
            || a.implementation != b.implementation
            || a.binder != b.binder
            || !ids(&a.source_parameters, &b.source_parameters, work)?
            || !types(&a.head_arguments, &b.head_arguments, work)?
            || a.prerequisites.len() != b.prerequisites.len()
        {
            return Ok(false);
        }
        work.charge(a.prerequisites.len())?;
        for (a, b) in a.prerequisites.iter().zip(&b.prerequisites) {
            if a.owner != b.owner
                || a.requirement != b.requirement
                || a.method != b.method
                || a.producer != b.producer
                || !app(&a.application, &b.application, work)?
                || !ids(&a.interface_parameters, &b.interface_parameters, work)?
                || !parameters(&a.method_parameters, &b.method_parameters, work)?
                || !same_type_with_budget(&a.value_type, &b.value_type, work)?
            {
                return Ok(false);
            }
        }
    }
    for (a, b) in left.concrete_sources.iter().zip(&right.concrete_sources) {
        if a.occurrence != b.occurrence
            || a.selection_node != b.selection_node
            || a.implementation != b.implementation
            || a.binder != b.binder
            || !types(&a.head_arguments, &b.head_arguments, work)?
            || !ids(&a.prerequisites, &b.prerequisites, work)?
        {
            return Ok(false);
        }
    }
    ids(&left.expectations, &right.expectations, work)
}

#[cfg(test)]
#[derive(Clone, Copy, Debug)]
pub(crate) enum MethodEvidenceCatalogMutationForTest {
    WrongRequirementPosition,
    WrongMethodPosition,
    WrongDomainSourceParameter,
    WrongDomainParameterKind,
    WrongDomainParameterOrder,
    WrongMethodScheme,
    WrongCanonicalMethodParameter,
    WrongAdapterBinder,
    WrongAdapterSourceParameter,
    WrongOwnerSourceParameter,
    WrongHeadCount,
    WrongHeadArgument,
    MissingPrerequisite,
    WrongPrerequisiteProducer,
    MissingExpectation,
    ExtraExpectation,
}

#[cfg(test)]
impl MethodEvidenceCatalog {
    pub(super) fn methods_mut_for_core_test(&mut self) -> &mut [MethodEvidenceMethod] {
        &mut self.methods
    }

    pub(super) fn implementation_owners_mut_for_core_test(
        &mut self,
    ) -> &mut [MethodEvidenceImplementationOwner] {
        &mut self.implementation_owners
    }

    pub(super) fn domains_mut_for_core_test(&mut self) -> &mut [MethodEvidenceDomain] {
        &mut self.domains
    }

    pub(super) fn occurrences_mut_for_core_test(&mut self) -> &mut [MethodEvidenceOccurrence] {
        &mut self.occurrences
    }

    pub(super) fn adapters_mut_for_core_test(&mut self) -> &mut [MethodEvidenceAdapter] {
        &mut self.adapters
    }

    pub(super) fn concrete_sources_mut_for_core_test(
        &mut self,
    ) -> &mut [MethodEvidenceConcreteSource] {
        &mut self.concrete_sources
    }

    pub(crate) fn corrupt_for_core_test(
        &mut self,
        mutation: MethodEvidenceCatalogMutationForTest,
    ) -> bool {
        match mutation {
            MethodEvidenceCatalogMutationForTest::WrongRequirementPosition => {
                self.domains.first_mut().is_some_and(|domain| {
                    domain.requirement_position = domain.requirement_position.saturating_add(1);
                    true
                })
            }
            MethodEvidenceCatalogMutationForTest::WrongDomainSourceParameter => self
                .domains
                .iter_mut()
                .find_map(|domain| domain.source_parameters.first_mut())
                .is_some_and(|parameter| {
                    parameter.0 = TypeVariableId::generated(u32::MAX);
                    true
                }),
            MethodEvidenceCatalogMutationForTest::WrongDomainParameterKind => self
                .domains
                .iter_mut()
                .find_map(|domain| domain.source_parameters.first_mut())
                .is_some_and(|parameter| {
                    parameter.1 = Kind::EffectRow;
                    true
                }),
            MethodEvidenceCatalogMutationForTest::WrongDomainParameterOrder => self
                .domains
                .iter_mut()
                .find(|domain| domain.source_parameters.len() > 1)
                .is_some_and(|domain| {
                    domain.source_parameters.swap(0, 1);
                    true
                }),
            MethodEvidenceCatalogMutationForTest::WrongMethodPosition => {
                self.domains.first_mut().is_some_and(|domain| {
                    domain.method_position = domain.method_position.saturating_add(1);
                    true
                })
            }
            MethodEvidenceCatalogMutationForTest::WrongMethodScheme => {
                self.methods.first_mut().is_some_and(|method| {
                    discard_type_iteratively(std::mem::replace(&mut method.value_type, Type::Bool));
                    true
                })
            }
            MethodEvidenceCatalogMutationForTest::WrongCanonicalMethodParameter => self
                .methods
                .iter_mut()
                .find_map(|method| method.parameters.first_mut())
                .is_some_and(|parameter| {
                    parameter.0 = TypeVariableId::generated(u32::MAX);
                    true
                }),
            MethodEvidenceCatalogMutationForTest::WrongAdapterBinder => {
                let Some(replacement) = self
                    .implementation_owners
                    .iter()
                    .map(|owner| owner.binder)
                    .find(|binder| {
                        self.adapters
                            .first()
                            .is_some_and(|adapter| adapter.binder != *binder)
                    })
                else {
                    return false;
                };
                self.adapters[0].binder = replacement;
                true
            }
            MethodEvidenceCatalogMutationForTest::WrongAdapterSourceParameter => self
                .adapters
                .iter_mut()
                .find(|adapter| {
                    !adapter.source_parameters.is_empty() && adapter.prerequisites.is_empty()
                })
                .is_some_and(|adapter| {
                    adapter.source_parameters[0] = TypeVariableId::generated(u32::MAX);
                    true
                }),
            MethodEvidenceCatalogMutationForTest::WrongOwnerSourceParameter => {
                let Some(implementation) = self
                    .adapters
                    .iter()
                    .find(|adapter| {
                        !adapter.source_parameters.is_empty() && adapter.prerequisites.is_empty()
                    })
                    .map(|adapter| adapter.implementation)
                else {
                    return false;
                };
                self.implementation_owners
                    .iter_mut()
                    .find(|owner| owner.implementation == implementation)
                    .is_some_and(|owner| {
                        owner.source_parameters[0].0 = TypeVariableId::generated(u32::MAX);
                        true
                    })
            }
            MethodEvidenceCatalogMutationForTest::WrongHeadCount => {
                let Some(implementation) = self
                    .adapters
                    .iter()
                    .find(|adapter| adapter.prerequisites.is_empty())
                    .map(|adapter| adapter.implementation)
                else {
                    return false;
                };
                self.implementation_owners
                    .iter_mut()
                    .find(|owner| owner.implementation == implementation)
                    .is_some_and(|owner| {
                        owner.head_type_parameter_count =
                            owner.head_type_parameter_count.saturating_add(1);
                        true
                    })
            }
            MethodEvidenceCatalogMutationForTest::WrongHeadArgument => self
                .adapters
                .iter_mut()
                .find_map(|adapter| adapter.head_arguments.first_mut())
                .is_some_and(|argument| {
                    discard_type_iteratively(std::mem::replace(argument, Type::Bool));
                    true
                }),
            MethodEvidenceCatalogMutationForTest::MissingPrerequisite => self
                .adapters
                .iter_mut()
                .find(|adapter| !adapter.prerequisites.is_empty())
                .is_some_and(|adapter| {
                    let mut prerequisites = std::mem::take(&mut adapter.prerequisites).into_vec();
                    let mut removed = prerequisites.pop().expect("non-empty prerequisites");
                    discard_type_iteratively(std::mem::replace(
                        &mut removed.value_type,
                        Type::Unit,
                    ));
                    adapter.prerequisites = prerequisites.into_boxed_slice();
                    true
                }),
            MethodEvidenceCatalogMutationForTest::WrongPrerequisiteProducer => self
                .adapters
                .iter_mut()
                .find_map(|adapter| adapter.prerequisites.first_mut())
                .is_some_and(|edge| {
                    edge.producer = MethodEvidenceExpectedProducer::Authenticated(usize::MAX);
                    true
                }),
            MethodEvidenceCatalogMutationForTest::MissingExpectation => {
                self.expectations.pop().is_some()
            }
            MethodEvidenceCatalogMutationForTest::ExtraExpectation => {
                let Some(extra) = self.expectations.first().copied() else {
                    return false;
                };
                self.expectations.push(extra);
                true
            }
        }
    }
}

pub(super) fn method_evidence_anchor_matches_expectation(
    catalog: &MethodEvidenceCatalog,
    expected: &MethodEvidenceExpectation,
    owner: Option<MethodEvidenceOwner>,
    requirement: Option<RequirementId>,
    role: MethodEvidenceAnchorRole,
    application: &InterfaceApplication,
    type_work: &mut TypeWorkBudget,
) -> Result<bool, ()> {
    type_work.charge(catalog.lookup_work().ok_or(())?)?;
    type_work.charge(1)?;
    match (expected.role, role) {
        (
            MethodEvidenceExpectedRole::LexicalCaptureUse { owner, ordinal },
            MethodEvidenceAnchorRole::LexicalCaptureUse {
                owner: actual_owner,
                ordinal: actual_ordinal,
            },
        ) => {
            let Some(expected) = catalog.lexical_owners.get(owner) else {
                return Ok(false);
            };
            Ok(owner == actual_owner
                && ordinal == actual_ordinal
                && ordinal < expected.captures.len()
                && requirement.is_none()
                && same_interface_application_with_budget(
                    &expected.application,
                    application,
                    type_work,
                )?)
        }
        (
            MethodEvidenceExpectedRole::LexicalOwner { owner: index },
            MethodEvidenceAnchorRole::LexicalOwner { source, binder },
        ) => {
            let Some(expected) = catalog.lexical_owners.get(index) else {
                return Ok(false);
            };
            Ok(expected.source == source
                && expected.binder == binder
                && requirement.is_none()
                && same_interface_application_with_budget(
                    &expected.application,
                    application,
                    type_work,
                )?)
        }
        (
            MethodEvidenceExpectedRole::LexicalUse {
                owner: index,
                selection_node,
            },
            MethodEvidenceAnchorRole::LexicalUse {
                source,
                binder,
                selection_node: actual,
            },
        ) => {
            let Some(expected_owner) = catalog.lexical_owners.get(index) else {
                return Ok(false);
            };
            let Some(occurrence) = expected
                .occurrence
                .and_then(|slot| catalog.occurrence(slot))
            else {
                return Ok(false);
            };
            Ok(expected_owner.source == source
                && expected_owner.binder == binder
                && selection_node == actual
                && matches!(occurrence.selection.node(selection_node), Some(EvidenceNode::Lexical { source: selected, methods }) if selected == source && methods.contains(&expected.method))
                && same_interface_application_with_budget(
                    &expected_owner.application,
                    application,
                    type_work,
                )?)
        }
        (
            MethodEvidenceExpectedRole::ImplementationOwner {
                owner: expected_owner,
            },
            MethodEvidenceAnchorRole::ImplementationOwner {
                implementation,
                binder,
            },
        ) => {
            let Some(expected) = catalog.implementation_owners.get(expected_owner) else {
                return Ok(false);
            };
            Ok(expected.implementation == implementation
                && expected.binder == binder
                && same_interface_application_with_budget(
                    &expected.application,
                    application,
                    type_work,
                )?
                && Some(MethodEvidenceOwner::Implementation(implementation)) == owner
                && requirement.is_none())
        }
        (
            MethodEvidenceExpectedRole::Domain { domain },
            MethodEvidenceAnchorRole::Domain { .. },
        ) => {
            let Some(domain) = catalog.domains().get(domain) else {
                return Ok(false);
            };
            Ok(Some(domain.owner) == owner
                && Some(domain.requirement) == requirement
                && domain.method == expected.method
                && same_interface_application_with_budget(
                    &domain.application,
                    application,
                    type_work,
                )?)
        }
        (
            MethodEvidenceExpectedRole::Application { domain, producer },
            MethodEvidenceAnchorRole::Application { producer: actual },
        ) => {
            let Some(domain) = catalog.domains().get(domain) else {
                return Ok(false);
            };
            let Some(occurrence) = expected
                .occurrence
                .and_then(|slot| catalog.occurrence(slot))
            else {
                return Ok(false);
            };
            let target = Some(domain.owner) == owner
                && Some(domain.requirement) == requirement
                && domain.method == expected.method
                && occurrence.target_owner == owner
                && occurrence.target_requirement == requirement
                && same_interface_application_with_budget(
                    &occurrence.checked_application,
                    application,
                    type_work,
                )?;
            let source = method_evidence_producer_matches(catalog, producer, actual);
            Ok(target && source)
        }
        (
            MethodEvidenceExpectedRole::Instantiation { producer },
            MethodEvidenceAnchorRole::Instantiation { binder },
        ) => {
            let Some(occurrence) = catalog.occurrence(expected.occurrence.unwrap_or(usize::MAX))
            else {
                return Ok(false);
            };
            let source_matches = match catalog
                .expectations()
                .get(producer)
                .map(|source| source.role)
            {
                Some(MethodEvidenceExpectedRole::Domain { domain }) => {
                    catalog.domains().get(domain).is_some_and(|domain| {
                        binder.is_some() && requirement == Some(domain.requirement)
                    })
                }
                Some(MethodEvidenceExpectedRole::Adapter { .. }) => {
                    binder.is_none() && requirement.is_none()
                }
                Some(MethodEvidenceExpectedRole::LexicalOwner { owner }) => {
                    catalog
                        .lexical_owners
                        .get(owner)
                        .is_some_and(|owner| binder == Some(owner.binder))
                        && requirement.is_none()
                }
                _ => false,
            };
            Ok(occurrence.scope == owner
                && occurrence.checked_method == Some(expected.method)
                && same_interface_application_with_budget(
                    &occurrence.checked_application,
                    application,
                    type_work,
                )?
                && source_matches)
        }
        (
            MethodEvidenceExpectedRole::Adapter { adapter },
            MethodEvidenceAnchorRole::Adapter {
                implementation,
                selection_node,
            },
        ) => {
            type_work.charge(1)?;
            let Some(expected) = catalog.adapters().get(adapter) else {
                return Ok(false);
            };
            Ok(expected.implementation == implementation
                && expected.selection_node == selection_node
                && method_evidence_adapter_interface_matches(
                    catalog,
                    expected,
                    application,
                    type_work,
                )?)
        }
        (
            MethodEvidenceExpectedRole::AdapterEdge { adapter, ordinal },
            MethodEvidenceAnchorRole::AdapterEdge {
                adapter: implementation,
                adapter_selection_node,
                ordinal: actual_ordinal,
                producer_selection_node,
                producer,
                ..
            },
        ) => {
            type_work.charge(2)?;
            let Some(adapter_row) = catalog.adapters().get(adapter) else {
                return Ok(false);
            };
            let Some(edge) = adapter_row.prerequisites.get(ordinal) else {
                return Ok(false);
            };
            Ok(adapter_row.implementation == implementation
                && adapter_row.selection_node == adapter_selection_node
                && ordinal == actual_ordinal
                && Some(edge.owner) == owner
                && Some(edge.requirement) == requirement
                && edge.method == expected.method
                && method_evidence_adapter_application_matches(
                    adapter_row,
                    &edge.application,
                    application,
                    type_work,
                )?
                && method_evidence_expected_producer_matches(
                    catalog,
                    expected.occurrence,
                    edge.producer,
                    producer_selection_node,
                    producer,
                    type_work,
                )?)
        }
        _ => Ok(false),
    }
}

fn method_evidence_adapter_interface_matches(
    catalog: &MethodEvidenceCatalog,
    adapter: &MethodEvidenceAdapter,
    actual: &InterfaceApplication,
    type_work: &mut TypeWorkBudget,
) -> Result<bool, ()> {
    let Some(owner) = catalog.implementation_owner(adapter.implementation) else {
        return Ok(false);
    };
    if adapter.head_arguments.len() != owner.head_type_parameter_count
        || owner.head_type_parameter_count > owner.source_parameters.len()
    {
        return Ok(false);
    }
    method_evidence_adapter_application_matches(adapter, &owner.application, actual, type_work)
}

fn method_evidence_adapter_application_matches(
    adapter: &MethodEvidenceAdapter,
    expected: &InterfaceApplication,
    actual: &InterfaceApplication,
    type_work: &mut TypeWorkBudget,
) -> Result<bool, ()> {
    type_work.charge(1)?;
    if adapter.head_arguments.len() > adapter.source_parameters.len() {
        return Ok(false);
    }
    let mut replacements = IterativeTypeMap(HashMap::new());
    type_work.charge(adapter.head_arguments.len())?;
    if replacements
        .0
        .try_reserve(adapter.head_arguments.len())
        .is_err()
    {
        return Err(());
    }
    for (parameter, argument) in adapter
        .source_parameters
        .iter()
        .zip(&adapter.head_arguments)
    {
        if let Some(displaced) = replacements
            .0
            .insert(*parameter, clone_type_with_budget(argument, type_work)?)
        {
            discard_type_iteratively(displaced);
            return Ok(false);
        }
    }
    if expected.interface() != actual.interface()
        || expected.arguments().len() != actual.arguments().len()
    {
        return Ok(false);
    }
    for (expected, actual) in expected.arguments().iter().zip(actual.arguments()) {
        if let (
            crate::types::KindedArgument::TypeArg(expected),
            crate::types::KindedArgument::TypeArg(actual),
        ) = (expected, actual)
        {
            let expected = IterativeTypeOwner::new(substitute_type_variables_with(
                expected,
                &replacements.0,
                |cells| type_work.charge(cells),
                || (),
            )?);
            if !same_type_with_budget(&expected, actual, type_work)? {
                return Ok(false);
            }
            continue;
        }
        let expected = crate::types::IterativeArgumentOwner::new(
            crate::types::map_kinded_argument_types_with_budget(
                expected,
                &mut |ty, budget: &mut TypeWorkBudget| {
                    substitute_type_variables_with(
                        ty,
                        &replacements.0,
                        |cells| budget.charge(cells),
                        || (),
                    )
                },
                type_work,
                &mut |_| (),
            )?,
        );
        if !crate::types::same_kinded_argument_with_budget(expected.as_ref(), actual, type_work)? {
            return Ok(false);
        }
    }
    Ok(true)
}

fn same_interface_application_with_budget(
    left: &InterfaceApplication,
    right: &InterfaceApplication,
    type_work: &mut TypeWorkBudget,
) -> Result<bool, ()> {
    type_work.charge(1)?;
    if left.interface() != right.interface() || left.arguments().len() != right.arguments().len() {
        return Ok(false);
    }
    for (left, right) in left.arguments().iter().zip(right.arguments()) {
        match (left, right) {
            (
                crate::types::KindedArgument::TypeArg(left),
                crate::types::KindedArgument::TypeArg(right),
            ) => {
                if !same_type_with_budget(left, right, type_work)? {
                    return Ok(false);
                }
            }
            _ => {
                if !crate::types::same_kinded_argument_with_budget(left, right, type_work)? {
                    return Ok(false);
                }
            }
        }
    }
    Ok(true)
}

fn method_evidence_expected_producer_matches(
    catalog: &MethodEvidenceCatalog,
    occurrence: Option<usize>,
    expected: MethodEvidenceExpectedProducer,
    actual_selection_node: EvidenceNodeId,
    actual: MethodEvidenceProducer,
    work: &mut TypeWorkBudget,
) -> Result<bool, ()> {
    work.charge(1)?;
    Ok(match expected {
        MethodEvidenceExpectedProducer::Authenticated(expectation) => {
            let Some(expected) = catalog.expectations().get(expectation) else {
                return Ok(false);
            };
            let exact_selection = match expected.role {
                MethodEvidenceExpectedRole::Adapter { adapter } => catalog
                    .adapters()
                    .get(adapter)
                    .is_some_and(|row| row.selection_node == actual_selection_node),
                MethodEvidenceExpectedRole::Domain { domain } => {
                    let selected = occurrence
                        .and_then(|slot| catalog.occurrence(slot))
                        .and_then(|row| row.selection.node(actual_selection_node));
                    match selected {
                        Some(EvidenceNode::Abstract {
                            requirement,
                            methods,
                        }) => {
                            work.charge(methods.len())?;
                            catalog.domains().get(domain).is_some_and(|row| {
                                row.requirement == requirement && methods.contains(&row.method)
                            })
                        }
                        _ => false,
                    }
                }
                MethodEvidenceExpectedRole::LexicalOwner { owner } => {
                    let selected = occurrence
                        .and_then(|slot| catalog.occurrence(slot))
                        .and_then(|row| row.selection.node(actual_selection_node));
                    match selected {
                        Some(EvidenceNode::Lexical { source, methods }) => {
                            work.charge(methods.len())?;
                            catalog.lexical_owners().get(owner).is_some_and(|row| {
                                row.source == source && methods.contains(&row.method)
                            })
                        }
                        _ => false,
                    }
                }
                _ => false,
            };
            exact_selection && method_evidence_producer_matches(catalog, expectation, actual)
        }
        MethodEvidenceExpectedProducer::Monomorphic {
            selection_node,
            producer_scope_position: _,
            producer,
        } => selection_node == actual_selection_node && producer == actual,
    })
}

pub(super) fn method_evidence_producer_matches(
    catalog: &MethodEvidenceCatalog,
    producer: usize,
    actual: MethodEvidenceProducer,
) -> bool {
    match (
        catalog
            .expectations()
            .get(producer)
            .map(|source| source.role),
        actual,
    ) {
        (
            Some(MethodEvidenceExpectedRole::LexicalOwner { owner }),
            MethodEvidenceProducer::Lexical { source },
        ) => catalog
            .lexical_owners
            .get(owner)
            .is_some_and(|owner| owner.source == source),
        (
            Some(MethodEvidenceExpectedRole::Domain { domain }),
            MethodEvidenceProducer::Abstract { requirement },
        ) => catalog
            .domains()
            .get(domain)
            .is_some_and(|domain| domain.requirement == requirement),
        (
            Some(MethodEvidenceExpectedRole::Adapter { adapter }),
            MethodEvidenceProducer::Adapter { implementation },
        ) => catalog
            .adapters()
            .get(adapter)
            .is_some_and(|adapter| adapter.implementation == implementation),
        _ => false,
    }
}

fn selection_contains_method(
    selection: &EvidenceSelection,
    method: MethodId,
    type_work: &mut TypeWorkBudget,
) -> Result<bool, ()> {
    selection_contains(selection, type_work, |node| match node {
        EvidenceNode::Abstract { methods, .. } | EvidenceNode::Lexical { methods, .. } => {
            methods.contains(&method)
        }
        EvidenceNode::Implementation { methods, .. } => {
            methods.iter().any(|candidate| candidate.method() == method)
        }
    })
}

fn selection_contains(
    selection: &EvidenceSelection,
    type_work: &mut TypeWorkBudget,
    mut predicate: impl FnMut(EvidenceNode<'_>) -> bool,
) -> Result<bool, ()> {
    type_work.charge(1)?;
    type_work.charge(selection.node_count().checked_mul(2).ok_or(())?)?;
    let mut pending = Vec::new();
    pending
        .try_reserve(selection.node_count())
        .map_err(|_| ())?;
    pending.push(selection.root());
    let mut visited = HashSet::<EvidenceNodeId>::new();
    visited
        .try_reserve(selection.node_count())
        .map_err(|_| ())?;
    while let Some(identity) = pending.pop() {
        type_work.charge(1)?;
        if !visited.insert(identity) {
            continue;
        }
        let Some(node) = selection.node(identity) else {
            return Ok(false);
        };
        let method_count = match node {
            EvidenceNode::Abstract { methods, .. } | EvidenceNode::Lexical { methods, .. } => {
                methods.len()
            }
            EvidenceNode::Implementation { methods, .. } => methods.len(),
        };
        type_work.charge(method_count)?;
        if predicate(node) {
            return Ok(true);
        }
        if let EvidenceNode::Implementation { prerequisites, .. } = node {
            type_work.charge(prerequisites.len())?;
            pending.try_reserve(prerequisites.len()).map_err(|_| ())?;
            pending.extend(prerequisites.iter().copied());
        }
    }
    Ok(false)
}

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub(crate) enum MethodEvidenceAnchorRole {
    LexicalCaptureUse {
        owner: usize,
        ordinal: usize,
    },
    LexicalOwner {
        source: crate::interface::LexicalEvidenceId,
        binder: BinderId,
    },
    LexicalUse {
        source: crate::interface::LexicalEvidenceId,
        binder: BinderId,
        selection_node: EvidenceNodeId,
    },
    ImplementationOwner {
        implementation: ImplMethodId,
        binder: BinderId,
    },
    Domain {
        binder: BinderId,
    },
    Application {
        producer: MethodEvidenceProducer,
    },
    Instantiation {
        binder: Option<BinderId>,
    },
    Adapter {
        implementation: ImplMethodId,
        selection_node: EvidenceNodeId,
    },
    AdapterEdge {
        adapter: ImplMethodId,
        adapter_selection_node: EvidenceNodeId,
        ordinal: usize,
        producer_node: NodeId,
        producer_selection_node: EvidenceNodeId,
        producer_binder: Option<BinderId>,
        producer: MethodEvidenceProducer,
    },
}

const fn method_evidence_anchor_identity_work(role: MethodEvidenceAnchorRole) -> usize {
    match role {
        MethodEvidenceAnchorRole::Adapter { .. } => 1,
        MethodEvidenceAnchorRole::AdapterEdge { .. } => 4,
        MethodEvidenceAnchorRole::ImplementationOwner { .. }
        | MethodEvidenceAnchorRole::LexicalCaptureUse { .. }
        | MethodEvidenceAnchorRole::LexicalOwner { .. }
        | MethodEvidenceAnchorRole::LexicalUse { .. }
        | MethodEvidenceAnchorRole::Domain { .. }
        | MethodEvidenceAnchorRole::Application { .. }
        | MethodEvidenceAnchorRole::Instantiation { .. } => 0,
    }
}

#[derive(Debug)]
pub(crate) struct MethodEvidenceAnchor {
    pub(crate) node: NodeId,
    pub(crate) owner: Option<MethodEvidenceOwner>,
    pub(crate) requirement: Option<RequirementId>,
    pub(crate) method: MethodId,
    pub(crate) application: InterfaceApplication,
    pub(crate) role: MethodEvidenceAnchorRole,
    pub(crate) occurrence: Option<usize>,
    pub(crate) expectation: usize,
}

/// Names the closed pure Core dialect selected by Ash.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct AshPureDialect;

impl AshPureDialect {
    /// Stable compiler-facing name of the selected Core dialect.
    pub const NAME: &'static str = "ash.pure";
}

/// Maximum recursive Type or Origin wrappers admitted into Core storage.
///
/// This is replaceable compiler resource behavior aligned with the current
/// parser structural budget plus the two wrappers that retained lowering may
/// synthesize for tuple domains and constructor/function values. It is not an
/// Ash language-semantic limit.
pub const CORE_PAYLOAD_DEPTH_LIMIT: usize = 130;

/// Maximum structured-pattern wrappers admitted into one Core pattern.
pub const CORE_PATTERN_DEPTH_LIMIT: usize = 33;

pub(super) fn origin_depth_within_limit(root: &Origin) -> bool {
    let mut current = root;
    for _ in 0..=CORE_PAYLOAD_DEPTH_LIMIT {
        match current {
            Origin::Source(_) => return true,
            Origin::Generated { cause, .. } => current = cause,
            Origin::Related { primary, .. } => current = primary,
        }
    }
    false
}

/// Identifies a node inside one Core arena.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub struct NodeId {
    arena: ArenaId,
    index: u32,
}

impl NodeId {
    pub(super) const fn new(arena: ArenaId, index: u32) -> Self {
        Self { arena, index }
    }

    /// Returns the arena-local numeric handle.
    #[must_use]
    pub const fn value(self) -> u32 {
        self.index
    }

    pub(super) const fn arena(self) -> ArenaId {
        self.arena
    }

    pub(super) fn index(self) -> Result<usize, BuildError> {
        usize::try_from(self.index).map_err(|_| BuildError::InvalidNodeId)
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub(super) struct ArenaId(u32);

impl ArenaId {
    #[cfg(test)]
    pub(super) const fn new(value: u32) -> Self {
        Self(value)
    }
}

static ARENA_IDS: ArenaIdAllocator = ArenaIdAllocator::with_next(0);

struct ArenaIdAllocator {
    next: AtomicU32,
}

impl ArenaIdAllocator {
    const fn with_next(next: u32) -> Self {
        Self {
            next: AtomicU32::new(next),
        }
    }

    fn allocate(&self) -> Result<ArenaId, BuildError> {
        self.next
            .fetch_update(Ordering::Relaxed, Ordering::Relaxed, checked_add_one)
            .map(ArenaId)
            .map_err(|_| BuildError::ArenaIdExhausted)
    }
}

const fn checked_add_one(value: u32) -> Option<u32> {
    value.checked_add(1)
}

/// A typed expression in the pure Ash dialect.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CoreTypedExpr<F: CoreOperationFamily> {
    /// The structural result type.
    pub ty: Type,
    /// The exact effects requested while evaluating this node.
    pub(super) effects: F::Effects,
    /// Causal source provenance.
    pub origin: Origin,
    /// The selected pure feature payload.
    pub kind: F::Kind,
}

/// One typed node in the pure Core dialect.
pub type TypedExpr = CoreTypedExpr<PureOperationFamily>;

impl<F: CoreOperationFamily> CoreTypedExpr<F> {
    /// Returns this node's authenticated computation row.
    #[must_use]
    pub fn effects(&self) -> &EffectRow {
        F::effect_row(&self.effects)
    }

    /// Consumes a standalone expression and dismantles its structural type
    /// without following the host call stack.
    pub fn discard_iteratively(self) {
        let Self {
            ty,
            effects,
            origin,
            kind,
        } = self;
        discard_type_iteratively(ty);
        F::discard_effects(effects);
        discard_origin_iteratively(origin);
        F::discard_metadata(kind);
    }
}

/// The closed expression families in the pure Ash dialect.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PureExprKind {
    /// A value node.
    Value(PureValue),
    /// A resolved variable occurrence.
    Variable(VariableNode),
    /// A strict pure computation.
    Computation(PureComputation),
}

impl PureExprKind {
    /// Returns the number of graph edges owned by this closed payload.
    #[must_use]
    pub fn child_count(&self) -> usize {
        match self {
            Self::Value(value) => match value {
                PureValue::Integer(node) => fixed_child_count(node.children()),
                PureValue::Boolean(node) => fixed_child_count(node.children()),
                PureValue::Unit(node) => fixed_child_count(node.children()),
                PureValue::Function(node) => fixed_child_count(node.children()),
                PureValue::Constructor(_) | PureValue::String(_) | PureValue::Intrinsic(_) => 0,
            },
            Self::Variable(node) => fixed_child_count(node.children()),
            Self::Computation(computation) => match computation {
                PureComputation::Bind(node) => fixed_child_count(node.children()),
                PureComputation::RecursiveBind(node) => node.child_count(),
                PureComputation::Apply(node) => fixed_child_count(node.children()),
                PureComputation::Primitive(node) => fixed_child_count(node.children()),
                PureComputation::Tuple(node) => node.elements().len(),
                PureComputation::Match(node) => node.arms().len() + 1,
                PureComputation::NewtypeConversion(_)
                | PureComputation::LocalNominalScope(_)
                | PureComputation::TypeAbstraction(_)
                | PureComputation::TypeApplication(_) => 1,
            },
        }
    }

    /// Returns one graph edge in deterministic evaluation-independent order.
    #[must_use]
    pub fn child_at(&self, index: usize) -> Option<NodeId> {
        match self {
            Self::Value(value) => match value {
                PureValue::Integer(node) => fixed_child_at(node.children(), index),
                PureValue::Boolean(node) => fixed_child_at(node.children(), index),
                PureValue::Unit(node) => fixed_child_at(node.children(), index),
                PureValue::Function(node) => fixed_child_at(node.children(), index),
                PureValue::Constructor(_) | PureValue::String(_) | PureValue::Intrinsic(_) => None,
            },
            Self::Variable(node) => fixed_child_at(node.children(), index),
            Self::Computation(computation) => match computation {
                PureComputation::Bind(node) => fixed_child_at(node.children(), index),
                PureComputation::RecursiveBind(node) => node.child_at(index),
                PureComputation::Apply(node) => fixed_child_at(node.children(), index),
                PureComputation::Primitive(node) => fixed_child_at(node.children(), index),
                PureComputation::Tuple(node) => node.elements().get(index).copied(),
                PureComputation::Match(node) => {
                    if index == 0 {
                        Some(node.scrutinee())
                    } else {
                        node.arms().get(index - 1).map(CoreMatchArm::body)
                    }
                }
                PureComputation::TypeAbstraction(node) => {
                    fixed_child_at([Some(node.body())], index)
                }
                PureComputation::TypeApplication(node) => {
                    fixed_child_at([Some(node.function())], index)
                }
                PureComputation::NewtypeConversion(node) => {
                    fixed_child_at([Some(node.child())], index)
                }
                PureComputation::LocalNominalScope(node) => {
                    fixed_child_at([Some(node.body())], index)
                }
            },
        }
    }
}

fn fixed_child_count<const N: usize>(children: [Option<NodeId>; N]) -> usize {
    children.into_iter().flatten().count()
}

fn fixed_child_at<const N: usize>(children: [Option<NodeId>; N], index: usize) -> Option<NodeId> {
    children.into_iter().flatten().nth(index)
}

/// The closed value families in the pure Ash dialect.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PureValue {
    /// A packed UTF-8 string literal.
    String(super::packed::StringNode),
    /// A compiler-owned first-order pure callable.
    Intrinsic(super::packed::IntrinsicNode),
    /// An arbitrary-precision integer.
    Integer(IntegerNode),
    /// A Boolean value.
    Boolean(BooleanNode),
    /// The unit value.
    Unit(UnitNode),
    /// A unary function value.
    Function(FunctionNode),
    /// A nullary value or payload-constructor function.
    Constructor(ConstructorNode),
}

/// The closed computation families in the pure Ash dialect.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PureComputation {
    /// A sequential nonrecursive binding.
    Bind(BindingNode),
    /// A simultaneous recursive binding group.
    RecursiveBind(RecursiveBindingNode),
    /// A strict unary application.
    Apply(ApplicationNode),
    /// A primitive operation.
    Primitive(PrimitiveNode),
    /// Strict tuple construction.
    Tuple(TupleNode),
    /// Structured first-match selection.
    Match(MatchNode),
    /// An explicit erased module-newtype representation conversion.
    NewtypeConversion(NewtypeConversionNode),
    /// A runtime-erased lexical nominal scope.
    LocalNominalScope(LocalNominalScopeNode),
    /// An explicit erased rank-1 type abstraction.
    TypeAbstraction(TypeAbstractionNode),
    /// An explicit erased rank-1 type application.
    TypeApplication(TypeApplicationNode),
}

/// The pure dialect's deliberately uninhabited operation family.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum PureOperation {}

#[doc(hidden)]
pub enum OperationTypeMetadata<'a> {
    Type(&'a Type),
    Argument(&'a crate::types::KindedArgument),
    Row(&'a crate::types::EffectRow),
    Pattern(&'a CorePattern),
}

/// Selects the operation payload admitted by one Core dialect while reusing
/// the common arena, program, validation, and transform substrate.
pub trait CoreOperationFamily: Clone + Copy + fmt::Debug + Eq + PartialEq + 'static {
    /// The dialect-specific node payload.
    type Kind: Clone + fmt::Debug + Eq + PartialEq;
    /// The dialect-specific operation family.
    type Operation;
    /// Per-node computation-row storage. Pure Core selects a zero-sized carrier.
    type Effects: Clone + fmt::Debug + Eq + PartialEq;

    /// Stable dialect membership name.
    const DIALECT_NAME: &'static str;
    /// Whether every node in this dialect must have an empty effect row.
    const REQUIRES_EMPTY_ROWS: bool;
    /// Whether function types may retain a nonempty computation codomain row.
    const ALLOWS_EFFECTFUL_TYPES: bool;

    /// Embeds an ordinary Core feature.
    fn from_pure(kind: PureExprKind) -> Self::Kind;
    /// Embeds one dialect operation.
    fn from_operation(operation: Self::Operation) -> Self::Kind;
    /// Borrows an ordinary Core feature when present.
    fn pure(kind: &Self::Kind) -> Option<&PureExprKind>;
    /// Mutably borrows an ordinary Core feature when present.
    fn pure_mut(kind: &mut Self::Kind) -> Option<&mut PureExprKind>;
    /// Visits binders owned by dialect operations at their enclosing node.
    fn visit_operation_binders<'a>(_kind: &'a Self::Kind, _visit: &mut dyn FnMut(&'a TypedBinder)) {
    }
    /// Visits type-bearing metadata owned by dialect operations.
    fn visit_operation_type_metadata<'a>(
        _kind: &'a Self::Kind,
        _visit: &mut dyn FnMut(OperationTypeMetadata<'a>),
    ) {
    }
    /// Rewrites operation-owned types through admitted, fallible callbacks.
    fn rewrite_operation_type_metadata(
        _kind: &mut Self::Kind,
        _rewrite: &mut dyn FnMut(&Type) -> Result<Type, BuildError>,
        _charge: &mut dyn FnMut(usize) -> Result<(), BuildError>,
    ) -> Result<(), BuildError> {
        Ok(())
    }
    /// Stores an admitted row in this family's per-node carrier.
    fn store_effects(effects: EffectRow) -> Self::Effects;
    /// Borrows the semantic row represented by the family carrier.
    fn effect_row(effects: &Self::Effects) -> &EffectRow;
    /// Disposes one family row carrier.
    fn discard_effects(effects: Self::Effects);
    /// Returns the number of graph edges in this payload.
    fn child_count(kind: &Self::Kind) -> usize;
    /// Returns operation-owned edges beyond the one node-priced primary edge.
    fn operation_extra_edge_count(_kind: &Self::Kind) -> usize {
        0
    }
    /// Returns one graph edge in deterministic order.
    fn child_at(kind: &Self::Kind, index: usize) -> Option<NodeId>;
    /// Iteratively disposes owned payload metadata.
    fn discard_metadata(kind: Self::Kind);
}

/// Selects the pure dialect's uninhabited operation family.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct PureOperationFamily;

impl CoreOperationFamily for PureOperationFamily {
    type Kind = PureExprKind;
    type Operation = PureOperation;
    type Effects = ();

    const DIALECT_NAME: &'static str = AshPureDialect::NAME;
    const REQUIRES_EMPTY_ROWS: bool = true;
    const ALLOWS_EFFECTFUL_TYPES: bool = false;

    fn from_pure(kind: PureExprKind) -> Self::Kind {
        kind
    }

    fn from_operation(operation: Self::Operation) -> Self::Kind {
        match operation {}
    }

    fn pure(kind: &Self::Kind) -> Option<&PureExprKind> {
        Some(kind)
    }

    fn pure_mut(kind: &mut Self::Kind) -> Option<&mut PureExprKind> {
        Some(kind)
    }

    fn store_effects(effects: EffectRow) -> Self::Effects {
        debug_assert!(effects.is_empty());
        drop(effects);
    }

    fn effect_row(_: &Self::Effects) -> &EffectRow {
        static EMPTY: OnceLock<EffectRow> = OnceLock::new();
        EMPTY.get_or_init(EffectRow::empty)
    }

    fn discard_effects(_: Self::Effects) {}

    fn child_count(kind: &Self::Kind) -> usize {
        kind.child_count()
    }

    fn child_at(kind: &Self::Kind, index: usize) -> Option<NodeId> {
        kind.child_at(index)
    }

    fn discard_metadata(kind: Self::Kind) {
        discard_pure_expr_kind_metadata(kind);
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) struct DialectId(&'static str);

impl DialectId {
    #[cfg(test)]
    pub(super) const PURE: Self = Self(AshPureDialect::NAME);

    pub(super) const fn named(name: &'static str) -> Self {
        Self(name)
    }

    #[cfg(test)]
    pub(super) const FOREIGN: Self = Self("test.foreign");
}

#[derive(Debug)]
pub(super) struct StoredNode<F: CoreOperationFamily> {
    pub(super) dialect: DialectId,
    pub(super) ty: Type,
    pub(super) effects: F::Effects,
    pub(super) origin: Option<Origin>,
    pub(super) kind: F::Kind,
}

/// An unchecked Core arena which must cross [`super::validate()`] before use.
#[derive(Debug)]
pub struct UnvalidatedCoreProgram<F: CoreOperationFamily> {
    pub(super) registry: Arc<ResolvedRegistry>,
    pub(super) method_evidence: Arc<MethodEvidenceCatalog>,
    pub(super) method_evidence_anchors: Box<[MethodEvidenceAnchor]>,
    pub(super) arena: ArenaId,
    pub(super) nodes: Vec<StoredNode<F>>,
    pub(super) root: NodeId,
}

type UnvalidatedParts<F> = (
    Arc<ResolvedRegistry>,
    Arc<MethodEvidenceCatalog>,
    Box<[MethodEvidenceAnchor]>,
    ArenaId,
    Vec<StoredNode<F>>,
    NodeId,
);

/// An unchecked pure Core arena.
pub type UnvalidatedProgram = UnvalidatedCoreProgram<PureOperationFamily>;

impl UnvalidatedProgram {
    #[cfg(test)]
    pub(crate) fn expression_kinds_for_test(&self) -> impl Iterator<Item = &PureExprKind> {
        self.nodes.iter().map(|node| &node.kind)
    }
}

impl<F: CoreOperationFamily> UnvalidatedCoreProgram<F> {
    pub(crate) fn method_evidence(&self) -> &Arc<MethodEvidenceCatalog> {
        &self.method_evidence
    }

    /// Borrows recorded anchor claims; original admission authenticates them.
    pub(crate) fn method_evidence_anchors(&self) -> &[MethodEvidenceAnchor] {
        &self.method_evidence_anchors
    }

    pub(super) fn discard_iteratively(mut self) {
        self.discard_contents();
    }

    pub(super) fn into_parts(mut self) -> UnvalidatedParts<F> {
        let registry = std::mem::replace(&mut self.registry, Arc::clone(empty_registry()));
        let method_evidence = std::mem::replace(
            &mut self.method_evidence,
            Arc::clone(empty_method_evidence()),
        );
        let method_evidence_anchors = std::mem::take(&mut self.method_evidence_anchors);
        let nodes = std::mem::take(&mut self.nodes);
        (
            registry,
            method_evidence,
            method_evidence_anchors,
            self.arena,
            nodes,
            self.root,
        )
    }

    fn discard_contents(&mut self) {
        for stored in std::mem::take(&mut self.nodes) {
            discard_type_iteratively(stored.ty);
            F::discard_effects(stored.effects);
            if let Some(origin) = stored.origin {
                discard_origin_iteratively(origin);
            }
            F::discard_metadata(stored.kind);
        }
        let registry = std::mem::replace(&mut self.registry, Arc::clone(empty_registry()));
        if let Ok(registry) = Arc::try_unwrap(registry) {
            registry.discard_iteratively();
        }
        self.method_evidence_anchors = Box::new([]);
        drop(std::mem::replace(
            &mut self.method_evidence,
            Arc::clone(empty_method_evidence()),
        ));
    }
}

impl<F: CoreOperationFamily> Drop for UnvalidatedCoreProgram<F> {
    fn drop(&mut self) {
        self.discard_contents();
    }
}

/// A pure Core arena whose graph, types, scope, dialect, and provenance hold.
#[derive(Debug)]
pub struct CoreProgram<F: CoreOperationFamily> {
    registry: Arc<ResolvedRegistry>,
    method_evidence: Arc<MethodEvidenceCatalog>,
    method_evidence_anchors: Box<[MethodEvidenceAnchor]>,
    arena: ArenaId,
    nodes: Box<[CoreTypedExpr<F>]>,
    root: NodeId,
}

/// A validated pure Core arena.
pub type PureProgram = CoreProgram<PureOperationFamily>;

impl<F: CoreOperationFamily> CoreProgram<F> {
    pub(super) fn new(
        registry: Arc<ResolvedRegistry>,
        method_evidence: Arc<MethodEvidenceCatalog>,
        method_evidence_anchors: Box<[MethodEvidenceAnchor]>,
        arena: ArenaId,
        nodes: Vec<CoreTypedExpr<F>>,
        root: NodeId,
    ) -> Self {
        Self {
            registry,
            method_evidence,
            method_evidence_anchors,
            arena,
            nodes: nodes.into_boxed_slice(),
            root,
        }
    }

    /// Returns the root expression.
    #[must_use]
    pub const fn root(&self) -> NodeId {
        self.root
    }

    /// Returns a node when the arena-local handle belongs to this program.
    #[must_use]
    pub fn node(&self, id: NodeId) -> Option<&CoreTypedExpr<F>> {
        if id.arena() != self.arena {
            return None;
        }
        usize::try_from(id.value())
            .ok()
            .and_then(|index| self.nodes.get(index))
    }

    /// Returns the number of validated nodes.
    #[must_use]
    pub const fn node_count(&self) -> usize {
        self.nodes.len()
    }

    /// Returns the immutable nominal and constructor registry.
    #[must_use]
    pub const fn registry(&self) -> &Arc<ResolvedRegistry> {
        &self.registry
    }

    pub(crate) const fn method_evidence(&self) -> &Arc<MethodEvidenceCatalog> {
        &self.method_evidence
    }

    pub(crate) const fn method_evidence_anchors(&self) -> &[MethodEvidenceAnchor] {
        &self.method_evidence_anchors
    }
}

impl<F: CoreOperationFamily> Drop for CoreProgram<F> {
    fn drop(&mut self) {
        let nodes = std::mem::take(&mut self.nodes);
        for typed in nodes {
            discard_type_iteratively(typed.ty);
            F::discard_effects(typed.effects);
            discard_origin_iteratively(typed.origin);
            F::discard_metadata(typed.kind);
        }
        let registry = std::mem::replace(&mut self.registry, Arc::clone(empty_registry()));
        if let Ok(registry) = Arc::try_unwrap(registry) {
            registry.discard_iteratively();
        }
        self.method_evidence_anchors = Box::new([]);
        drop(std::mem::replace(
            &mut self.method_evidence,
            Arc::clone(empty_method_evidence()),
        ));
    }
}

/// The capability required by all later Core consumers.
#[derive(Debug)]
pub struct ValidatedCoreProgram<F: CoreOperationFamily>(Arc<CoreProgram<F>>);

/// The validated pure Core capability.
pub type ValidatedProgram = ValidatedCoreProgram<PureOperationFamily>;

impl<F: CoreOperationFamily> ValidatedCoreProgram<F> {
    pub(super) fn new(program: CoreProgram<F>) -> Self {
        Self(Arc::new(program))
    }

    #[allow(dead_code, reason = "reserved for the validated evaluator boundary")]
    pub(crate) fn shared(&self) -> Arc<CoreProgram<F>> {
        Arc::clone(&self.0)
    }

    /// Returns the validated root expression.
    #[must_use]
    pub fn root(&self) -> NodeId {
        self.0.root()
    }

    /// Returns a validated node when the handle belongs to this program.
    #[must_use]
    pub fn node(&self, id: NodeId) -> Option<&CoreTypedExpr<F>> {
        self.0.node(id)
    }

    /// Returns the number of validated nodes.
    #[must_use]
    pub fn node_count(&self) -> usize {
        self.0.node_count()
    }

    /// Returns the immutable nominal and constructor registry.
    #[must_use]
    pub fn registry(&self) -> &Arc<ResolvedRegistry> {
        self.0.registry()
    }

    pub(crate) fn method_evidence(&self) -> &Arc<MethodEvidenceCatalog> {
        self.0.method_evidence()
    }

    pub(crate) fn method_evidence_anchors(&self) -> &[MethodEvidenceAnchor] {
        self.0.method_evidence_anchors()
    }
}

#[cfg(test)]
pub(crate) fn forge_validated_for_test(program: UnvalidatedProgram) -> ValidatedProgram {
    let (registry, method_evidence, method_evidence_anchors, arena, stored_nodes, root) =
        program.into_parts();
    let nodes = stored_nodes
        .into_iter()
        .map(|stored| TypedExpr {
            ty: stored.ty,
            effects: stored.effects,
            origin: stored
                .origin
                .expect("a forged validated test node must retain provenance"),
            kind: stored.kind,
        })
        .collect();
    ValidatedProgram::new(PureProgram::new(
        registry,
        method_evidence,
        method_evidence_anchors,
        arena,
        nodes,
        root,
    ))
}

/// Why unchecked Core construction could not be represented.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum BuildError {
    /// The process cannot assign another distinct Core arena identity.
    ArenaIdExhausted,
    /// The arena cannot assign another `u32` node handle.
    NodeIdExhausted,
    /// The builder cannot assign another resolver-compatible binder identity.
    BinderIdExhausted,
    /// A resolver identity occurs more than once in namespace reservations.
    DuplicateBinderReservation,
    /// Resolver namespace reservation was attempted after binder work began.
    BinderReservationPhaseStarted,
    /// A resolver identity was materialized without an upfront reservation.
    UnreservedResolvedBinder,
    /// A reserved resolver identity was materialized more than once.
    DuplicateResolvedBinder,
    /// A binder capability belongs to another Core arena.
    ForeignBinder,
    /// A Type contains more recursive wrappers than Core currently admits.
    TypeDepthExceeded,
    /// Cumulative structural type work exceeded the compiler budget.
    TypeWorkExceeded,
    /// An Origin contains more recursive wrappers than Core currently admits.
    OriginDepthExceeded,
    /// A structured pattern contains more wrappers than Core currently admits.
    PatternDepthExceeded,
    /// Iterative payload rebuilding found inconsistent internal state.
    InvalidPayload,
    /// The requested root does not belong to this arena.
    InvalidNodeId,
}

impl BuildError {
    pub(crate) fn diagnostic_message(self) -> (crate::message::Message<'static>, &'static str) {
        use crate::message::Message;
        match self {
            Self::ArenaIdExhausted => (
                Message::core_build_arena_id_exhausted(),
                "arena-id-exhausted",
            ),
            Self::NodeIdExhausted => (Message::core_build_node_id_exhausted(), "node-id-exhausted"),
            Self::BinderIdExhausted => (
                Message::core_build_binder_id_exhausted(),
                "binder-id-exhausted",
            ),
            Self::DuplicateBinderReservation => (
                Message::core_build_duplicate_binder_reservation(),
                "duplicate-binder-reservation",
            ),
            Self::BinderReservationPhaseStarted => (
                Message::core_build_binder_reservation_phase_started(),
                "binder-reservation-phase-started",
            ),
            Self::UnreservedResolvedBinder => (
                Message::core_build_unreserved_resolved_binder(),
                "unreserved-resolved-binder",
            ),
            Self::DuplicateResolvedBinder => (
                Message::core_build_duplicate_resolved_binder(),
                "duplicate-resolved-binder",
            ),
            Self::ForeignBinder => (Message::core_build_foreign_binder(), "foreign-binder"),
            Self::TypeDepthExceeded => (
                Message::core_build_type_depth_exceeded(),
                "type-depth-exceeded",
            ),
            Self::TypeWorkExceeded => (
                Message::core_build_type_work_exceeded(),
                "type-work-exceeded",
            ),
            Self::OriginDepthExceeded => (
                Message::core_build_origin_depth_exceeded(),
                "origin-depth-exceeded",
            ),
            Self::PatternDepthExceeded => (
                Message::core_build_pattern_depth_exceeded(),
                "pattern-depth-exceeded",
            ),
            Self::InvalidPayload => (Message::core_build_invalid_payload(), "invalid-payload"),
            Self::InvalidNodeId => (Message::core_build_invalid_node_id(), "invalid-node-id"),
        }
    }
}

impl fmt::Display for BuildError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(match self {
            Self::ArenaIdExhausted => "core arena identity space is exhausted",
            Self::NodeIdExhausted => "core node identity space is exhausted",
            Self::BinderIdExhausted => "core binder identity space is exhausted",
            Self::DuplicateBinderReservation => {
                "core resolved binder namespace contains a duplicate identity"
            }
            Self::BinderReservationPhaseStarted => {
                "core resolved binder namespace must be reserved before binder construction"
            }
            Self::UnreservedResolvedBinder => {
                "core resolved binder identity was not reserved upfront"
            }
            Self::DuplicateResolvedBinder => {
                "core resolved binder identity was already materialized"
            }
            Self::ForeignBinder => "core binder capability belongs to another arena",
            Self::TypeDepthExceeded => "core type structural depth is exceeded",
            Self::TypeWorkExceeded => "core cumulative type work is exceeded",
            Self::OriginDepthExceeded => "core origin structural depth is exceeded",
            Self::PatternDepthExceeded => "core pattern structural depth is exceeded",
            Self::InvalidPayload => "core payload admission state is inconsistent",
            Self::InvalidNodeId => "core node identity does not belong to the arena",
        })
    }
}

impl Error for BuildError {}

/// Builds an unchecked pure Core arena with checked identity allocation.
#[derive(Debug)]
#[must_use]
pub struct CoreBuilder<F: CoreOperationFamily = PureOperationFamily> {
    registry: Arc<ResolvedRegistry>,
    method_evidence: Arc<MethodEvidenceCatalog>,
    method_evidence_anchors: Vec<MethodEvidenceAnchor>,
    consumed_method_evidence: Vec<bool>,
    method_evidence_anchor_keys: HashSet<(NodeId, MethodEvidenceAnchorRole, Option<usize>)>,
    method_evidence_expectation_positions: HashMap<(Option<usize>, MethodId), Vec<usize>>,
    arena: Option<ArenaId>,
    pub(super) nodes: Vec<StoredNode<F>>,
    next_binder: u32,
    reserved_resolved: HashSet<BinderId>,
    materialized_resolved: HashSet<BinderId>,
    generated_binders: HashSet<BinderId>,
    inference_binders: HashSet<BinderId>,
    binder_phase_started: bool,
    pub(super) type_work: TypeWorkBudget,
    rewrite_type_work: TypeWorkBudget,
    requires_type_rewrite: bool,
    deferred_cleanup_rows: HashSet<crate::types::InferenceVariableId>,
}

impl Default for CoreBuilder<PureOperationFamily> {
    fn default() -> Self {
        Self::new()
    }
}

impl CoreBuilder<PureOperationFamily> {
    /// Starts an empty pure Core arena.
    pub fn new() -> Self {
        Self::new_for_family()
    }

    /// Starts a pure arena carrying an immutable resolved data registry.
    pub fn with_registry(registry: Arc<ResolvedRegistry>) -> Self {
        Self::with_registry_for_family(registry)
    }

    #[cfg(test)]
    fn with_registry_method_evidence_and_type_work(
        registry: Arc<ResolvedRegistry>,
        method_evidence: Arc<MethodEvidenceCatalog>,
        type_work: TypeWorkBudget,
    ) -> Result<Self, BuildError> {
        Self::with_catalogs_and_type_work(registry, method_evidence, type_work)
    }
}

/// Identifies the first Core node after an elaboration-local type boundary.
#[derive(Clone, Copy, Debug)]
pub(crate) struct TypeRewriteCheckpoint(usize);

/// Captures the builder-owned state that constructor lowering may append.
#[derive(Clone, Copy, Debug)]
pub(crate) struct CoreBuilderCheckpoint {
    nodes: usize,
    next_binder: u32,
    binder_phase_started: bool,
    requires_type_rewrite: bool,
}

impl<F: CoreOperationFamily> CoreBuilder<F> {
    fn from_catalogs(
        registry: Arc<ResolvedRegistry>,
        method_evidence: Arc<MethodEvidenceCatalog>,
        method_evidence_anchors: Vec<MethodEvidenceAnchor>,
        consumed_method_evidence: Vec<bool>,
        type_work: TypeWorkBudget,
    ) -> Self {
        Self {
            registry,
            method_evidence,
            method_evidence_anchors,
            consumed_method_evidence,
            method_evidence_anchor_keys: HashSet::new(),
            method_evidence_expectation_positions: HashMap::new(),
            arena: None,
            nodes: Vec::new(),
            next_binder: 0,
            reserved_resolved: HashSet::new(),
            materialized_resolved: HashSet::new(),
            generated_binders: HashSet::new(),
            inference_binders: HashSet::new(),
            binder_phase_started: false,
            type_work,
            rewrite_type_work: TypeWorkBudget::default(),
            requires_type_rewrite: false,
            deferred_cleanup_rows: HashSet::new(),
        }
    }

    /// Starts an empty Core arena.
    fn new_for_family() -> Self {
        Self::from_catalogs(
            Arc::clone(empty_registry()),
            Arc::clone(empty_method_evidence()),
            Vec::new(),
            Vec::new(),
            TypeWorkBudget::default(),
        )
    }

    /// Starts an empty arena carrying an immutable resolved data registry.
    pub(crate) fn with_registry_for_family(registry: Arc<ResolvedRegistry>) -> Self {
        Self::from_catalogs(
            registry,
            Arc::clone(empty_method_evidence()),
            Vec::new(),
            Vec::new(),
            TypeWorkBudget::default(),
        )
    }

    pub(crate) fn with_registry_and_method_evidence(
        registry: Arc<ResolvedRegistry>,
        method_evidence: Arc<MethodEvidenceCatalog>,
    ) -> Result<Self, BuildError> {
        Self::with_catalogs_and_type_work(registry, method_evidence, TypeWorkBudget::default())
    }

    fn with_catalogs_and_type_work(
        registry: Arc<ResolvedRegistry>,
        method_evidence: Arc<MethodEvidenceCatalog>,
        mut type_work: TypeWorkBudget,
    ) -> Result<Self, BuildError> {
        let expectation_count = method_evidence.expectations().len();
        type_work
            .charge(
                expectation_count
                    .checked_mul(6)
                    .ok_or(BuildError::TypeWorkExceeded)?,
            )
            .map_err(|()| BuildError::TypeWorkExceeded)?;
        let mut consumed_method_evidence = Vec::new();
        consumed_method_evidence
            .try_reserve_exact(expectation_count)
            .map_err(|_| BuildError::TypeWorkExceeded)?;
        consumed_method_evidence.resize(expectation_count, false);
        let mut method_evidence_anchors = Vec::new();
        method_evidence_anchors
            .try_reserve_exact(expectation_count)
            .map_err(|_| BuildError::TypeWorkExceeded)?;
        // Two original carriers, two bounded index tables, and one original
        // visit plus retained position per expectation were charged above.
        let mut method_evidence_anchor_keys = HashSet::new();
        method_evidence_anchor_keys
            .try_reserve(expectation_count)
            .map_err(|_| BuildError::TypeWorkExceeded)?;
        let mut method_evidence_expectation_positions =
            HashMap::<(Option<usize>, MethodId), Vec<usize>>::new();
        method_evidence_expectation_positions
            .try_reserve(expectation_count)
            .map_err(|_| BuildError::TypeWorkExceeded)?;
        for (position, expected) in method_evidence.expectations().iter().enumerate() {
            let positions = method_evidence_expectation_positions
                .entry((expected.occurrence, expected.method))
                .or_default();
            positions
                .try_reserve(1)
                .map_err(|_| BuildError::TypeWorkExceeded)?;
            positions.push(position);
        }
        let mut builder = Self::from_catalogs(
            registry,
            method_evidence,
            method_evidence_anchors,
            consumed_method_evidence,
            type_work,
        );
        builder.method_evidence_anchor_keys = method_evidence_anchor_keys;
        builder.method_evidence_expectation_positions = method_evidence_expectation_positions;
        Ok(builder)
    }

    pub(crate) fn requires_method_evidence_implementation_owner(
        &mut self,
        implementation: ImplMethodId,
    ) -> Result<bool, BuildError> {
        self.type_work
            .charge(self.method_evidence.implementation_owner_count())
            .map_err(|()| BuildError::TypeWorkExceeded)?;
        Ok(self
            .method_evidence
            .implementation_owner(implementation)
            .is_some())
    }

    #[allow(
        clippy::too_many_arguments,
        reason = "the private anchor row is authenticated field-for-field"
    )]
    pub(crate) fn authenticate_method_evidence(
        &mut self,
        node: NodeId,
        owner: Option<MethodEvidenceOwner>,
        requirement: Option<RequirementId>,
        method: MethodId,
        application: InterfaceApplication,
        role: MethodEvidenceAnchorRole,
        occurrence: Option<usize>,
    ) -> Result<(), BuildError> {
        let lookup_work = self
            .method_evidence
            .occurrence_count()
            .checked_mul(3)
            .and_then(|work| work.checked_add(self.method_evidence.method_count()))
            .ok_or(BuildError::TypeWorkExceeded)?;
        self.type_work
            .charge(lookup_work)
            .map_err(|()| BuildError::TypeWorkExceeded)?;
        let owner = match (role, occurrence) {
            (
                MethodEvidenceAnchorRole::Instantiation { .. }
                | MethodEvidenceAnchorRole::Adapter { .. }
                | MethodEvidenceAnchorRole::LexicalUse { .. },
                Some(slot),
            ) => self
                .method_evidence
                .occurrence(slot)
                .and_then(|expected| expected.scope),
            _ => owner,
        };
        let selection_authority = match (role, occurrence) {
            (MethodEvidenceAnchorRole::Application { .. }, Some(slot)) => self
                .method_evidence
                .occurrence(slot)
                .map(|expected| expected.selection.clone())
                .map(|selection| selection_contains_method(&selection, method, &mut self.type_work))
                .transpose()
                .map_err(|()| BuildError::TypeWorkExceeded)?
                .unwrap_or(false),
            (
                MethodEvidenceAnchorRole::Adapter {
                    implementation,
                    selection_node,
                },
                Some(slot),
            ) => self
                .method_evidence
                .occurrence(slot)
                .map(|expected| expected.selection.clone())
                .map(|selection| {
                    let Some(node) = selection.node(selection_node) else {
                        return Ok(false);
                    };
                    let EvidenceNode::Implementation { methods, .. } = node else {
                        return Ok(false);
                    };
                    self.type_work.charge(methods.len())?;
                    Ok(methods.contains(&implementation))
                })
                .transpose()
                .map_err(|()| BuildError::TypeWorkExceeded)?
                .unwrap_or(false),
            (
                MethodEvidenceAnchorRole::AdapterEdge {
                    adapter,
                    adapter_selection_node,
                    ..
                },
                Some(slot),
            ) => self
                .method_evidence
                .occurrence(slot)
                .map(|expected| expected.selection.clone())
                .map(|selection| {
                    let Some(node) = selection.node(adapter_selection_node) else {
                        return Ok(false);
                    };
                    let EvidenceNode::Implementation { methods, .. } = node else {
                        return Ok(false);
                    };
                    self.type_work.charge(methods.len())?;
                    Ok(methods.contains(&adapter))
                })
                .transpose()
                .map_err(|()| BuildError::TypeWorkExceeded)?
                .unwrap_or(false),
            _ => true,
        };
        let authority_matches = selection_authority
            && matches!(
                (role, occurrence),
                (MethodEvidenceAnchorRole::ImplementationOwner { .. }, None)
                    | (MethodEvidenceAnchorRole::LexicalOwner { .. }, None)
                    | (MethodEvidenceAnchorRole::LexicalCaptureUse { .. }, None)
                    | (MethodEvidenceAnchorRole::Domain { .. }, None)
                    | (
                        MethodEvidenceAnchorRole::Instantiation { .. }
                            | MethodEvidenceAnchorRole::LexicalUse { .. }
                            | MethodEvidenceAnchorRole::Application { .. }
                            | MethodEvidenceAnchorRole::Adapter { .. }
                            | MethodEvidenceAnchorRole::AdapterEdge { .. },
                        Some(_)
                    )
            );
        let source_identity_matches = match role {
            MethodEvidenceAnchorRole::AdapterEdge {
                producer_node,
                producer_binder,
                producer,
                ..
            } => {
                self.type_work
                    .charge(method_evidence_anchor_identity_work(role))
                    .map_err(|()| BuildError::TypeWorkExceeded)?;
                let application_argument = node
                    .index()
                    .ok()
                    .and_then(|index| self.nodes.get(index))
                    .and_then(|stored| match F::pure(&stored.kind) {
                        Some(PureExprKind::Computation(PureComputation::Apply(application))) => {
                            Some(application.argument())
                        }
                        _ => None,
                    });
                application_argument == Some(producer_node)
                    && match (producer, producer_binder) {
                        (MethodEvidenceProducer::Abstract { .. } | MethodEvidenceProducer::Lexical { .. }, Some(binder)) => producer_node
                            .index()
                            .ok()
                            .and_then(|index| self.nodes.get(index))
                            .is_some_and(|stored| {
                                matches!(
                                    F::pure(&stored.kind),
                                    Some(PureExprKind::Variable(variable)) if variable.binder() == binder
                                )
                            }),
                        (MethodEvidenceProducer::Adapter { .. }, None) => true,
                        _ => false,
                    }
            }
            _ => true,
        };
        if self.arena != Some(node.arena())
            || (!matches!(
                role,
                MethodEvidenceAnchorRole::AdapterEdge { .. }
                    | MethodEvidenceAnchorRole::ImplementationOwner { .. }
            ) && self.method_evidence.method(method).is_none())
            || !authority_matches
            || !source_identity_matches
        {
            return Err(BuildError::InvalidPayload);
        }
        self.type_work
            .charge(2)
            .map_err(|()| BuildError::TypeWorkExceeded)?;
        let anchor_key = (node, role, occurrence);
        if self.method_evidence_anchor_keys.contains(&anchor_key) {
            return Err(BuildError::InvalidPayload);
        }
        let mut expectation = None;
        let positions = self
            .method_evidence_expectation_positions
            .get(&(occurrence, method))
            .ok_or(BuildError::InvalidPayload)?;
        for &index in positions {
            self.type_work
                .charge(1)
                .map_err(|()| BuildError::TypeWorkExceeded)?;
            let expected = &self.method_evidence.expectations()[index];
            if !self.consumed_method_evidence[index]
                && expected.occurrence == occurrence
                && expected.method == method
                && method_evidence_anchor_matches_expectation(
                    &self.method_evidence,
                    expected,
                    owner,
                    requirement,
                    role,
                    &application,
                    &mut self.type_work,
                )
                .map_err(|()| BuildError::TypeWorkExceeded)?
            {
                expectation = Some(index);
                break;
            }
        }
        let Some(expectation) = expectation else {
            return Err(BuildError::InvalidPayload);
        };
        let retained_anchor_work = 8usize
            .checked_add(application.arguments().len())
            .ok_or(BuildError::TypeWorkExceeded)?
            .checked_add(method_evidence_anchor_identity_work(role))
            .ok_or(BuildError::TypeWorkExceeded)?;
        self.type_work
            .charge(retained_anchor_work)
            .map_err(|()| BuildError::TypeWorkExceeded)?;
        self.method_evidence_anchors
            .try_reserve(1)
            .map_err(|_| BuildError::TypeWorkExceeded)?;
        self.method_evidence_anchor_keys
            .try_reserve(1)
            .map_err(|_| BuildError::TypeWorkExceeded)?;
        let (interface, arguments) = application.into_parts();
        let admitted = self.admit_owner_arguments(arguments)?;
        self.method_evidence_anchor_keys.insert(anchor_key);
        self.method_evidence_anchors.push(MethodEvidenceAnchor {
            node,
            owner,
            requirement,
            method,
            application: InterfaceApplication::new_kinded(interface, admitted),
            role,
            occurrence,
            expectation,
        });
        self.consumed_method_evidence[expectation] = true;
        Ok(())
    }

    pub(crate) fn lexical_capture_owner(
        &mut self,
        source: crate::interface::LexicalEvidenceId,
        method: MethodId,
    ) -> Result<usize, BuildError> {
        self.type_work
            .charge(self.method_evidence.lexical_owners.len())
            .map_err(|()| BuildError::TypeWorkExceeded)?;
        self.method_evidence
            .lexical_owners
            .iter()
            .position(|owner| owner.source == source && owner.method == method)
            .ok_or(BuildError::InvalidPayload)
    }

    pub(crate) fn authenticate_lexical_capture_use(
        &mut self,
        node: NodeId,
        owner: usize,
        ordinal: usize,
    ) -> Result<(), BuildError> {
        self.type_work
            .charge(1)
            .map_err(|()| BuildError::TypeWorkExceeded)?;
        let row = self
            .method_evidence
            .lexical_owners
            .get(owner)
            .ok_or(BuildError::InvalidPayload)?;
        let binder = row
            .captures
            .get(ordinal)
            .ok_or(BuildError::InvalidPayload)?;
        if !self.nodes.get(node.index()?).and_then(|node| F::pure(&node.kind))
            .is_some_and(|kind| matches!(kind, PureExprKind::Variable(variable) if variable.binder() == *binder)) {
            return Err(BuildError::InvalidPayload);
        }
        let method = row.method;
        let application = row
            .application
            .clone_with_budget(&mut self.type_work)
            .map_err(|()| BuildError::TypeWorkExceeded)?;
        self.authenticate_method_evidence(
            node,
            None,
            None,
            method,
            application,
            MethodEvidenceAnchorRole::LexicalCaptureUse { owner, ordinal },
            None,
        )
    }

    /// Reserves the complete resolver-assigned binder namespace.
    ///
    /// Callers may make multiple reservations before binder construction
    /// starts, but every identity must be globally unique across those calls.
    /// The reservation is transactional: an error leaves the namespace
    /// unchanged.
    ///
    /// # Errors
    ///
    /// Returns [`BuildError::DuplicateBinderReservation`] when an identity is
    /// duplicated within this input or was reserved by an earlier call.
    /// Returns [`BuildError::BinderReservationPhaseStarted`] once any binder
    /// allocation or resolved-binder materialization has started.
    pub fn reserve_resolved_binders<I>(&mut self, ids: I) -> Result<(), BuildError>
    where
        I: IntoIterator<Item = BinderId>,
    {
        if self.binder_phase_started {
            return Err(BuildError::BinderReservationPhaseStarted);
        }
        let mut pending = HashSet::new();
        for id in ids {
            if self.reserved_resolved.contains(&id) || !pending.insert(id) {
                return Err(BuildError::DuplicateBinderReservation);
            }
        }
        self.reserved_resolved.extend(pending);
        Ok(())
    }

    /// Reserve the unpublished draft's exact binders using its caller's work ledger.
    pub(crate) fn reserve_provider_draft_binders(
        &mut self,
        ids: &[BinderId],
        budget: &mut TypeWorkBudget,
    ) -> Result<(), BuildError> {
        if self.binder_phase_started {
            return Err(BuildError::BinderReservationPhaseStarted);
        }
        budget
            .charge(ids.len().saturating_mul(2))
            .map_err(|()| BuildError::TypeWorkExceeded)?;
        let mut pending = HashSet::new();
        pending
            .try_reserve(ids.len())
            .map_err(|_| BuildError::TypeWorkExceeded)?;
        for id in ids {
            if self.reserved_resolved.contains(id) || !pending.insert(*id) {
                return Err(BuildError::DuplicateBinderReservation);
            }
        }
        self.reserved_resolved
            .try_reserve(pending.len())
            .map_err(|_| BuildError::TypeWorkExceeded)?;
        self.reserved_resolved.extend(pending);
        Ok(())
    }

    /// Creates a fresh typed binder for a definition payload.
    ///
    /// # Errors
    ///
    /// Returns a payload resource failure before allocating any builder state.
    /// Returns [`BuildError::BinderIdExhausted`] when no identity remains, or
    /// [`BuildError::ArenaIdExhausted`] without consuming the computed binder
    /// identity when no arena identity remains.
    pub fn binder(&mut self, ty: Type, origin: Origin) -> Result<TypedBinder, BuildError> {
        let (ty, origin, requires_type_rewrite) =
            admit_payloads(ty, origin, &mut self.type_work, F::ALLOWS_EFFECTFUL_TYPES)?;
        let (id, next) = match self.next_binder_candidate() {
            Ok(candidate) => candidate,
            Err(error) => {
                discard_admitted_payload(ty, origin);
                return Err(error);
            }
        };
        let arena = match self.ensure_arena() {
            Ok(arena) => arena,
            Err(error) => {
                discard_admitted_payload(ty, origin);
                return Err(error);
            }
        };
        if !self.generated_binders.insert(id) {
            discard_admitted_payload(ty, origin);
            return Err(BuildError::InvalidPayload);
        }
        self.next_binder = next;
        self.binder_phase_started = true;
        if requires_type_rewrite {
            self.inference_binders.insert(id);
        }
        self.requires_type_rewrite |= requires_type_rewrite;
        Ok(TypedBinder::new(arena, id, ty, origin))
    }

    /// Reads the compiler preparation allocator position.
    pub(crate) const fn provider_copy_binder_cursor(&self) -> u32 {
        self.next_binder
    }

    /// Transfers an allocation cursor to a fresh final builder. Reserved source
    /// names are allowed; no term declaration or executable authority is copied.
    pub(crate) fn seed_provider_copy_binder_cursor(
        &mut self,
        cursor: u32,
    ) -> Result<(), BuildError> {
        self.type_work
            .charge(1)
            .map_err(|()| BuildError::TypeWorkExceeded)?;
        if cursor < self.next_binder
            || !self.nodes.is_empty()
            || !self.materialized_resolved.is_empty()
            || !self.generated_binders.is_empty()
            || !self.inference_binders.is_empty()
            || !self.method_evidence_anchors.is_empty()
        {
            return Err(BuildError::InvalidPayload);
        }
        self.next_binder = cursor;
        Ok(())
    }

    /// Allocates an occurrence's generated identities without materializing
    /// declarations. The copied forest subsequently reserves them atomically.
    /// Advancing the allocator prevents ordinary binder allocation reusing them.
    pub(crate) fn allocate_provider_copy_binders(
        &mut self,
        count: usize,
    ) -> Result<Vec<BinderId>, BuildError> {
        self.type_work
            .charge(count)
            .map_err(|()| BuildError::TypeWorkExceeded)?;
        let mut identities = Vec::new();
        identities
            .try_reserve_exact(count)
            .map_err(|_| BuildError::TypeWorkExceeded)?;
        let mut next = self.next_binder;
        for _ in 0..count {
            loop {
                self.type_work
                    .charge(1)
                    .map_err(|()| BuildError::TypeWorkExceeded)?;
                let identity = BinderId::new(next);
                next = next.checked_add(1).ok_or(BuildError::BinderIdExhausted)?;
                if !self.reserved_resolved.contains(&identity)
                    && !self.materialized_resolved.contains(&identity)
                    && !self.generated_binders.contains(&identity)
                {
                    identities.push(identity);
                    break;
                }
            }
        }
        self.next_binder = next;
        Ok(identities)
    }

    /// Appends one copied occurrence's fresh namespace without changing the
    /// public reservation phase. Final validation checks exact local coverage.
    pub(crate) fn reserve_provider_copy_binders(
        &mut self,
        ids: &[BinderId],
    ) -> Result<(), BuildError> {
        self.type_work
            .charge(
                ids.len()
                    .checked_mul(2)
                    .ok_or(BuildError::TypeWorkExceeded)?,
            )
            .map_err(|()| BuildError::TypeWorkExceeded)?;
        let mut pending = HashSet::new();
        pending
            .try_reserve(ids.len())
            .map_err(|_| BuildError::TypeWorkExceeded)?;
        for id in ids {
            if self.reserved_resolved.contains(id)
                || self.generated_binders.contains(id)
                || self.materialized_resolved.contains(id)
                || !pending.insert(*id)
            {
                return Err(BuildError::DuplicateBinderReservation);
            }
        }
        self.reserved_resolved
            .try_reserve(pending.len())
            .map_err(|_| BuildError::TypeWorkExceeded)?;
        self.reserved_resolved.extend(pending);
        Ok(())
    }

    /// Materializes an upfront-reserved resolver identity in a typed binder.
    ///
    /// # Errors
    ///
    /// Returns a payload resource failure without allocating an arena or
    /// materializing the identity. Returns [`BuildError::ArenaIdExhausted`]
    /// without materializing the identity when no arena identity remains.
    /// Returns [`BuildError::UnreservedResolvedBinder`] when `id` was not in
    /// the upfront namespace, or [`BuildError::DuplicateResolvedBinder`] when
    /// that reserved identity was already materialized.
    pub fn resolved_binder(
        &mut self,
        id: BinderId,
        ty: Type,
        origin: Origin,
    ) -> Result<TypedBinder, BuildError> {
        let (ty, origin, requires_type_rewrite) =
            admit_payloads(ty, origin, &mut self.type_work, F::ALLOWS_EFFECTFUL_TYPES)?;
        if !self.reserved_resolved.contains(&id) {
            discard_admitted_payload(ty, origin);
            return Err(BuildError::UnreservedResolvedBinder);
        }
        if self.materialized_resolved.contains(&id) {
            discard_admitted_payload(ty, origin);
            return Err(BuildError::DuplicateResolvedBinder);
        }
        let arena = match self.ensure_arena() {
            Ok(arena) => arena,
            Err(error) => {
                discard_admitted_payload(ty, origin);
                return Err(error);
            }
        };
        self.materialized_resolved.insert(id);
        self.binder_phase_started = true;
        if requires_type_rewrite {
            self.inference_binders.insert(id);
        }
        self.requires_type_rewrite |= requires_type_rewrite;
        Ok(TypedBinder::new(arena, id, ty, origin))
    }

    /// Adds an integer payload with an unchecked result annotation.
    pub fn integer(
        &mut self,
        value: Integer,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        self.push(
            ty,
            origin,
            PureExprKind::Value(PureValue::Integer(IntegerNode::new(value))),
        )
    }

    /// Adds a raw string payload with an unchecked annotation and encoding.
    pub fn string(
        &mut self,
        bytes: impl Into<Arc<[u8]>>,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        self.push(
            ty,
            origin,
            PureExprKind::Value(PureValue::String(super::packed::StringNode::new(
                bytes.into(),
            ))),
        )
    }

    /// Adds an unchecked compiler-owned pure callable.
    pub fn intrinsic(
        &mut self,
        operation: super::packed::Intrinsic,
        module: ModuleId,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        self.push(
            ty,
            origin,
            PureExprKind::Value(PureValue::Intrinsic(super::packed::IntrinsicNode::new(
                operation, module,
            ))),
        )
    }

    /// Adds a Boolean payload with an unchecked result annotation.
    pub fn boolean(&mut self, value: bool, ty: Type, origin: Origin) -> Result<NodeId, BuildError> {
        self.push(
            ty,
            origin,
            PureExprKind::Value(PureValue::Boolean(BooleanNode::new(value))),
        )
    }

    /// Adds a unit payload with an unchecked result annotation.
    pub fn unit(&mut self, ty: Type, origin: Origin) -> Result<NodeId, BuildError> {
        self.push(ty, origin, PureExprKind::Value(PureValue::Unit(UnitNode)))
    }

    /// Adds an unchecked constructor occurrence.
    pub fn constructor(
        &mut self,
        constructor: crate::types::ConstructorId,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        self.push(
            ty,
            origin,
            PureExprKind::Value(PureValue::Constructor(ConstructorNode::new(constructor))),
        )
    }

    /// Adds an unchecked explicit module-newtype representation conversion.
    pub fn newtype_conversion(
        &mut self,
        owner: crate::types::NominalTypeId,
        direction: NewtypeConversionDirection,
        child: NodeId,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        self.push(
            ty,
            origin,
            PureExprKind::Computation(PureComputation::NewtypeConversion(
                NewtypeConversionNode::new(owner, direction, child),
            )),
        )
    }

    /// Adds an unchecked runtime-erased lexical nominal scope.
    pub fn local_nominal_scope(
        &mut self,
        owner: crate::types::NominalTypeId,
        body: NodeId,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        self.push(
            ty,
            origin,
            PureExprKind::Computation(PureComputation::LocalNominalScope(
                LocalNominalScopeNode::new(owner, body),
            )),
        )
    }

    /// Adds strict tuple construction with an unchecked result annotation.
    pub fn tuple(
        &mut self,
        elements: Vec<NodeId>,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        self.push(
            ty,
            origin,
            PureExprKind::Computation(PureComputation::Tuple(TupleNode::new(elements))),
        )
    }

    /// Adds a structured match with unchecked pattern and branch invariants.
    pub fn match_expression(
        &mut self,
        scrutinee: NodeId,
        arms: Vec<CoreMatchArm>,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        let admitted_arms = admit_match_arms(
            arms,
            &mut self.type_work,
            &self.inference_binders,
            F::ALLOWS_EFFECTFUL_TYPES,
        );
        let admitted_result =
            admit_payloads(ty, origin, &mut self.type_work, F::ALLOWS_EFFECTFUL_TYPES);
        match (admitted_arms, admitted_result) {
            (Ok((arms, arm_rewrite)), Ok((ty, origin, result_rewrite))) => self
                .push_admitted_tracking(
                    ty,
                    origin,
                    PureExprKind::Computation(PureComputation::Match(MatchNode::new(
                        scrutinee, arms,
                    ))),
                    arm_rewrite || result_rewrite,
                ),
            (Err(arm_error), Ok((ty, origin, _))) => {
                discard_type_iteratively(ty);
                discard_origin_iteratively(origin);
                Err(arm_error)
            }
            (Ok((arms, _)), Err(result_error)) => {
                discard_match_arms(arms);
                Err(result_error)
            }
            (Err(arm_error), Err(_)) => Err(arm_error),
        }
    }

    /// Adds a variable occurrence with an unchecked result annotation.
    pub fn variable(
        &mut self,
        binder: BinderId,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        self.push(
            ty,
            origin,
            PureExprKind::Variable(VariableNode::new(binder)),
        )
    }

    /// Adds a unary function value with an unchecked result annotation.
    ///
    /// Payload admission precedes the binder-capability check, so rejected
    /// recursive payloads are dismantled within Core's resource boundary.
    ///
    /// # Errors
    ///
    /// Returns [`BuildError::ForeignBinder`] when `parameter` was produced by
    /// another Core builder, after reporting any payload resource failure.
    pub fn function(
        &mut self,
        parameter: TypedBinder,
        body: NodeId,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        let (ty, origin, result_rewrite) =
            match admit_payloads(ty, origin, &mut self.type_work, F::ALLOWS_EFFECTFUL_TYPES) {
                Ok(payloads) => payloads,
                Err(error) => {
                    parameter.discard_metadata();
                    return Err(error);
                }
            };
        if self.arena != Some(parameter.arena()) {
            parameter.discard_metadata();
            discard_admitted_payload(ty, origin);
            return Err(BuildError::ForeignBinder);
        }
        let binder_rewrite = self.inference_binders.contains(&parameter.id());
        self.push_admitted_tracking(
            ty,
            origin,
            PureExprKind::Value(PureValue::Function(FunctionNode::new(parameter, body))),
            binder_rewrite || result_rewrite,
        )
    }

    /// Adds a sequential binding with an unchecked result annotation.
    ///
    /// Payload admission precedes the binder-capability check, so rejected
    /// recursive payloads are dismantled within Core's resource boundary.
    ///
    /// # Errors
    ///
    /// Returns [`BuildError::ForeignBinder`] when `binder` was produced by
    /// another Core builder, after reporting any payload resource failure.
    pub fn binding(
        &mut self,
        binder: TypedBinder,
        initializer: NodeId,
        body: NodeId,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        let (ty, origin, result_rewrite) =
            match admit_payloads(ty, origin, &mut self.type_work, F::ALLOWS_EFFECTFUL_TYPES) {
                Ok(payloads) => payloads,
                Err(error) => {
                    binder.discard_metadata();
                    return Err(error);
                }
            };
        if self.arena != Some(binder.arena()) {
            binder.discard_metadata();
            discard_admitted_payload(ty, origin);
            return Err(BuildError::ForeignBinder);
        }
        let binder_rewrite = self.inference_binders.contains(&binder.id());
        self.push_admitted_tracking(
            ty,
            origin,
            PureExprKind::Computation(PureComputation::Bind(BindingNode::new(
                binder,
                initializer,
                body,
            ))),
            binder_rewrite || result_rewrite,
        )
    }

    /// Adds a simultaneous recursive binding group with unchecked invariants.
    ///
    /// Payload admission precedes binder-capability checks. The independent
    /// validator owns nonemptiness, function-or-guarded-data initializer,
    /// type, scope, and provenance invariants.
    ///
    /// # Errors
    ///
    /// Returns [`BuildError::ForeignBinder`] when any member binder was
    /// produced by another Core builder, after reporting any payload resource
    /// failure.
    pub fn recursive_binding(
        &mut self,
        members: Vec<(TypedBinder, NodeId)>,
        body: NodeId,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        let (ty, origin, result_rewrite) =
            match admit_payloads(ty, origin, &mut self.type_work, F::ALLOWS_EFFECTFUL_TYPES) {
                Ok(payloads) => payloads,
                Err(error) => {
                    discard_recursive_binding_inputs(members);
                    return Err(error);
                }
            };
        if members
            .iter()
            .any(|(binder, _)| self.arena != Some(binder.arena()))
        {
            discard_recursive_binding_inputs(members);
            discard_admitted_payload(ty, origin);
            return Err(BuildError::ForeignBinder);
        }
        let binder_rewrite = members
            .iter()
            .any(|(binder, _)| self.inference_binders.contains(&binder.id()));
        let members = members
            .into_iter()
            .map(|(binder, initializer)| RecursiveBindingMember::new(binder, initializer))
            .collect();
        self.push_admitted_tracking(
            ty,
            origin,
            PureExprKind::Computation(PureComputation::RecursiveBind(RecursiveBindingNode::new(
                members, body,
            ))),
            binder_rewrite || result_rewrite,
        )
    }

    /// Adds a strict unary application with an unchecked result annotation.
    pub fn application(
        &mut self,
        function: NodeId,
        argument: NodeId,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        self.push(
            ty,
            origin,
            PureExprKind::Computation(PureComputation::Apply(ApplicationNode::new(
                function, argument,
            ))),
        )
    }

    pub(crate) fn application_with_effects(
        &mut self,
        application: ApplicationNode,
        ty: Type,
        effects: EffectRow,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        if F::REQUIRES_EMPTY_ROWS {
            assert!(effects.is_empty(), "pure application row");
            return self.application(application.function(), application.argument(), ty, origin);
        }
        let kind = PureExprKind::Computation(PureComputation::Apply(application));
        self.push_explicit_kind(ty, effects, origin, || F::from_pure(kind))
    }

    /// Adds an unchecked explicit type abstraction.
    pub fn type_abstraction(
        &mut self,
        parameters: Vec<(TypeVariableId, Kind)>,
        body: NodeId,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        let parameter_admission = charge_kinded_type_parameters(&parameters, &mut self.type_work)
            .map(|()| parameters)
            .map_err(|()| BuildError::TypeWorkExceeded);
        self.type_abstraction_after_parameter_admission(parameter_admission, body, ty, origin)
    }

    pub(super) fn type_abstraction_from_borrowed(
        &mut self,
        parameters: &[(TypeVariableId, Kind)],
        body: NodeId,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        let parameter_admission =
            clone_kinded_type_parameters_with_budget(parameters, &mut self.type_work)
                .map_err(|()| BuildError::TypeWorkExceeded);
        self.type_abstraction_after_parameter_admission(parameter_admission, body, ty, origin)
    }

    fn type_abstraction_after_parameter_admission(
        &mut self,
        parameter_admission: Result<Vec<(TypeVariableId, Kind)>, BuildError>,
        body: NodeId,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        let payloads = admit_payloads(ty, origin, &mut self.type_work, F::ALLOWS_EFFECTFUL_TYPES);
        let (parameters, ty, origin, requires_type_rewrite) = match (parameter_admission, payloads)
        {
            (Err(error), Ok((ty, origin, _))) => {
                discard_admitted_payload(ty, origin);
                return Err(error);
            }
            (Err(error), Err(_)) | (Ok(_), Err(error)) => return Err(error),
            (Ok(parameters), Ok((ty, origin, requires_type_rewrite))) => {
                (parameters, ty, origin, requires_type_rewrite)
            }
        };
        self.push_admitted_tracking(
            ty,
            origin,
            PureExprKind::Computation(PureComputation::TypeAbstraction(TypeAbstractionNode::new(
                parameters, body,
            ))),
            requires_type_rewrite,
        )
    }

    pub(super) fn clone_type_for_rebuild(&mut self, ty: &Type) -> Result<Type, BuildError> {
        clone_type_with_budget(ty, &mut self.type_work).map_err(|()| BuildError::TypeWorkExceeded)
    }

    pub(super) fn clone_owner_argument_for_rebuild(
        &mut self,
        argument: &crate::types::KindedArgument,
    ) -> Result<crate::types::KindedArgument, BuildError> {
        crate::types::clone_kinded_argument_with_budget(argument, &mut self.type_work)
            .map_err(|()| BuildError::TypeWorkExceeded)
    }

    pub(super) fn clone_effect_row_for_rebuild(
        &mut self,
        row: &EffectRow,
    ) -> Result<EffectRow, BuildError> {
        clone_effect_row_with_budget(row, &mut self.type_work)
            .map_err(|()| BuildError::TypeWorkExceeded)
    }

    fn admit_owner_arguments(
        &mut self,
        arguments: Box<[crate::types::KindedArgument]>,
    ) -> Result<Box<[crate::types::KindedArgument]>, BuildError> {
        let owned = IterativeArgumentBuffer(arguments.into_vec());
        self.type_work
            .charge(owned.0.len())
            .map_err(|()| BuildError::TypeWorkExceeded)?;
        let (contains_inference, normalize) = scan_type_admission(
            TypeAdmissionTask::Owner(&owned.0, 0),
            &mut self.type_work,
            true,
            F::ALLOWS_EFFECTFUL_TYPES,
        )?;
        self.requires_type_rewrite |= contains_inference;
        if normalize {
            let mut normalized = IterativeArgumentBuffer(Vec::new());
            normalized
                .0
                .try_reserve_exact(owned.0.len())
                .map_err(|_| BuildError::TypeWorkExceeded)?;
            for argument in &owned.0 {
                normalized.0.push(
                    crate::types::clone_kinded_argument_with_budget(argument, &mut self.type_work)
                        .map_err(|()| BuildError::TypeWorkExceeded)?,
                );
            }
            Ok(normalized.into_boxed_slice())
        } else {
            Ok(owned.into_boxed_slice())
        }
    }

    pub(super) fn admit_provider_state_access_arguments(
        &mut self,
        arguments: Box<[crate::types::KindedArgument]>,
    ) -> Result<Box<[crate::types::KindedArgument]>, BuildError> {
        self.admit_owner_arguments(arguments)
    }

    pub(super) fn admit_effect_instance(
        &mut self,
        instance: crate::types::EffectInstance,
    ) -> Result<crate::types::EffectInstance, BuildError> {
        self.type_work
            .charge(instance.arguments().len())
            .map_err(|()| BuildError::TypeWorkExceeded)?;
        let (contains_inference, normalize) = scan_type_admission(
            TypeAdmissionTask::Owner(instance.arguments(), 0),
            &mut self.type_work,
            false,
            F::ALLOWS_EFFECTFUL_TYPES,
        )?;
        if contains_inference {
            return Err(BuildError::InvalidPayload);
        }
        if normalize {
            crate::types::clone_effect_instance_with_budget(&instance, &mut self.type_work)
                .map_err(|()| BuildError::TypeWorkExceeded)
        } else {
            Ok(instance)
        }
    }

    pub(super) fn admit_effect_clause_arm(
        &mut self,
        arm: CoreMatchArm,
    ) -> Result<CoreMatchArm, BuildError> {
        let (arm, requires_type_rewrite) = admit_match_arm(
            arm,
            &mut self.type_work,
            &self.inference_binders,
            F::ALLOWS_EFFECTFUL_TYPES,
        )?;
        self.requires_type_rewrite |= requires_type_rewrite;
        Ok(arm)
    }

    pub(super) fn charge_effect_metadata(&mut self, cells: usize) -> Result<(), BuildError> {
        self.type_work
            .charge(cells)
            .map_err(|()| BuildError::TypeWorkExceeded)
    }

    pub(super) fn clone_interface_application_for_rebuild(
        &mut self,
        application: &InterfaceApplication,
    ) -> Result<InterfaceApplication, BuildError> {
        application
            .clone_with_budget(&mut self.type_work)
            .map_err(|()| BuildError::TypeWorkExceeded)
    }

    #[cfg(test)]
    pub(super) fn charge_type_work_for_test(&mut self, work: usize) -> Result<(), BuildError> {
        self.type_work
            .charge(work)
            .map_err(|()| BuildError::TypeWorkExceeded)
    }

    /// Adds an unchecked explicit type application.
    pub fn type_application(
        &mut self,
        function: NodeId,
        arguments: Vec<Type>,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        self.type_application_with_row_arguments(function, arguments, Vec::new(), ty, origin)
    }

    pub(crate) fn type_application_with_row_arguments(
        &mut self,
        function: NodeId,
        arguments: Vec<Type>,
        row_arguments: Vec<EffectRow>,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        if !F::ALLOWS_EFFECTFUL_TYPES && !row_arguments.is_empty() {
            let mut arguments = arguments;
            discard_type_vector_iteratively(&mut arguments);
            discard_type_iteratively(ty);
            discard_origin_iteratively(origin);
            return Err(BuildError::InvalidPayload);
        }
        let mut admitted_arguments = Vec::new();
        let mut first_error = None;
        let mut argument_rewrite = !row_arguments.is_empty();
        for argument in arguments {
            match admit_type_with_status(
                argument,
                &mut self.type_work,
                true,
                F::ALLOWS_EFFECTFUL_TYPES,
            ) {
                Ok((argument, contains_inference)) if first_error.is_none() => {
                    argument_rewrite |= contains_inference;
                    admitted_arguments.push(argument);
                }
                Ok((argument, _)) => discard_type_iteratively(argument),
                Err(error) => {
                    first_error.get_or_insert(error);
                }
            }
        }
        for row in &row_arguments {
            if charge_effect_row_cells(row, &mut self.type_work).is_err() {
                first_error.get_or_insert(BuildError::TypeWorkExceeded);
            }
        }
        let payloads = admit_payloads(ty, origin, &mut self.type_work, F::ALLOWS_EFFECTFUL_TYPES);
        let (ty, origin, result_rewrite) = match (first_error, payloads) {
            (Some(error), Ok((ty, origin, _))) => {
                discard_type_vector_iteratively(&mut admitted_arguments);
                discard_admitted_payload(ty, origin);
                return Err(error);
            }
            (Some(error), Err(_)) => {
                discard_type_vector_iteratively(&mut admitted_arguments);
                return Err(error);
            }
            (None, Err(error)) => {
                discard_type_vector_iteratively(&mut admitted_arguments);
                return Err(error);
            }
            (None, Ok(payloads)) => payloads,
        };
        self.push_admitted_tracking(
            ty,
            origin,
            PureExprKind::Computation(PureComputation::TypeApplication(
                TypeApplicationNode::new_with_row_arguments(
                    function,
                    admitted_arguments,
                    row_arguments,
                ),
            )),
            argument_rewrite || result_rewrite,
        )
    }

    /// Adds a primitive operation with an unchecked result annotation.
    pub fn primitive(
        &mut self,
        primitive: Primitive,
        left: NodeId,
        right: NodeId,
        ty: Type,
        origin: Origin,
    ) -> Result<NodeId, BuildError> {
        self.push(
            ty,
            origin,
            PureExprKind::Computation(PureComputation::Primitive(PrimitiveNode::new(
                primitive, left, right,
            ))),
        )
    }

    /// Records that an existing node successfully checked against an expected
    /// type whose source cause is optional.
    ///
    /// # Errors
    ///
    /// Returns [`BuildError::InvalidNodeId`] unless `node` belongs to this
    /// builder, or an origin resource error if the causal wrapper is too deep.
    pub(crate) fn record_type_check(
        &mut self,
        node: NodeId,
        expected_cause: Option<Span>,
    ) -> Result<(), BuildError> {
        let Some(arena) = self.arena else {
            return Err(BuildError::InvalidNodeId);
        };
        if node.arena() != arena {
            return Err(BuildError::InvalidNodeId);
        }
        let index = node.index()?;
        let stored = self.nodes.get(index).ok_or(BuildError::InvalidNodeId)?;
        let Some(current) = stored.origin.as_ref() else {
            return Err(BuildError::InvalidPayload);
        };
        let cause = match expected_cause {
            Some(span) if span.source() == current.primary_span().source() => Origin::Related {
                primary: Box::new(current.clone()),
                related: vec![span],
            },
            Some(_) | None => current.clone(),
        };
        let origin = admit_origin(Origin::Generated {
            cause: Box::new(cause),
            reason: GeneratedReason::TypeChecking,
        })?;
        replace_origin_iteratively(&mut self.nodes[index].origin, origin);
        Ok(())
    }

    /// Rewrites every stored type before unchecked Core leaves elaboration.
    ///
    /// The rewrite callback owns cumulative structural construction work. Core
    /// rechecks depth and cumulatively charges the quantifier identities added
    /// to rewritten storage.
    #[cfg_attr(
        not(test),
        allow(
            dead_code,
            reason = "the complete-arena rewrite seam is retained for its focused Core tests"
        )
    )]
    pub(crate) fn rewrite_types<R>(&mut self, mut rewrite: R) -> Result<(), BuildError>
    where
        R: FnMut(&Type) -> Result<Type, BuildError>,
    {
        let checkpoint = TypeRewriteCheckpoint(0);
        let rewritten_requires_type_rewrite =
            self.rewrite_types_from(checkpoint, &mut rewrite, None)?;
        self.requires_type_rewrite = rewritten_requires_type_rewrite;
        Ok(())
    }

    /// Captures the current end of the Core arena for a bounded type rewrite.
    pub(crate) fn type_rewrite_checkpoint(&self) -> TypeRewriteCheckpoint {
        TypeRewriteCheckpoint(self.nodes.len())
    }

    /// Captures an elaboration-local construction boundary.
    pub(crate) fn checkpoint(&self) -> CoreBuilderCheckpoint {
        CoreBuilderCheckpoint {
            nodes: self.nodes.len(),
            next_binder: self.next_binder,
            binder_phase_started: self.binder_phase_started,
            requires_type_rewrite: self.requires_type_rewrite,
        }
    }

    /// Discards every node and generated binder appended after `checkpoint`.
    pub(crate) fn rollback(&mut self, checkpoint: CoreBuilderCheckpoint) {
        debug_assert!(checkpoint.nodes <= self.nodes.len());
        while self.nodes.len() > checkpoint.nodes {
            let stored = self
                .nodes
                .pop()
                .expect("the checkpoint suffix is non-empty");
            discard_type_iteratively(stored.ty);
            F::discard_effects(stored.effects);
            if let Some(origin) = stored.origin {
                discard_origin_iteratively(origin);
            }
            F::discard_metadata(stored.kind);
        }
        self.generated_binders.retain(|identity| {
            !matches!(identity, BinderId::Generated(local) if *local >= checkpoint.next_binder)
        });
        self.inference_binders.retain(|identity| {
            !matches!(identity, BinderId::Generated(local) if *local >= checkpoint.next_binder)
        });
        self.next_binder = checkpoint.next_binder;
        self.binder_phase_started = checkpoint.binder_phase_started;
        self.requires_type_rewrite = checkpoint.requires_type_rewrite;
    }

    pub(crate) fn rewrite_types_and_rows<R, Q>(
        &mut self,
        checkpoint: Option<TypeRewriteCheckpoint>,
        mut rewrite: R,
        mut rewrite_row: Q,
    ) -> Result<(), BuildError>
    where
        R: FnMut(&Type) -> Result<Type, BuildError>,
        Q: FnMut(&EffectRow) -> Result<EffectRow, BuildError>,
    {
        let rewritten_requires_type_rewrite = self.rewrite_types_from(
            checkpoint.unwrap_or(TypeRewriteCheckpoint(0)),
            &mut rewrite,
            Some(&mut rewrite_row),
        )?;
        self.requires_type_rewrite =
            checkpoint.is_some() && self.requires_type_rewrite || rewritten_requires_type_rewrite;
        Ok(())
    }

    #[allow(
        clippy::type_complexity,
        reason = "the optional row callback keeps the shared rewrite traversal local"
    )]
    fn rewrite_types_from<R>(
        &mut self,
        checkpoint: TypeRewriteCheckpoint,
        rewrite: &mut R,
        mut rewrite_row: Option<&mut dyn FnMut(&EffectRow) -> Result<EffectRow, BuildError>>,
    ) -> Result<bool, BuildError>
    where
        R: FnMut(&Type) -> Result<Type, BuildError>,
    {
        let nodes = self
            .nodes
            .get_mut(checkpoint.0..)
            .ok_or(BuildError::InvalidNodeId)?;
        let rewrite_type_work = &mut self.rewrite_type_work;
        let mut rewritten_requires_type_rewrite = false;
        macro_rules! rewrite_admitted {
            ($ty:expr) => {{
                let rewritten = rewrite($ty)?;
                let (rewritten, contains_inference) =
                    admit_rewritten_type(rewritten, rewrite_type_work, F::ALLOWS_EFFECTFUL_TYPES)?;
                rewritten_requires_type_rewrite |= contains_inference;
                Ok::<Type, BuildError>(rewritten)
            }};
        }
        for node in nodes {
            let rewritten = rewrite_admitted!(&node.ty)?;
            replace_type_iteratively(&mut node.ty, rewritten);
            if let Some(rewrite_row) = rewrite_row.as_deref_mut()
                && !F::effect_row(&node.effects).is_empty()
            {
                let effects = rewrite_row(F::effect_row(&node.effects))?;
                charge_effect_row_cells(&effects, rewrite_type_work)
                    .map_err(|()| BuildError::TypeWorkExceeded)?;
                node.effects = F::store_effects(effects);
            }
            {
                let work = std::cell::RefCell::new(&mut *rewrite_type_work);
                F::rewrite_operation_type_metadata(
                    &mut node.kind,
                    &mut |ty| {
                        let rewritten = rewrite(ty)?;
                        let (rewritten, contains_inference) = admit_rewritten_type(
                            rewritten,
                            &mut work.borrow_mut(),
                            F::ALLOWS_EFFECTFUL_TYPES,
                        )?;
                        rewritten_requires_type_rewrite |= contains_inference;
                        Ok(rewritten)
                    },
                    &mut |cells| {
                        work.borrow_mut()
                            .charge(cells)
                            .map_err(|()| BuildError::TypeWorkExceeded)
                    },
                )?;
            }
            let Some(kind) = F::pure_mut(&mut node.kind) else {
                continue;
            };
            match kind {
                PureExprKind::Value(PureValue::Function(function)) => {
                    function
                        .parameter_mut()
                        .rewrite_type(&mut |ty| rewrite_admitted!(ty))?;
                }
                PureExprKind::Computation(PureComputation::Bind(binding)) => {
                    binding
                        .binder_mut()
                        .rewrite_type(&mut |ty| rewrite_admitted!(ty))?;
                }
                PureExprKind::Computation(PureComputation::RecursiveBind(group)) => {
                    for member in group.members_mut() {
                        member
                            .binder_mut()
                            .rewrite_type(&mut |ty| rewrite_admitted!(ty))?;
                    }
                }
                PureExprKind::Computation(PureComputation::Match(match_expression)) => {
                    for arm in match_expression.arms_mut() {
                        arm.pattern_mut()
                            .rewrite_types(&mut |ty| rewrite_admitted!(ty))?;
                    }
                }
                PureExprKind::Computation(PureComputation::TypeApplication(application)) => {
                    application.rewrite_types(&mut |ty| rewrite_admitted!(ty))?;
                    if let Some(rewrite_row) = rewrite_row.as_deref_mut() {
                        application.rewrite_row_arguments(&mut |row| {
                            let rewritten = rewrite_row(row)?;
                            charge_effect_row_cells(&rewritten, rewrite_type_work)
                                .map_err(|()| BuildError::TypeWorkExceeded)?;
                            Ok(rewritten)
                        })?;
                    }
                }
                PureExprKind::Value(
                    PureValue::Integer(_)
                    | PureValue::String(_)
                    | PureValue::Intrinsic(_)
                    | PureValue::Boolean(_)
                    | PureValue::Unit(_)
                    | PureValue::Constructor(_),
                )
                | PureExprKind::Variable(_)
                | PureExprKind::Computation(
                    PureComputation::Apply(_)
                    | PureComputation::Primitive(_)
                    | PureComputation::Tuple(_)
                    | PureComputation::NewtypeConversion(_)
                    | PureComputation::LocalNominalScope(_)
                    | PureComputation::TypeAbstraction(_),
                ) => {}
            }
        }
        Ok(rewritten_requires_type_rewrite)
    }

    /// Reports whether admitted types or pending cleanup-derived rows need rewriting.
    pub(crate) fn requires_type_rewrite(&self) -> bool {
        self.requires_type_rewrite || !self.deferred_cleanup_rows.is_empty()
    }

    /// Charges the new retained-draft final consumption scan to its caller.
    /// Prior builder work has already been discharged at each rebuild step.
    pub(crate) fn finish_provider_draft(
        mut self,
        root: NodeId,
        work: &mut TypeWorkBudget,
    ) -> Result<UnvalidatedCoreProgram<F>, BuildError> {
        let finish_work = self.consumed_method_evidence.len();
        work.charge(finish_work)
            .map_err(|()| BuildError::TypeWorkExceeded)?;
        self.type_work = TypeWorkBudget::with_limit(finish_work);
        self.finish(root)
    }

    pub(crate) fn provider_node_at_ordinal(
        &self,
        root: NodeId,
        ordinal: usize,
    ) -> Result<NodeId, BuildError> {
        if self.arena != Some(root.arena()) || ordinal >= self.nodes.len() {
            return Err(BuildError::InvalidNodeId);
        }
        Ok(NodeId::new(
            root.arena(),
            u32::try_from(ordinal).map_err(|_| BuildError::InvalidNodeId)?,
        ))
    }

    #[allow(clippy::type_complexity)] // Borrowed arena, nodes and original catalog form one view.
    pub(in crate::core) fn provider_projection_parts(
        &self,
    ) -> Result<(ArenaId, &[StoredNode<F>], &Arc<MethodEvidenceCatalog>), BuildError> {
        Ok((
            self.arena.ok_or(BuildError::InvalidNodeId)?,
            &self.nodes,
            &self.method_evidence,
        ))
    }

    pub(in crate::core) fn provider_projection_anchors(&self) -> &[MethodEvidenceAnchor] {
        &self.method_evidence_anchors
    }

    /// Borrows a preparation node. The caller charges node and edge traversal;
    /// this view grants no validation or executable admission.
    pub(crate) fn compiler_node_kind(&self, node: NodeId) -> Result<&F::Kind, BuildError> {
        if self.arena != Some(node.arena()) {
            return Err(BuildError::InvalidNodeId);
        }
        self.nodes
            .get(node.index()?)
            .map(|stored| &stored.kind)
            .ok_or(BuildError::InvalidNodeId)
    }

    /// Borrows the immutable final catalogue; this view grants no admission.
    pub(crate) fn provider_method_catalog(&self) -> &Arc<MethodEvidenceCatalog> {
        &self.method_evidence
    }

    /// Finishes unchecked construction at `root`.
    ///
    /// # Errors
    ///
    /// Returns [`BuildError::InvalidNodeId`] unless `root` belongs to this arena.
    /// Returns [`BuildError::InvalidPayload`] while source cleanup row equations
    /// remain unfinished.
    pub fn finish(mut self, root: NodeId) -> Result<UnvalidatedCoreProgram<F>, BuildError> {
        if !self.deferred_cleanup_rows.is_empty() {
            return Err(BuildError::InvalidPayload);
        }
        let Some(arena) = self.arena else {
            return Err(BuildError::InvalidNodeId);
        };
        if root.arena() != arena {
            return Err(BuildError::InvalidNodeId);
        }
        let index = root.index()?;
        if index >= self.nodes.len() {
            return Err(BuildError::InvalidNodeId);
        }
        self.type_work
            .charge(self.consumed_method_evidence.len())
            .map_err(|()| BuildError::TypeWorkExceeded)?;
        if self
            .consumed_method_evidence
            .iter()
            .any(|consumed| !consumed)
        {
            return Err(BuildError::InvalidPayload);
        }
        Ok(UnvalidatedCoreProgram {
            registry: std::mem::replace(&mut self.registry, Arc::clone(empty_registry())),
            method_evidence: std::mem::replace(
                &mut self.method_evidence,
                Arc::clone(empty_method_evidence()),
            ),
            method_evidence_anchors: std::mem::take(&mut self.method_evidence_anchors)
                .into_boxed_slice(),
            arena,
            nodes: std::mem::take(&mut self.nodes),
            root,
        })
    }

    pub(crate) fn charge_rebuild_work(&mut self, work: usize) -> Result<(), BuildError> {
        self.type_work
            .charge(work)
            .map_err(|()| BuildError::TypeWorkExceeded)
    }

    fn push(&mut self, ty: Type, origin: Origin, kind: PureExprKind) -> Result<NodeId, BuildError> {
        let (ty, origin, requires_type_rewrite) =
            admit_payloads(ty, origin, &mut self.type_work, F::ALLOWS_EFFECTFUL_TYPES)?;
        self.push_admitted_tracking(ty, origin, kind, requires_type_rewrite)
    }

    fn push_admitted_tracking(
        &mut self,
        ty: Type,
        origin: Origin,
        kind: PureExprKind,
        requires_type_rewrite: bool,
    ) -> Result<NodeId, BuildError> {
        let node = self.push_admitted(ty, origin, kind)?;
        self.requires_type_rewrite |= requires_type_rewrite;
        Ok(node)
    }

    fn push_admitted(
        &mut self,
        ty: Type,
        origin: Origin,
        kind: PureExprKind,
    ) -> Result<NodeId, BuildError> {
        let effects = match self.infer_pure_effects(&kind) {
            Ok(effects) => effects,
            Err(error) => {
                discard_pending_node_payload(ty, origin, kind);
                return Err(error);
            }
        };
        let index = match u32::try_from(self.nodes.len()) {
            Ok(index) => index,
            Err(_) => {
                discard_pending_node_payload(ty, origin, kind);
                return Err(BuildError::NodeIdExhausted);
            }
        };
        let arena = match self.ensure_arena() {
            Ok(arena) => arena,
            Err(error) => {
                discard_pending_node_payload(ty, origin, kind);
                return Err(error);
            }
        };
        self.nodes.push(StoredNode {
            dialect: DialectId(F::DIALECT_NAME),
            ty,
            effects: F::store_effects(effects),
            origin: Some(origin),
            kind: F::from_pure(kind),
        });
        Ok(NodeId::new(arena, index))
    }

    fn infer_pure_effects(&mut self, kind: &PureExprKind) -> Result<EffectRow, BuildError> {
        if F::REQUIRES_EMPTY_ROWS || !matches!(kind, PureExprKind::Computation(_)) {
            return Ok(EffectRow::empty());
        }
        let mut effects = EffectRow::empty();
        for child_index in 0..kind.child_count() {
            let child = kind
                .child_at(child_index)
                .ok_or(BuildError::InvalidPayload)?;
            if self.arena != Some(child.arena()) {
                return Err(BuildError::InvalidNodeId);
            }
            let child = child.index()?;
            let row = F::effect_row(
                &self
                    .nodes
                    .get(child)
                    .ok_or(BuildError::InvalidNodeId)?
                    .effects,
            );
            if self.is_deferred_cleanup_row(&effects) || self.is_deferred_cleanup_row(row) {
                if self.is_deferred_cleanup_row(row) {
                    effects = clone_effect_row_with_budget(row, &mut self.type_work)
                        .map_err(|_| BuildError::TypeWorkExceeded)?;
                }
                continue;
            }
            effects = effects
                .union_with_budget(row, &mut self.type_work)
                .map_err(|()| BuildError::TypeWorkExceeded)?
                .map_err(|_| BuildError::InvalidPayload)?;
        }
        if let PureExprKind::Computation(PureComputation::Apply(application)) = kind {
            if self.arena != Some(application.function().arena()) {
                return Err(BuildError::InvalidNodeId);
            }
            let function = application.function().index()?;
            let function = self.nodes.get(function).ok_or(BuildError::InvalidNodeId)?;
            if let Type::EffectfulFunction(_, codomain) = &function.ty {
                if self.is_deferred_cleanup_row(&effects)
                    || self.is_deferred_cleanup_row(codomain.effects())
                {
                    return clone_effect_row_with_budget(codomain.effects(), &mut self.type_work)
                        .map_err(|_| BuildError::TypeWorkExceeded);
                }
                effects = effects
                    .union_with_budget(codomain.effects(), &mut self.type_work)
                    .map_err(|()| BuildError::TypeWorkExceeded)?
                    .map_err(|_| BuildError::InvalidPayload)?;
            }
        }
        Ok(effects)
    }

    fn is_deferred_cleanup_row(&self, row: &EffectRow) -> bool {
        row.tail().is_some_and(|tail| match tail.variable() {
            EffectRowVariable::Inference(id) => self.deferred_cleanup_rows.contains(&id),
            _ => false,
        })
    }

    pub(crate) fn defer_cleanup_row(
        &mut self,
        id: crate::types::InferenceVariableId,
    ) -> Result<(), BuildError> {
        self.type_work
            .charge(1)
            .map_err(|_| BuildError::TypeWorkExceeded)?;
        self.deferred_cleanup_rows
            .try_reserve(1)
            .map_err(|_| BuildError::TypeWorkExceeded)?;
        self.deferred_cleanup_rows.insert(id);
        Ok(())
    }

    pub(crate) fn finish_cleanup_rows(&mut self) {
        self.deferred_cleanup_rows.clear();
    }

    pub(crate) fn forget_cleanup_row(&mut self, id: crate::types::InferenceVariableId) {
        self.deferred_cleanup_rows.remove(&id);
    }

    /// A committed row solution must rewrite effect metadata even when the
    /// previous type rewrite found no remaining type inference.
    pub(crate) fn complete_cleanup_row(&mut self, id: crate::types::InferenceVariableId) {
        self.deferred_cleanup_rows.remove(&id);
        self.requires_type_rewrite = true;
    }

    pub(crate) fn push_operation(
        &mut self,
        ty: Type,
        effects: EffectRow,
        origin: Origin,
        operation: F::Operation,
    ) -> Result<NodeId, BuildError> {
        self.push_explicit_kind(ty, effects, origin, || F::from_operation(operation))
    }

    fn push_explicit_kind(
        &mut self,
        ty: Type,
        effects: EffectRow,
        origin: Origin,
        kind: impl FnOnce() -> F::Kind,
    ) -> Result<NodeId, BuildError> {
        let (ty, origin, requires_type_rewrite) =
            admit_payloads(ty, origin, &mut self.type_work, F::ALLOWS_EFFECTFUL_TYPES)?;
        if charge_effect_row_cells(&effects, &mut self.type_work).is_err() {
            discard_admitted_payload(ty, origin);
            drop(effects);
            return Err(BuildError::TypeWorkExceeded);
        }
        let index = match u32::try_from(self.nodes.len()) {
            Ok(index) => index,
            Err(_) => {
                discard_admitted_payload(ty, origin);
                drop(effects);
                return Err(BuildError::NodeIdExhausted);
            }
        };
        let arena = match self.ensure_arena() {
            Ok(arena) => arena,
            Err(error) => {
                discard_admitted_payload(ty, origin);
                drop(effects);
                return Err(error);
            }
        };
        self.nodes.push(StoredNode {
            dialect: DialectId(F::DIALECT_NAME),
            ty,
            effects: F::store_effects(effects),
            origin: Some(origin),
            kind: kind(),
        });
        self.requires_type_rewrite |= requires_type_rewrite;
        Ok(NodeId::new(arena, index))
    }

    /// Recognizes an immediately selected constructor through type applications.
    /// This query reports syntax identity; it grants no lifecycle authority.
    pub(crate) fn direct_constructor(
        &mut self,
        mut node: NodeId,
    ) -> Result<Option<crate::types::ConstructorId>, BuildError> {
        loop {
            self.type_work
                .charge(1)
                .map_err(|()| BuildError::TypeWorkExceeded)?;
            if self.arena != Some(node.arena()) {
                return Err(BuildError::InvalidNodeId);
            }
            let stored = self
                .nodes
                .get(node.index().map_err(|_| BuildError::InvalidNodeId)?)
                .ok_or(BuildError::InvalidNodeId)?;
            match F::pure(&stored.kind) {
                Some(PureExprKind::Value(PureValue::Constructor(constructor))) => {
                    return Ok(Some(constructor.constructor()));
                }
                Some(PureExprKind::Computation(PureComputation::TypeApplication(application))) => {
                    node = application.function()
                }
                _ => return Ok(None),
            }
        }
    }

    pub(crate) const fn node_checkpoint(&self) -> usize {
        self.nodes.len()
    }

    /// Copies a constructed body's row for generated continuation arrows.
    pub(crate) fn clone_node_effects_with_budget(
        &self,
        node: NodeId,
        budget: &mut TypeWorkBudget,
    ) -> Result<EffectRow, BuildError> {
        budget
            .charge(1)
            .map_err(|()| BuildError::TypeWorkExceeded)?;
        if self.arena != Some(node.arena()) {
            return Err(BuildError::InvalidNodeId);
        }
        let expression = self
            .nodes
            .get(node.index()?)
            .ok_or(BuildError::InvalidNodeId)?;
        clone_effect_row_with_budget(F::effect_row(&expression.effects), budget)
            .map_err(|()| BuildError::TypeWorkExceeded)
    }

    pub(super) fn infer_pure_effects_at(&mut self, index: usize) -> Result<EffectRow, BuildError> {
        let kind = F::pure(&self.nodes.get(index).ok_or(BuildError::InvalidNodeId)?.kind)
            .ok_or(BuildError::InvalidPayload)?;
        if F::REQUIRES_EMPTY_ROWS || !matches!(kind, PureExprKind::Computation(_)) {
            return Ok(EffectRow::empty());
        }
        let child_count = kind.child_count();
        let application_function = match kind {
            PureExprKind::Computation(PureComputation::Apply(application)) => {
                Some(application.function())
            }
            _ => None,
        };
        let mut effects = EffectRow::empty();
        for child_index in 0..child_count {
            let child = F::pure(&self.nodes[index].kind)
                .and_then(|kind| kind.child_at(child_index))
                .ok_or(BuildError::InvalidPayload)?;
            let child = child.index()?;
            effects = effects
                .union_with_budget(
                    F::effect_row(
                        &self
                            .nodes
                            .get(child)
                            .ok_or(BuildError::InvalidNodeId)?
                            .effects,
                    ),
                    &mut self.type_work,
                )
                .map_err(|()| BuildError::TypeWorkExceeded)?
                .map_err(|_| BuildError::InvalidPayload)?;
        }
        if let Some(function) = application_function {
            let function = self
                .nodes
                .get(function.index()?)
                .ok_or(BuildError::InvalidNodeId)?;
            if let Type::EffectfulFunction(_, codomain) = &function.ty {
                // Recomputing cleanup-dependent ancestors must not erase the
                // lexical lacks attached when this application was elaborated.
                // They are provisional builder facts: independent validation
                // authenticates them against the enclosing forall contract.
                let reported = F::effect_row(&self.nodes[index].effects);
                let callable = match (codomain.effects().tail(), reported.tail()) {
                    (Some(tail), Some(previous)) if tail.variable() == previous.variable() => {
                        crate::types::rebuild_effect_row_with_budget(
                            codomain.effects().known(),
                            Some(tail.variable()),
                            tail.lacks().iter().chain(previous.lacks()),
                            crate::types::clone_type_with_budget,
                            &mut self.type_work,
                        )
                        .map_err(|()| BuildError::TypeWorkExceeded)?
                    }
                    _ => clone_effect_row_with_budget(codomain.effects(), &mut self.type_work)
                        .map_err(|()| BuildError::TypeWorkExceeded)?,
                };
                effects = effects
                    .union_with_budget(&callable, &mut self.type_work)
                    .map_err(|()| BuildError::TypeWorkExceeded)?
                    .map_err(|_| BuildError::InvalidPayload)?;
            }
        }
        Ok(effects)
    }

    fn ensure_arena(&mut self) -> Result<ArenaId, BuildError> {
        if let Some(arena) = self.arena {
            return Ok(arena);
        }
        let arena = ARENA_IDS.allocate()?;
        self.arena = Some(arena);
        Ok(arena)
    }

    fn next_binder_candidate(&self) -> Result<(BinderId, u32), BuildError> {
        let mut candidate = self.next_binder;
        loop {
            let id = BinderId::new(candidate);
            let next = candidate
                .checked_add(1)
                .ok_or(BuildError::BinderIdExhausted)?;
            if !self.reserved_resolved.contains(&id) && !self.generated_binders.contains(&id) {
                return Ok((id, next));
            }
            candidate = next;
        }
    }
}

impl CoreBuilder<super::effect::EffectOperationFamily> {
    /// Transfers the exact unfinished row owner with a private conditional forest.
    /// Ordinary finish and ordinary independent validation retain their guards.
    pub(crate) fn finish_provider_conditional_draft(
        mut self,
        root: NodeId,
        pending: super::provider::HandlerPendingRows,
        work: &mut TypeWorkBudget,
    ) -> Result<
        (
            UnvalidatedCoreProgram<super::effect::EffectOperationFamily>,
            super::provider::HandlerPendingRows,
        ),
        BuildError,
    > {
        let mut identities = HashSet::new();
        work.charge(
            pending
                .equations
                .len()
                .checked_mul(2)
                .and_then(|count| count.checked_add(self.deferred_cleanup_rows.len()))
                .ok_or(BuildError::TypeWorkExceeded)?,
        )
        .map_err(|()| BuildError::TypeWorkExceeded)?;
        identities
            .try_reserve(pending.equations.len())
            .map_err(|_| BuildError::TypeWorkExceeded)?;
        for identity in pending.identities() {
            if !identities.insert(identity) || !self.deferred_cleanup_rows.contains(&identity) {
                return Err(BuildError::InvalidPayload);
            }
        }
        if identities.len() != self.deferred_cleanup_rows.len() {
            return Err(BuildError::InvalidPayload);
        }
        pending.check_source_nodes(
            &self.nodes,
            root,
            super::provider::row_effect_operation,
            work,
        )?;
        self.deferred_cleanup_rows.clear();
        let program = self.finish_provider_draft(root, work)?;
        Ok((program, pending))
    }
}

impl<F: CoreOperationFamily> Drop for CoreBuilder<F> {
    fn drop(&mut self) {
        for stored in self.nodes.drain(..) {
            discard_type_iteratively(stored.ty);
            F::discard_effects(stored.effects);
            if let Some(origin) = stored.origin {
                discard_origin_iteratively(origin);
            }
            F::discard_metadata(stored.kind);
        }
    }
}

fn replace_origin_iteratively(slot: &mut Option<Origin>, replacement: Origin) {
    if let Some(displaced) = slot.replace(replacement) {
        discard_origin_iteratively(displaced);
    }
}

fn discard_admitted_payload(ty: Type, origin: Origin) {
    discard_type_iteratively(ty);
    discard_origin_iteratively(origin);
}

fn discard_type_vector_iteratively(types: &mut Vec<Type>) {
    for ty in types.drain(..) {
        discard_type_iteratively(ty);
    }
}

fn discard_recursive_binding_inputs(members: Vec<(TypedBinder, NodeId)>) {
    for (binder, _) in members {
        binder.discard_metadata();
    }
}

fn discard_pending_node_payload(ty: Type, origin: Origin, kind: PureExprKind) {
    discard_admitted_payload(ty, origin);
    discard_pure_expr_kind_metadata(kind);
}

pub(super) fn discard_pure_expr_kind_metadata(kind: PureExprKind) {
    match kind {
        PureExprKind::Value(PureValue::Function(function)) => function.discard_metadata(),
        PureExprKind::Computation(PureComputation::Bind(binding)) => binding.discard_metadata(),
        PureExprKind::Computation(PureComputation::RecursiveBind(group)) => {
            group.discard_metadata();
        }
        PureExprKind::Computation(PureComputation::Match(match_node)) => {
            match_node.discard_metadata();
        }
        PureExprKind::Computation(PureComputation::TypeApplication(operation)) => {
            operation.discard_metadata();
        }
        PureExprKind::Value(
            PureValue::Integer(_)
            | PureValue::String(_)
            | PureValue::Intrinsic(_)
            | PureValue::Boolean(_)
            | PureValue::Unit(_)
            | PureValue::Constructor(_),
        )
        | PureExprKind::Variable(_)
        | PureExprKind::Computation(
            PureComputation::Apply(_)
            | PureComputation::Primitive(_)
            | PureComputation::Tuple(_)
            | PureComputation::NewtypeConversion(_)
            | PureComputation::LocalNominalScope(_)
            | PureComputation::TypeAbstraction(_),
        ) => {}
    }
}

enum PatternAdmissionTask {
    Visit(CorePattern, usize),
    VisitSequence(std::vec::IntoIter<CorePattern>, usize),
    FinishTuple {
        ty: Type,
        origin: Origin,
        count: usize,
    },
    FinishConstructor {
        ty: Type,
        origin: Origin,
        constructor: crate::types::ConstructorId,
        has_payload: bool,
    },
}

#[cfg(test)]
std::thread_local! {
    static PATTERN_ADMISSION_PENDING_PEAK: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
    static MATCH_ARM_RETAINED_CAPACITY_PEAK: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
}

#[cfg(test)]
fn record_pattern_admission_pending(pending: usize) {
    PATTERN_ADMISSION_PENDING_PEAK.with(|peak| peak.set(peak.get().max(pending)));
}

#[cfg(test)]
fn record_match_arm_retained_capacity(capacity: usize) {
    MATCH_ARM_RETAINED_CAPACITY_PEAK.with(|peak| peak.set(peak.get().max(capacity)));
}

enum PatternToken {
    Binder(Type, Origin, TypedBinder),
    Wildcard(Type, Origin),
    Boolean(Type, Origin, bool),
    Unit(Type, Origin),
    Tuple(Type, Origin, usize),
    Constructor(Type, Origin, crate::types::ConstructorId, bool),
}

fn admit_match_arms(
    arms: Vec<CoreMatchArm>,
    type_work: &mut TypeWorkBudget,
    inference_binders: &HashSet<BinderId>,
    allow_effectful: bool,
) -> Result<(Vec<CoreMatchArm>, bool), BuildError> {
    let mut admitted = Vec::new();
    let mut requires_type_rewrite = false;
    let mut remaining = arms.into_iter();
    while let Some(arm) = remaining.next() {
        match admit_match_arm(arm, type_work, inference_binders, allow_effectful) {
            Ok((arm, pattern_rewrite)) => {
                requires_type_rewrite |= pattern_rewrite;
                admitted.push(arm);
                #[cfg(test)]
                record_match_arm_retained_capacity(admitted.capacity());
            }
            Err(error) => {
                discard_match_arms(admitted);
                discard_match_arm_remainder(remaining);
                return Err(error);
            }
        }
    }
    Ok((admitted, requires_type_rewrite))
}

fn admit_match_arm(
    arm: CoreMatchArm,
    type_work: &mut TypeWorkBudget,
    inference_binders: &HashSet<BinderId>,
    allow_effectful: bool,
) -> Result<(CoreMatchArm, bool), BuildError> {
    let (pattern, body, origin) = arm.into_parts();
    let pattern = admit_pattern(pattern, type_work, inference_binders, allow_effectful);
    let origin = admit_origin(origin);
    match (pattern, origin) {
        (Ok((pattern, pattern_rewrite)), Ok(origin)) => {
            Ok((CoreMatchArm::new(pattern, body, origin), pattern_rewrite))
        }
        (Err(error), Ok(origin)) => {
            discard_origin_iteratively(origin);
            Err(error)
        }
        (Ok((pattern, _)), Err(error)) => {
            pattern.discard_iteratively();
            Err(error)
        }
        (Err(pattern_error), Err(_)) => Err(pattern_error),
    }
}

fn admit_pattern(
    pattern: CorePattern,
    type_work: &mut TypeWorkBudget,
    inference_binders: &HashSet<BinderId>,
    allow_effectful: bool,
) -> Result<(CorePattern, bool), BuildError> {
    let mut work = vec![PatternAdmissionTask::Visit(pattern, 0)];
    let mut tokens = Vec::new();
    let mut requires_type_rewrite = false;
    #[cfg(test)]
    record_pattern_admission_pending(work.len());
    while let Some(task) = work.pop() {
        match task {
            PatternAdmissionTask::Visit(pattern, depth) => {
                if depth > CORE_PATTERN_DEPTH_LIMIT {
                    pattern.discard_iteratively();
                    discard_pattern_admission_work(work);
                    discard_pattern_tokens(tokens);
                    return Err(BuildError::PatternDepthExceeded);
                }
                let CorePattern { ty, origin, kind } = pattern;
                let (ty, origin, pattern_rewrite) =
                    match admit_payloads(ty, origin, type_work, allow_effectful) {
                        Ok(payloads) => payloads,
                        Err(error) => {
                            discard_pattern_kind(kind);
                            discard_pattern_admission_work(work);
                            discard_pattern_tokens(tokens);
                            return Err(error);
                        }
                    };
                requires_type_rewrite |= pattern_rewrite;
                match kind {
                    CorePatternKind::Binder(binder) => {
                        requires_type_rewrite |= inference_binders.contains(&binder.id());
                        tokens.push(PatternToken::Binder(ty, origin, binder));
                    }
                    CorePatternKind::Wildcard => tokens.push(PatternToken::Wildcard(ty, origin)),
                    CorePatternKind::Boolean(value) => {
                        tokens.push(PatternToken::Boolean(ty, origin, value));
                    }
                    CorePatternKind::Unit => tokens.push(PatternToken::Unit(ty, origin)),
                    CorePatternKind::Tuple(elements) => {
                        let count = elements.len();
                        work.push(PatternAdmissionTask::FinishTuple { ty, origin, count });
                        work.push(PatternAdmissionTask::VisitSequence(
                            elements.into_vec().into_iter(),
                            depth.saturating_add(1),
                        ));
                    }
                    CorePatternKind::Constructor {
                        constructor,
                        payload,
                    } => {
                        let has_payload = payload.is_some();
                        work.push(PatternAdmissionTask::FinishConstructor {
                            ty,
                            origin,
                            constructor,
                            has_payload,
                        });
                        if let Some(payload) = payload {
                            work.push(PatternAdmissionTask::Visit(
                                *payload,
                                depth.saturating_add(1),
                            ));
                        }
                    }
                }
            }
            PatternAdmissionTask::VisitSequence(mut remaining, depth) => {
                if let Some(pattern) = remaining.next() {
                    work.push(PatternAdmissionTask::VisitSequence(remaining, depth));
                    work.push(PatternAdmissionTask::Visit(pattern, depth));
                }
            }
            PatternAdmissionTask::FinishTuple { ty, origin, count } => {
                tokens.push(PatternToken::Tuple(ty, origin, count));
            }
            PatternAdmissionTask::FinishConstructor {
                ty,
                origin,
                constructor,
                has_payload,
            } => tokens.push(PatternToken::Constructor(
                ty,
                origin,
                constructor,
                has_payload,
            )),
        }
        #[cfg(test)]
        record_pattern_admission_pending(work.len());
    }

    let mut rebuilt = Vec::new();
    let mut remaining_tokens = tokens.into_iter();
    while let Some(token) = remaining_tokens.next() {
        let pattern = match token {
            PatternToken::Binder(ty, origin, binder) => {
                CorePattern::new(ty, origin, CorePatternKind::Binder(binder))
            }
            PatternToken::Wildcard(ty, origin) => {
                CorePattern::new(ty, origin, CorePatternKind::Wildcard)
            }
            PatternToken::Boolean(ty, origin, value) => {
                CorePattern::new(ty, origin, CorePatternKind::Boolean(value))
            }
            PatternToken::Unit(ty, origin) => CorePattern::new(ty, origin, CorePatternKind::Unit),
            PatternToken::Tuple(ty, origin, count) => {
                if rebuilt.len() < count {
                    discard_type_iteratively(ty);
                    discard_origin_iteratively(origin);
                    discard_patterns(rebuilt);
                    discard_pattern_token_remainder(remaining_tokens);
                    return Err(BuildError::InvalidPayload);
                }
                let elements = rebuilt.split_off(rebuilt.len() - count);
                CorePattern::new(
                    ty,
                    origin,
                    CorePatternKind::Tuple(elements.into_boxed_slice()),
                )
            }
            PatternToken::Constructor(ty, origin, constructor, has_payload) => {
                let payload = if has_payload {
                    let Some(payload) = rebuilt.pop() else {
                        discard_type_iteratively(ty);
                        discard_origin_iteratively(origin);
                        discard_patterns(rebuilt);
                        discard_pattern_token_remainder(remaining_tokens);
                        return Err(BuildError::InvalidPayload);
                    };
                    Some(Box::new(payload))
                } else {
                    None
                };
                CorePattern::new(
                    ty,
                    origin,
                    CorePatternKind::Constructor {
                        constructor,
                        payload,
                    },
                )
            }
        };
        rebuilt.push(pattern);
    }
    let Some(result) = rebuilt.pop() else {
        return Err(BuildError::InvalidPayload);
    };
    if rebuilt.is_empty() {
        Ok((result, requires_type_rewrite))
    } else {
        result.discard_iteratively();
        discard_patterns(rebuilt);
        Err(BuildError::InvalidPayload)
    }
}

fn discard_patterns(patterns: Vec<CorePattern>) {
    for pattern in patterns {
        pattern.discard_iteratively();
    }
}

fn discard_pattern_token_remainder(tokens: impl Iterator<Item = PatternToken>) {
    discard_pattern_tokens(tokens);
}

fn discard_match_arm_remainder(arms: impl Iterator<Item = CoreMatchArm>) {
    for arm in arms {
        let (pattern, _, origin) = arm.into_parts();
        pattern.discard_iteratively();
        discard_origin_iteratively(origin);
    }
}

fn discard_match_arms(arms: Vec<CoreMatchArm>) {
    discard_match_arm_remainder(arms.into_iter());
}

fn discard_pattern_kind(kind: CorePatternKind) {
    match kind {
        CorePatternKind::Binder(binder) => binder.discard_metadata(),
        CorePatternKind::Tuple(elements) => {
            for pattern in elements.into_vec() {
                pattern.discard_iteratively();
            }
        }
        CorePatternKind::Constructor { payload, .. } => {
            if let Some(payload) = payload {
                payload.discard_iteratively();
            }
        }
        CorePatternKind::Wildcard | CorePatternKind::Boolean(_) | CorePatternKind::Unit => {}
    }
}

fn discard_pattern_admission_work(mut work: Vec<PatternAdmissionTask>) {
    while let Some(task) = work.pop() {
        match task {
            PatternAdmissionTask::Visit(pattern, _) => pattern.discard_iteratively(),
            PatternAdmissionTask::VisitSequence(remaining, _) => {
                for pattern in remaining {
                    pattern.discard_iteratively();
                }
            }
            PatternAdmissionTask::FinishTuple { ty, origin, .. }
            | PatternAdmissionTask::FinishConstructor { ty, origin, .. } => {
                discard_type_iteratively(ty);
                discard_origin_iteratively(origin);
            }
        }
    }
}

fn discard_pattern_tokens(tokens: impl IntoIterator<Item = PatternToken>) {
    for token in tokens {
        match token {
            PatternToken::Binder(ty, origin, binder) => {
                discard_type_iteratively(ty);
                discard_origin_iteratively(origin);
                binder.discard_metadata();
            }
            PatternToken::Wildcard(ty, origin)
            | PatternToken::Boolean(ty, origin, _)
            | PatternToken::Unit(ty, origin)
            | PatternToken::Tuple(ty, origin, _)
            | PatternToken::Constructor(ty, origin, _, _) => {
                discard_type_iteratively(ty);
                discard_origin_iteratively(origin);
            }
        }
    }
}

fn admit_payloads(
    ty: Type,
    origin: Origin,
    type_work: &mut TypeWorkBudget,
    allow_effectful: bool,
) -> Result<(Type, Origin, bool), BuildError> {
    let admitted_type = admit_type_with_status(ty, type_work, true, allow_effectful);
    let admitted_origin = admit_origin(origin);
    match (admitted_type, admitted_origin) {
        (Ok((ty, contains_inference)), Ok(origin)) => Ok((ty, origin, contains_inference)),
        (Err(error), Ok(origin)) => {
            discard_origin_iteratively(origin);
            Err(error)
        }
        (Err(error), Err(_)) => Err(error),
        (Ok((ty, _)), Err(error)) => {
            discard_type_iteratively(ty);
            Err(error)
        }
    }
}

enum TypeAdmissionTask<'a> {
    Visit(&'a Type, usize),
    VisitSequence(std::slice::Iter<'a, Type>, usize),
    Owner(&'a [crate::types::KindedArgument], usize),
}

#[cfg(test)]
std::thread_local! {
    static TYPE_ADMISSION_PENDING_PEAK: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
}

#[cfg(test)]
fn record_type_admission_pending(pending: usize) {
    TYPE_ADMISSION_PENDING_PEAK.with(|peak| peak.set(peak.get().max(pending)));
}

#[cfg(test)]
fn admit_type(ty: Type, type_work: &mut TypeWorkBudget) -> Result<Type, BuildError> {
    admit_type_with_status(ty, type_work, true, false).map(|(ty, _)| ty)
}

fn admit_rewritten_type(
    ty: Type,
    type_work: &mut TypeWorkBudget,
    allow_effectful: bool,
) -> Result<(Type, bool), BuildError> {
    admit_type_with_status(ty, type_work, false, allow_effectful)
}

fn admit_type_with_status(
    ty: Type,
    type_work: &mut TypeWorkBudget,
    charge_structure: bool,
    allow_effectful: bool,
) -> Result<(Type, bool), BuildError> {
    match ty {
        ty @ (Type::Bytes
        | Type::String
        | Type::Int
        | Type::Bool
        | Type::Unit
        | Type::Nominal(_)
        | Type::Variable(_)
        | Type::Inference(_)) => {
            if charge_structure && type_work.charge(1).is_err() {
                return Err(BuildError::TypeWorkExceeded);
            }
            let contains_inference = matches!(ty, Type::Inference(_));
            Ok((ty, contains_inference))
        }
        ty => admit_structured_type_with_status(ty, type_work, charge_structure, allow_effectful),
    }
}

fn admit_structured_type_with_status(
    ty: Type,
    type_work: &mut TypeWorkBudget,
    charge_structure: bool,
    allow_effectful: bool,
) -> Result<(Type, bool), BuildError> {
    let owned = IterativeTypeOwner::new(ty);
    let (contains_inference, normalize) = scan_type_admission(
        TypeAdmissionTask::Visit(&owned, 0),
        type_work,
        charge_structure,
        allow_effectful,
    )?;
    if normalize {
        let normalized =
            clone_type_with_budget(&owned, type_work).map_err(|()| BuildError::TypeWorkExceeded)?;
        Ok((normalized, contains_inference))
    } else {
        Ok((owned.into_inner(), contains_inference))
    }
}

fn scan_type_admission<'a>(
    initial: TypeAdmissionTask<'a>,
    type_work: &mut TypeWorkBudget,
    charge_structure: bool,
    allow_effectful: bool,
) -> Result<(bool, bool), BuildError> {
    let mut work = Vec::new();
    // Keep ordinary Type structure admission optional. New owner-vector
    // scheduling below has its own real retention charges in either mode.
    if charge_structure && matches!(initial, TypeAdmissionTask::Visit(_, _)) {
        type_work
            .charge(1)
            .map_err(|()| BuildError::TypeWorkExceeded)?;
    }
    work.try_reserve_exact(1)
        .map_err(|_| BuildError::TypeWorkExceeded)?;
    work.push(initial);
    let mut exceeded = false;
    let mut contains_inference = false;
    let mut normalize = false;
    #[cfg(test)]
    record_type_admission_pending(work.len());
    while let Some(task) = work.pop() {
        work.try_reserve(3)
            .map_err(|_| BuildError::TypeWorkExceeded)?;
        match task {
            TypeAdmissionTask::Visit(ty, depth) => match ty {
                Type::Inference(_) => contains_inference = true,
                Type::Application(function, argument) => {
                    let child_depth = depth.saturating_add(1);
                    exceeded |= child_depth > CORE_PAYLOAD_DEPTH_LIMIT;
                    if charge_structure {
                        type_work
                            .charge(2)
                            .map_err(|()| BuildError::TypeWorkExceeded)?;
                    }
                    work.push(TypeAdmissionTask::Visit(argument, child_depth));
                    // The unary left spine records source application width.
                    work.push(TypeAdmissionTask::Visit(function, depth));
                }
                Type::Function(domain, codomain) => {
                    let child_depth = depth.saturating_add(1);
                    exceeded |= child_depth > CORE_PAYLOAD_DEPTH_LIMIT;
                    if charge_structure {
                        type_work
                            .charge(2)
                            .map_err(|()| BuildError::TypeWorkExceeded)?;
                    }
                    work.push(TypeAdmissionTask::Visit(codomain, child_depth));
                    work.push(TypeAdmissionTask::Visit(domain, child_depth));
                }
                Type::Tuple(elements) => {
                    let child_depth = depth.saturating_add(1);
                    exceeded |= child_depth > CORE_PAYLOAD_DEPTH_LIMIT;
                    work.push(TypeAdmissionTask::VisitSequence(
                        elements.iter(),
                        child_depth,
                    ));
                }
                Type::Forall(parameters, body) => {
                    charge_kinded_type_parameters(parameters, type_work)
                        .map_err(|()| BuildError::TypeWorkExceeded)?;
                    let child_depth = depth.saturating_add(1);
                    exceeded |= child_depth > CORE_PAYLOAD_DEPTH_LIMIT;
                    if charge_structure {
                        type_work
                            .charge(1)
                            .map_err(|()| BuildError::TypeWorkExceeded)?;
                    }
                    work.push(TypeAdmissionTask::Visit(body, child_depth));
                }
                Type::ResourceApply(_, arguments) => {
                    let child_depth = depth.saturating_add(1);
                    exceeded |= child_depth > CORE_PAYLOAD_DEPTH_LIMIT;
                    work.push(TypeAdmissionTask::Owner(arguments, child_depth));
                }
                Type::EffectfulFunction(domain, computation) => {
                    if !allow_effectful {
                        return Err(BuildError::InvalidPayload);
                    }
                    charge_effect_row_cells(computation.effects(), type_work)
                        .map_err(|()| BuildError::TypeWorkExceeded)?;
                    normalize |= computation.effects().is_empty();
                    contains_inference |= matches!(
                        computation.effects().tail().map(|tail| tail.variable()),
                        Some(EffectRowVariable::Inference(_))
                    );
                    let child_depth = depth.saturating_add(1);
                    exceeded |= child_depth > CORE_PAYLOAD_DEPTH_LIMIT;
                    // Row metadata does not add Type structural depth.
                    for instance in computation.effects().known().iter().chain(
                        computation
                            .effects()
                            .tail()
                            .into_iter()
                            .flat_map(|tail| tail.lacks()),
                    ) {
                        type_work
                            .charge(1)
                            .map_err(|()| BuildError::TypeWorkExceeded)?;
                        work.try_reserve(1)
                            .map_err(|_| BuildError::TypeWorkExceeded)?;
                        work.push(TypeAdmissionTask::Owner(instance.arguments(), child_depth));
                    }
                    if charge_structure {
                        type_work
                            .charge(2)
                            .map_err(|()| BuildError::TypeWorkExceeded)?;
                    }
                    work.try_reserve(2)
                        .map_err(|_| BuildError::TypeWorkExceeded)?;
                    work.push(TypeAdmissionTask::Visit(computation.value(), child_depth));
                    work.push(TypeAdmissionTask::Visit(domain, child_depth));
                }
                Type::Bytes
                | Type::String
                | Type::Int
                | Type::Bool
                | Type::Unit
                | Type::Nominal(_)
                | Type::Variable(_) => {}
            },
            TypeAdmissionTask::VisitSequence(mut remaining, depth) => {
                if let Some(ty) = remaining.next() {
                    if charge_structure {
                        type_work
                            .charge(1)
                            .map_err(|()| BuildError::TypeWorkExceeded)?;
                    }
                    work.push(TypeAdmissionTask::VisitSequence(remaining, depth));
                    work.push(TypeAdmissionTask::Visit(ty, depth));
                }
            }
            TypeAdmissionTask::Owner(arguments, depth) => {
                crate::types::visit_owner_components_with_charge(
                    arguments.iter(),
                    type_work,
                    |ty, budget| {
                        budget.charge(1)?;
                        work.try_reserve(1).map_err(|_| ())?;
                        work.push(TypeAdmissionTask::Visit(ty, depth));
                        Ok(())
                    },
                    |tail, _| {
                        contains_inference |=
                            matches!(tail.variable(), EffectRowVariable::Inference(_));
                        Ok(())
                    },
                )
                .map_err(|()| BuildError::TypeWorkExceeded)?;
            }
        }
        #[cfg(test)]
        record_type_admission_pending(work.len());
    }
    if exceeded {
        return Err(BuildError::TypeDepthExceeded);
    }
    Ok((contains_inference, normalize))
}

enum OriginAdmissionTask {
    Visit(Origin, usize),
    FinishGenerated(GeneratedReason),
    FinishRelated(Vec<Span>),
}

enum OriginToken {
    Source(Span),
    Generated(GeneratedReason),
    Related(Vec<Span>),
}

fn admit_origin(origin: Origin) -> Result<Origin, BuildError> {
    let mut work = vec![OriginAdmissionTask::Visit(origin, 0)];
    let mut tokens = Vec::new();
    let mut exceeded = false;
    while let Some(task) = work.pop() {
        match task {
            OriginAdmissionTask::Visit(Origin::Source(span), _) => {
                tokens.push(OriginToken::Source(span));
            }
            OriginAdmissionTask::Visit(Origin::Generated { cause, reason }, depth) => {
                let child_depth = depth.saturating_add(1);
                exceeded |= child_depth > CORE_PAYLOAD_DEPTH_LIMIT;
                work.push(OriginAdmissionTask::FinishGenerated(reason));
                work.push(OriginAdmissionTask::Visit(*cause, child_depth));
            }
            OriginAdmissionTask::Visit(Origin::Related { primary, related }, depth) => {
                let child_depth = depth.saturating_add(1);
                exceeded |= child_depth > CORE_PAYLOAD_DEPTH_LIMIT;
                work.push(OriginAdmissionTask::FinishRelated(related));
                work.push(OriginAdmissionTask::Visit(*primary, child_depth));
            }
            OriginAdmissionTask::FinishGenerated(reason) => {
                tokens.push(OriginToken::Generated(reason));
            }
            OriginAdmissionTask::FinishRelated(related) => {
                tokens.push(OriginToken::Related(related));
            }
        }
    }
    if exceeded {
        return Err(BuildError::OriginDepthExceeded);
    }

    let mut rebuilt = Vec::new();
    for token in tokens {
        match token {
            OriginToken::Source(span) => rebuilt.push(Origin::Source(span)),
            OriginToken::Generated(reason) => {
                let Some(cause) = rebuilt.pop() else {
                    return Err(BuildError::InvalidPayload);
                };
                rebuilt.push(Origin::Generated {
                    cause: Box::new(cause),
                    reason,
                });
            }
            OriginToken::Related(related) => {
                let Some(primary) = rebuilt.pop() else {
                    return Err(BuildError::InvalidPayload);
                };
                rebuilt.push(Origin::Related {
                    primary: Box::new(primary),
                    related,
                });
            }
        }
    }
    let Some(result) = rebuilt.pop() else {
        return Err(BuildError::InvalidPayload);
    };
    if !rebuilt.is_empty() {
        return Err(BuildError::InvalidPayload);
    }
    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{
        interface::{ImplId, InterfaceId},
        module::ModuleId,
        resolved::{ResolvedConstructor, ResolvedNominalType, ResolvedTypeVariable},
        source::{ByteRange, GeneratedReason, SourceFile},
        types::{ConstructorId, NominalTypeId, TYPE_WORK_LIMIT, TypeVariableId},
    };

    fn resolved_id(local: u32) -> BinderId {
        BinderId::resolved(ModuleId::new(0), local)
    }

    #[test]
    fn arena_allocator_reserves_maximum_as_its_exhaustion_sentinel() {
        let allocator = ArenaIdAllocator::with_next(u32::MAX - 1);

        assert_eq!(allocator.allocate(), Ok(ArenaId::new(u32::MAX - 1)));
        assert_eq!(allocator.allocate(), Err(BuildError::ArenaIdExhausted));
    }

    fn function_type(depth: usize) -> Type {
        let mut ty = Type::Unit;
        for _ in 0..depth {
            ty = Type::Function(Box::new(Type::Unit), Box::new(ty));
        }
        ty
    }

    fn application_type(depth: usize) -> Type {
        let mut ty = Type::Unit;
        for _ in 0..depth {
            ty = Type::Application(Box::new(ty), Box::new(Type::Unit));
        }
        ty
    }

    fn generated_origin(source: &SourceFile, depth: usize) -> Origin {
        let range = ByteRange::new(0, 2).expect("ordered test range");
        let mut origin = Origin::Source(source.span(range).expect("test span"));
        for _ in 0..depth {
            origin = Origin::Generated {
                cause: Box::new(origin),
                reason: GeneratedReason::TypeChecking,
            };
        }
        origin
    }

    #[test]
    fn one_method_evidence_anchor_and_finish_have_an_exact_retry_boundary() {
        // The unary complete application adds one container-authentication
        // unit and one retained argument-slot unit to the predecessor 14.

        let source = SourceFile::new("method-anchor.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let interface = InterfaceId::new(ModuleId::new(0), 0);
        let method = MethodId::new(interface, 0);
        let implementation = ImplMethodId::new(ImplId::new(ModuleId::new(0), 0), method);
        let binder = resolved_id(0);
        let catalog = Arc::new(MethodEvidenceCatalog::new(
            Vec::new(),
            vec![MethodEvidenceImplementationOwner {
                implementation,
                binder,
                head_type_parameter_count: 0,
                source_parameters: Box::new([]),
                application: InterfaceApplication::new(interface, Box::new([Type::Int])),
            }],
            Vec::new(),
            Vec::new(),
            Vec::new(),
            Vec::new(),
            vec![MethodEvidenceExpectation {
                occurrence: None,
                method,
                role: MethodEvidenceExpectedRole::ImplementationOwner { owner: 0 },
            }],
        ));
        let prepare = || {
            let mut builder = CoreBuilder::with_registry_and_method_evidence(
                Arc::new(ResolvedRegistry::default()),
                Arc::clone(&catalog),
            )
            .expect("the one-row consumption bitmap should fit");
            let node = builder
                .unit(Type::Unit, origin.clone())
                .expect("the anchor carrier should fit");
            (builder, node)
        };
        let authenticate = |builder: &mut CoreBuilder, node| {
            builder.authenticate_method_evidence(
                node,
                Some(MethodEvidenceOwner::Implementation(implementation)),
                None,
                method,
                InterfaceApplication::new(interface, Box::new([Type::Int])),
                MethodEvidenceAnchorRole::ImplementationOwner {
                    implementation,
                    binder,
                },
                None,
            )
        };

        let (mut measured, measured_node) = prepare();
        let initial_work = measured.type_work.used();
        authenticate(&mut measured, measured_node)
            .expect("measure complete tagged anchor admission");
        let authenticate_and_finish_work =
            measured.type_work.used() - initial_work + measured.consumed_method_evidence.len();
        measured
            .finish(measured_node)
            .expect("measured anchor publication");

        let (mut short, short_node) = prepare();
        short
            .charge_type_work_for_test(
                TYPE_WORK_LIMIT - short.type_work.used() - (authenticate_and_finish_work - 1),
            )
            .expect("the one-short prefix should fit");
        authenticate(&mut short, short_node).expect("the exact anchor emission should fit");
        assert_eq!(
            short
                .finish(short_node)
                .expect_err("one missing finish-consumption cell must reject publication"),
            BuildError::TypeWorkExceeded,
        );

        for _ in 0..2 {
            let (mut exact, exact_node) = prepare();
            exact
                .charge_type_work_for_test(
                    TYPE_WORK_LIMIT - exact.type_work.used() - authenticate_and_finish_work,
                )
                .expect("the exact prefix should fit");
            authenticate(&mut exact, exact_node).expect("the exact anchor emission should fit");
            exact
                .finish(exact_node)
                .expect("a fresh exact stage should retry and publish");
        }
    }

    fn lexical_capture_catalog() -> MethodEvidenceCatalog {
        let interface = InterfaceId::new(ModuleId::new(0), 0);
        let method = MethodId::new(interface, 0);
        let parameter = TypeVariableId::Resolved {
            module: ModuleId::new(0),
            local: 0,
        };
        let mut catalog = MethodEvidenceCatalog::new(
            vec![MethodEvidenceMethod {
                id: method,
                interface_parameters: Box::new([parameter]),
                inherited_parameters: Box::new([crate::resolved::InheritedOwnerParameter {
                    owner: crate::resolved::OwnerId::Interface(interface),
                    slot: 0,
                    binder: parameter,
                }]),
                parameters: Box::new([]),
                value_type: Type::Function(
                    Box::new(Type::Variable(parameter)),
                    Box::new(Type::Int),
                ),
            }],
            Vec::new(),
            Vec::new(),
            Vec::new(),
            Vec::new(),
            Vec::new(),
            std::iter::once(MethodEvidenceExpectation {
                occurrence: None,
                method,
                role: MethodEvidenceExpectedRole::LexicalOwner { owner: 0 },
            })
            .chain((0..3).map(|ordinal| MethodEvidenceExpectation {
                occurrence: None,
                method,
                role: MethodEvidenceExpectedRole::LexicalCaptureUse { owner: 0, ordinal },
            }))
            .collect(),
        );
        catalog.set_lexical_owners(vec![MethodEvidenceLexicalOwner {
            resource: None,
            source_parameters: Box::new([]),
            source: crate::interface::LexicalEvidenceId::new(ModuleId::new(0), 0),
            method,
            binder: resolved_id(0),
            application: InterfaceApplication::new(
                interface,
                Box::new([Type::Nominal(NominalTypeId::new(ModuleId::new(0), 0))]),
            ),
            captures: Box::new([resolved_id(1), resolved_id(2), resolved_id(2)]),
        }]);
        catalog
    }

    #[test]
    fn lexical_capture_owner_lookup_charges_the_full_owner_table() {
        for width in [1, 64] {
            let mut catalog = lexical_capture_catalog();
            let first = catalog.lexical_owners[0].clone();
            for index in 1..width {
                let mut owner = first.clone();
                owner.source =
                    crate::interface::LexicalEvidenceId::new(ModuleId::new(0), index as u32);
                catalog.lexical_owners.push(owner);
            }
            let mut builder: CoreBuilder = CoreBuilder::with_registry_and_method_evidence(
                Arc::new(ResolvedRegistry::default()),
                Arc::new(catalog),
            )
            .expect("capture catalog");
            builder.type_work = TypeWorkBudget::with_limit(width - 1);
            assert_eq!(
                builder.lexical_capture_owner(first.source, first.method),
                Err(BuildError::TypeWorkExceeded)
            );
            assert_eq!(builder.type_work.used(), 0);
            for _ in 0..2 {
                builder.type_work = TypeWorkBudget::with_limit(width);
                assert_eq!(
                    builder.lexical_capture_owner(first.source, first.method),
                    Ok(0)
                );
                assert_eq!(builder.type_work.used(), width);
            }
        }
    }

    #[test]
    fn lexical_capture_authentication_is_exact_atomic_and_retryable() {
        let source = SourceFile::new("capture-anchor.ash", "()").expect("source");
        let catalog = Arc::new(lexical_capture_catalog());
        // Four expectations retain six charged carrier/visit units each,
        // including both exact scalar indexes and original ordered positions.
        assert_eq!(
            CoreBuilder::with_registry_method_evidence_and_type_work(
                Arc::new(ResolvedRegistry::default()),
                Arc::clone(&catalog),
                TypeWorkBudget::with_limit(23),
            )
            .expect_err("one missing carrier unit"),
            BuildError::TypeWorkExceeded
        );
        let prepare = || {
            let mut builder = CoreBuilder::with_registry_method_evidence_and_type_work(
                Arc::new(ResolvedRegistry::default()),
                Arc::clone(&catalog),
                TypeWorkBudget::with_limit(24),
            )
            .expect("exact carriers");
            assert_eq!(builder.type_work.used(), 24);
            builder.type_work = TypeWorkBudget::unbounded();
            let nodes = catalog.lexical_owners[0]
                .captures
                .iter()
                .map(|binder| {
                    builder
                        .variable(*binder, Type::Int, generated_origin(&source, 0))
                        .expect("exact captured variable")
                })
                .collect::<Vec<_>>();
            (builder, nodes)
        };
        for fresh in 0..2 {
            let (mut builder, nodes) = prepare();
            // Binder, application, lookup, indexed visits, and retained key
            // are charged independently; every candidate still pays the full
            // original catalog lookup and role/application comparison.
            for ordinal in [2, 0, 1] {
                let reached = match ordinal {
                    2 => 4,
                    _ => 2,
                };
                let (mut measured, measured_nodes) = prepare();
                for prior_ordinal in [2, 0, 1].into_iter().take_while(|prior| *prior != ordinal) {
                    measured
                        .authenticate_lexical_capture_use(
                            measured_nodes[prior_ordinal],
                            0,
                            prior_ordinal,
                        )
                        .unwrap();
                }
                let initial_work = measured.type_work.used();
                measured
                    .authenticate_lexical_capture_use(measured_nodes[ordinal], 0, ordinal)
                    .unwrap();
                let work = measured.type_work.used() - initial_work;
                // Complete argument tags and catalog authority supplement the predecessor accounting.
                assert!(work >= 19 + 7 * reached);
                let prior = builder.method_evidence_anchors.len();
                let consumed = builder.consumed_method_evidence.clone();
                let keys = builder.method_evidence_anchor_keys.clone();
                builder.type_work = TypeWorkBudget::with_limit(work - 1);
                assert_eq!(
                    builder.authenticate_lexical_capture_use(nodes[ordinal], 0, ordinal),
                    Err(BuildError::TypeWorkExceeded),
                    "fresh {fresh}, ordinal {ordinal}"
                );
                assert_eq!(builder.method_evidence_anchors.len(), prior);
                assert_eq!(builder.consumed_method_evidence, consumed);
                assert_eq!(builder.method_evidence_anchor_keys, keys);
                builder.type_work = TypeWorkBudget::with_limit(work);
                builder
                    .authenticate_lexical_capture_use(nodes[ordinal], 0, ordinal)
                    .expect("exact capture authentication");
                assert_eq!(builder.type_work.used(), work);
                assert_eq!(builder.method_evidence_anchors.len(), prior + 1);
                assert!(builder.consumed_method_evidence[ordinal + 1]);
            }
        }
    }

    #[test]
    fn method_evidence_anchor_authenticates_a_complete_ordered_application() {
        let source = SourceFile::new("vector-method-anchor.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let interface = InterfaceId::new(ModuleId::new(0), 0);
        let method = MethodId::new(interface, 0);
        let implementation = ImplMethodId::new(ImplId::new(ModuleId::new(0), 0), method);
        let binder = resolved_id(0);
        let catalog = Arc::new(MethodEvidenceCatalog::new(
            Vec::new(),
            vec![MethodEvidenceImplementationOwner {
                implementation,
                binder,
                head_type_parameter_count: 0,
                source_parameters: Box::new([]),
                application: InterfaceApplication::new(
                    interface,
                    vec![Type::Int, Type::Bool].into_boxed_slice(),
                ),
            }],
            Vec::new(),
            Vec::new(),
            Vec::new(),
            Vec::new(),
            vec![MethodEvidenceExpectation {
                occurrence: None,
                method,
                role: MethodEvidenceExpectedRole::ImplementationOwner { owner: 0 },
            }],
        ));
        let prepare = || {
            let mut builder = CoreBuilder::with_registry_and_method_evidence(
                Arc::new(ResolvedRegistry::default()),
                Arc::clone(&catalog),
            )
            .expect("one expectation bitmap");
            let node = builder
                .unit(Type::Unit, origin.clone())
                .expect("the anchor node should fit");
            (builder, node)
        };
        let authenticate = |builder: &mut CoreBuilder, node| {
            builder.authenticate_method_evidence(
                node,
                Some(MethodEvidenceOwner::Implementation(implementation)),
                None,
                method,
                InterfaceApplication::new(
                    interface,
                    vec![Type::Int, Type::Bool].into_boxed_slice(),
                ),
                MethodEvidenceAnchorRole::ImplementationOwner {
                    implementation,
                    binder,
                },
                None,
            )
        };

        let (mut rejected, rejected_node) = prepare();
        assert_eq!(
            rejected.authenticate_method_evidence(
                rejected_node,
                Some(MethodEvidenceOwner::Implementation(implementation)),
                None,
                method,
                InterfaceApplication::new(
                    interface,
                    vec![Type::Bool, Type::Int].into_boxed_slice(),
                ),
                MethodEvidenceAnchorRole::ImplementationOwner {
                    implementation,
                    binder,
                },
                None,
            ),
            Err(BuildError::InvalidPayload),
            "an exact lookup key cannot authenticate a permuted application"
        );
        assert!(rejected.method_evidence_anchors.is_empty());
        assert!(rejected.method_evidence_anchor_keys.is_empty());
        assert_eq!(rejected.consumed_method_evidence, [false]);
        authenticate(&mut rejected, rejected_node).expect("retry the unchanged full predicate");
        assert_eq!(
            authenticate(&mut rejected, rejected_node),
            Err(BuildError::InvalidPayload),
            "the complete original anchor key cannot be published twice"
        );
        let other_node = rejected
            .unit(Type::Unit, origin.clone())
            .expect("a different actual arena coordinate");
        assert_eq!(
            authenticate(&mut rejected, other_node),
            Err(BuildError::InvalidPayload),
            "a distinct node cannot reuse the consumed original expectation"
        );
        assert_eq!(rejected.method_evidence_anchor_keys.len(), 1);
        assert_eq!(rejected.method_evidence_anchors.len(), 1);
        assert_eq!(rejected.consumed_method_evidence, [true]);

        let (mut measured, measured_node) = prepare();
        let before = measured.type_work.used();
        authenticate(&mut measured, measured_node)
            .expect("the same complete application should authenticate");
        let authentication_work = measured.type_work.used() - before;
        measured
            .finish(measured_node)
            .expect("the expectation should be consumed");

        let (mut short, short_node) = prepare();
        short
            .charge_type_work_for_test(
                TYPE_WORK_LIMIT - short.type_work.used() - (authentication_work - 1),
            )
            .expect("the one-short prefix should fit");
        assert_eq!(
            authenticate(&mut short, short_node),
            Err(BuildError::TypeWorkExceeded),
        );
        assert!(short.method_evidence_anchors.is_empty());
        assert!(short.method_evidence_anchor_keys.is_empty());
        assert_eq!(short.consumed_method_evidence, [false]);

        let (mut exact, exact_node) = prepare();
        exact
            .charge_type_work_for_test(
                TYPE_WORK_LIMIT - exact.type_work.used() - authentication_work,
            )
            .expect("the exact prefix should fit");
        authenticate(&mut exact, exact_node)
            .expect("the exact complete-vector authentication should retry atomically");
        assert_eq!(exact.type_work.used(), TYPE_WORK_LIMIT);
        assert_eq!(exact.method_evidence_anchors.len(), 1);
        assert_eq!(exact.method_evidence_anchor_keys.len(), 1);
        assert_eq!(exact.consumed_method_evidence, [true]);
    }

    #[test]
    fn rejected_deep_complete_application_discards_iteratively() {
        std::thread::Builder::new()
            .name("deep-complete-core-application".to_owned())
            .stack_size(64 * 1024)
            .spawn(|| {
                let source = SourceFile::new("deep-vector-anchor.ash", "()").expect("test source");
                let origin = generated_origin(&source, 0);
                let interface = InterfaceId::new(ModuleId::new(0), 0);
                let method = MethodId::new(interface, 0);
                let implementation = ImplMethodId::new(ImplId::new(ModuleId::new(0), 0), method);
                let binder = resolved_id(0);
                let catalog = Arc::new(MethodEvidenceCatalog::new(
                    Vec::new(),
                    vec![MethodEvidenceImplementationOwner {
                        implementation,
                        binder,
                        head_type_parameter_count: 0,
                        source_parameters: Box::new([]),
                        application: InterfaceApplication::new(
                            interface,
                            Box::new([Type::Int, application_type(CORE_PAYLOAD_DEPTH_LIMIT + 1)]),
                        ),
                    }],
                    Vec::new(),
                    Vec::new(),
                    Vec::new(),
                    Vec::new(),
                    vec![MethodEvidenceExpectation {
                        occurrence: None,
                        method,
                        role: MethodEvidenceExpectedRole::ImplementationOwner { owner: 0 },
                    }],
                ));
                let mut builder =
                    CoreBuilder::<PureOperationFamily>::with_registry_and_method_evidence(
                        Arc::new(ResolvedRegistry::default()),
                        catalog,
                    )
                    .expect("one expectation bitmap");
                let node = builder
                    .unit(Type::Unit, origin)
                    .expect("the anchor node should fit");
                let failure = builder.authenticate_method_evidence(
                    node,
                    Some(MethodEvidenceOwner::Implementation(implementation)),
                    None,
                    method,
                    InterfaceApplication::new(
                        InterfaceId::new(ModuleId::new(0), 1),
                        Box::new([Type::Int, application_type(CORE_PAYLOAD_DEPTH_LIMIT + 1)]),
                    ),
                    MethodEvidenceAnchorRole::ImplementationOwner {
                        implementation,
                        binder,
                    },
                    None,
                );
                assert!(failure.is_err());
                assert!(builder.method_evidence_anchors.is_empty());
            })
            .expect("the small-stack Core application worker should start")
            .join()
            .expect("rejected complete applications should dismantle iteratively");
    }

    #[test]
    fn lexical_capture_late_application_admission_failure_is_atomic_on_a_small_stack() {
        std::thread::Builder::new()
            .name("deep-lexical-capture-application".to_owned())
            .stack_size(128 * 1024)
            .spawn(|| {
                let source = SourceFile::new("deep-capture.ash", "()").expect("source");
                let mut catalog = lexical_capture_catalog();
                let interface = catalog.lexical_owners[0].method.interface();
                catalog.lexical_owners[0].application = InterfaceApplication::new(
                    interface,
                    Box::new([function_type(CORE_PAYLOAD_DEPTH_LIMIT + 1)]),
                );
                let mut builder: CoreBuilder = CoreBuilder::with_registry_and_method_evidence(
                    Arc::new(ResolvedRegistry::default()),
                    Arc::new(catalog),
                )
                .expect("catalog carriers");
                let node = builder
                    .variable(resolved_id(1), Type::Int, generated_origin(&source, 0))
                    .expect("capture node");
                builder.type_work = TypeWorkBudget::unbounded();
                assert_eq!(
                    builder.authenticate_lexical_capture_use(node, 0, 0),
                    Err(BuildError::TypeDepthExceeded)
                );
                assert!(builder.method_evidence_anchors.is_empty());
                assert_eq!(builder.consumed_method_evidence, [false; 4]);
                assert!(builder.method_evidence_anchor_keys.is_empty());
            })
            .expect("small-stack worker")
            .join()
            .expect("late cloned-application failure and catalog disposal are iterative");
    }

    #[test]
    fn method_evidence_builder_constructor_precharges_both_exact_carriers() {
        let interface = InterfaceId::new(ModuleId::new(0), 0);
        let method = MethodId::new(interface, 0);
        let catalog = Arc::new(MethodEvidenceCatalog::new(
            Vec::new(),
            Vec::new(),
            Vec::new(),
            Vec::new(),
            Vec::new(),
            Vec::new(),
            vec![
                MethodEvidenceExpectation {
                    occurrence: None,
                    method,
                    role: MethodEvidenceExpectedRole::Instantiation { producer: 0 },
                },
                MethodEvidenceExpectation {
                    occurrence: None,
                    method,
                    role: MethodEvidenceExpectedRole::Instantiation { producer: 0 },
                },
            ],
        ));
        const EXPECTATIONS: usize = 2;
        const EXACT_WORK: usize = 6 * EXPECTATIONS;

        assert_eq!(
            CoreBuilder::with_registry_method_evidence_and_type_work(
                Arc::new(ResolvedRegistry::default()),
                Arc::clone(&catalog),
                TypeWorkBudget::with_limit(EXACT_WORK - 1),
            )
            .expect_err("one missing carrier-capacity unit rejects construction"),
            BuildError::TypeWorkExceeded,
        );

        for _ in 0..2 {
            let builder = CoreBuilder::with_registry_method_evidence_and_type_work(
                Arc::new(ResolvedRegistry::default()),
                Arc::clone(&catalog),
                TypeWorkBudget::with_limit(EXACT_WORK),
            )
            .expect("a fresh exact constructor stage retries");
            assert_eq!(builder.type_work.used(), EXACT_WORK);
            assert_eq!(builder.consumed_method_evidence.capacity(), EXPECTATIONS);
            assert_eq!(builder.method_evidence_anchors.capacity(), EXPECTATIONS);
            assert!(builder.method_evidence_anchor_keys.is_empty());
            assert_eq!(builder.method_evidence_expectation_positions.len(), 1);
            assert_eq!(
                builder
                    .method_evidence_expectation_positions
                    .get(&(None, method)),
                Some(&vec![0, 1]),
                "candidate positions retain complete original order"
            );
        }
    }

    #[test]
    fn unfinished_builder_discards_deep_payloads_on_a_small_stack() {
        std::thread::scope(|scope| {
            std::thread::Builder::new()
                .stack_size(128 * 1024)
                .spawn_scoped(scope, || {
                    let source = SourceFile::new("temporary-check.ash", "()")
                        .expect("test source should fit");
                    let origin = Origin::Source(
                        source
                            .span(ByteRange::new(0, 2).expect("ordered range"))
                            .expect("range should belong to source"),
                    );
                    let mut builder = CoreBuilder::new();
                    for _ in 0..32 {
                        builder
                            .unit(function_type(CORE_PAYLOAD_DEPTH_LIMIT), origin.clone())
                            .expect("boundary-depth payload should be admitted");
                    }
                })
                .expect("small-stack builder-drop thread should complete");
        });
    }

    #[test]
    fn replacing_an_origin_discards_the_displaced_deep_origin_on_a_small_stack() {
        const DEPTH: usize = 32_768;

        std::thread::Builder::new()
            .name("replace-deep-core-origin".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("replace-origin.ash", "()")
                    .expect("the replacement fixture should fit");
                let mut slot = Some(generated_origin(&source, DEPTH));

                replace_origin_iteratively(&mut slot, generated_origin(&source, 0));

                assert_eq!(
                    slot.as_ref().map(Origin::primary_span).map(Span::source),
                    Some(source.id())
                );
            })
            .expect("the origin-replacement thread should start")
            .join()
            .expect("the displaced origin must be dismantled iteratively");
    }

    #[test]
    fn successful_core_metadata_rewrite_replaces_deep_types_on_a_small_stack() {
        const DEPTH: usize = 32_768;

        std::thread::Builder::new()
            .name("successful-deep-core-rewrite".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("rewrite-core.ash", "()")
                    .expect("the rewrite fixture should fit");
                let origin = generated_origin(&source, 0);

                let mut node_builder = CoreBuilder::new();
                node_builder
                    .unit(application_type(DEPTH), origin.clone())
                    .expect("the deep node annotation should be admitted");
                node_builder
                    .rewrite_types(|_| Ok(Type::Unit))
                    .expect("the deep node annotation should rewrite");

                let mut binder_builder = CoreBuilder::new();
                let body = binder_builder
                    .unit(Type::Unit, origin.clone())
                    .expect("the function body should fit");
                let parameter = binder_builder
                    .binder(application_type(DEPTH), origin.clone())
                    .expect("the deep binder annotation should be admitted");
                binder_builder
                    .function(parameter, body, Type::Unit, origin.clone())
                    .expect("the unchecked function should fit");
                binder_builder
                    .rewrite_types(|_| Ok(Type::Unit))
                    .expect("the deep binder annotation should rewrite");

                let mut pattern_builder = CoreBuilder::new();
                let value = pattern_builder
                    .unit(Type::Unit, origin.clone())
                    .expect("the scrutinee should fit");
                pattern_builder
                    .match_expression(
                        value,
                        vec![CoreMatchArm::new(
                            CorePattern::new(
                                application_type(DEPTH),
                                origin.clone(),
                                CorePatternKind::Wildcard,
                            ),
                            value,
                            origin.clone(),
                        )],
                        Type::Unit,
                        origin.clone(),
                    )
                    .expect("the deep pattern annotation should be admitted");
                pattern_builder
                    .rewrite_types(|_| Ok(Type::Unit))
                    .expect("the deep pattern annotation should rewrite");

                let mut operation_builder = CoreBuilder::new();
                let function = operation_builder
                    .unit(Type::Unit, origin.clone())
                    .expect("the type-operation function should fit");
                operation_builder
                    .type_application(function, vec![application_type(DEPTH)], Type::Unit, origin)
                    .expect("the deep type argument should be admitted");
                operation_builder
                    .rewrite_types(|_| Ok(Type::Unit))
                    .expect("the deep type argument should rewrite");
            })
            .expect("the rewrite thread should start")
            .join()
            .expect("successful Core rewrites must dismantle old types iteratively");
    }

    #[test]
    fn unvalidated_program_discards_deep_payloads_on_a_small_stack() {
        const DEPTH: usize = 32_768;

        std::thread::Builder::new()
            .name("unvalidated-deep-type-disposal".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source =
                    SourceFile::new("raw-core.ash", "()").expect("the raw Core fixture should fit");
                let origin = generated_origin(&source, 0);
                let mut builder = CoreBuilder::new();
                let root = builder
                    .unit(application_type(DEPTH), origin)
                    .expect("the deep raw annotation should be admitted");
                let unvalidated = builder.finish(root).expect("the raw Core root should fit");
                drop(unvalidated);
            })
            .expect("the raw Core thread should start")
            .join()
            .expect("raw Core teardown must dismantle stored types iteratively");
    }

    #[test]
    fn newtype_conversion_admission_has_an_exact_atomic_retry_boundary() {
        let source = SourceFile::new("newtype-conversion.ash", "1").expect("test source");
        let origin = Origin::Source(
            source
                .span(ByteRange::new(0, 1).expect("ordered range"))
                .expect("source span"),
        );
        let owner = NominalTypeId::new(ModuleId::new(0), 0);
        let prepare = || {
            let mut builder = CoreBuilder::new();
            let child = builder
                .integer(
                    Integer::parse_decimal("1").expect("valid integer"),
                    Type::Int,
                    origin.clone(),
                )
                .expect("the conversion child should fit");
            (builder, child)
        };

        let (mut measured, measured_child) = prepare();
        let before = measured.type_work.used();
        measured
            .newtype_conversion(
                owner,
                NewtypeConversionDirection::Wrap,
                measured_child,
                Type::Nominal(owner),
                origin.clone(),
            )
            .expect("the measured conversion should fit");
        const RESULT_TYPE_WORK: usize = 1; // one nominal result-type cell
        const EXACT_CONVERSION_WORK: usize = RESULT_TYPE_WORK;
        let conversion_work = measured.type_work.used() - before;
        assert_eq!(conversion_work, EXACT_CONVERSION_WORK);

        let (mut short, short_child) = prepare();
        let short_node_count = short.nodes.len();
        short
            .charge_type_work_for_test(
                TYPE_WORK_LIMIT - short.type_work.used() - (conversion_work - 1),
            )
            .expect("the one-short prefix should fit");
        assert_eq!(
            short.newtype_conversion(
                owner,
                NewtypeConversionDirection::Wrap,
                short_child,
                Type::Nominal(owner),
                origin.clone(),
            ),
            Err(BuildError::TypeWorkExceeded),
        );
        assert_eq!(short.nodes.len(), short_node_count);

        for _ in 0..2 {
            let (mut exact, exact_child) = prepare();
            exact
                .charge_type_work_for_test(
                    TYPE_WORK_LIMIT - exact.type_work.used() - conversion_work,
                )
                .expect("the exact prefix should fit");
            let root = exact
                .newtype_conversion(
                    owner,
                    NewtypeConversionDirection::Wrap,
                    exact_child,
                    Type::Nominal(owner),
                    origin.clone(),
                )
                .expect("a fresh exact builder should retry the conversion");
            assert_eq!(exact.type_work.used(), TYPE_WORK_LIMIT);
            assert_eq!(exact.nodes.len(), 2);
            let program = exact
                .finish(root)
                .expect("the exact conversion should finish");
            drop(program);
        }
    }

    #[test]
    fn local_nominal_scope_admission_has_an_exact_atomic_retry_boundary() {
        let source = SourceFile::new("local-nominal-scope.ash", "()").expect("test source");
        let origin = Origin::Source(
            source
                .span(ByteRange::new(0, 2).expect("ordered range"))
                .expect("source span"),
        );
        let owner = NominalTypeId::lexical(ModuleId::new(0), 0);
        let prepare = || {
            let mut builder = CoreBuilder::new();
            let body = builder
                .unit(Type::Unit, origin.clone())
                .expect("the scope body should fit");
            (builder, body)
        };

        let (mut measured, measured_body) = prepare();
        let before = measured.type_work.used();
        measured
            .local_nominal_scope(owner, measured_body, Type::Unit, origin.clone())
            .expect("the measured scope should fit");
        let scope_work = measured.type_work.used() - before;
        assert_eq!(
            scope_work, 1,
            "the carrier admits only its unit result type"
        );

        let (mut short, short_body) = prepare();
        let short_node_count = short.nodes.len();
        short
            .charge_type_work_for_test(TYPE_WORK_LIMIT - short.type_work.used())
            .expect("the one-short prefix should fit");
        assert_eq!(
            short.local_nominal_scope(owner, short_body, Type::Unit, origin.clone()),
            Err(BuildError::TypeWorkExceeded),
        );
        assert_eq!(short.nodes.len(), short_node_count);

        for _ in 0..2 {
            let (mut exact, exact_body) = prepare();
            exact
                .charge_type_work_for_test(TYPE_WORK_LIMIT - exact.type_work.used() - scope_work)
                .expect("the exact prefix should fit");
            let root = exact
                .local_nominal_scope(owner, exact_body, Type::Unit, origin.clone())
                .expect("a fresh exact builder should retry the scope");
            assert_eq!(exact.type_work.used(), TYPE_WORK_LIMIT);
            assert_eq!(exact.nodes.len(), 2);
            drop(exact.finish(root).expect("the exact scope should finish"));
        }
    }

    #[test]
    fn unvalidated_local_nominal_scope_chain_discards_on_a_small_stack() {
        const DEPTH: usize = 32_768;

        std::thread::Builder::new()
            .name("local-nominal-scope-disposal".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("local-scope-chain.ash", "()").expect("test source");
                let origin = Origin::Source(
                    source
                        .span(ByteRange::new(0, 2).expect("ordered range"))
                        .expect("source span"),
                );
                let owner = NominalTypeId::lexical(ModuleId::new(0), 0);
                let mut builder = CoreBuilder::new();
                let mut root = builder
                    .unit(Type::Unit, origin.clone())
                    .expect("the scope leaf should fit");
                for _ in 0..DEPTH {
                    root = builder
                        .local_nominal_scope(owner, root, Type::Unit, origin.clone())
                        .expect("the scope chain should fit");
                }
                assert_eq!(builder.nodes.len(), DEPTH + 1);
                drop(builder.finish(root).expect("the scope chain should finish"));
            })
            .expect("the local-scope disposal thread should start")
            .join()
            .expect("local scope teardown must remain iterative");
    }

    #[test]
    fn unvalidated_newtype_conversion_chain_discards_on_a_small_stack() {
        const DEPTH: usize = 32_768;

        std::thread::Builder::new()
            .name("newtype-conversion-disposal".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("conversion-chain.ash", "()").expect("test source");
                let origin = Origin::Source(
                    source
                        .span(ByteRange::new(0, 2).expect("ordered range"))
                        .expect("source span"),
                );
                let owner = NominalTypeId::new(ModuleId::new(0), 0);
                let mut builder = CoreBuilder::new();
                let mut root = builder
                    .unit(Type::Unit, origin.clone())
                    .expect("the conversion leaf should fit");
                for index in 0..DEPTH {
                    root = builder
                        .newtype_conversion(
                            owner,
                            if index % 2 == 0 {
                                NewtypeConversionDirection::Wrap
                            } else {
                                NewtypeConversionDirection::Unwrap
                            },
                            root,
                            Type::Unit,
                            origin.clone(),
                        )
                        .expect("the conversion chain should fit");
                }
                assert_eq!(builder.nodes.len(), DEPTH + 1);
                let program = builder
                    .finish(root)
                    .expect("the conversion chain should finish");
                drop(program);
            })
            .expect("the conversion disposal thread should start")
            .join()
            .expect("conversion carriers must dismantle iteratively");
    }

    #[test]
    fn successful_public_binder_owners_drop_deep_types_on_a_small_stack() {
        const DEPTH: usize = 32_768;

        std::thread::Builder::new()
            .name("successful-binder-owner-disposal".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source =
                    SourceFile::new("binder-owner.ash", "()").expect("the fixture should fit");
                let origin = generated_origin(&source, 0);

                let mut generated_builder = CoreBuilder::new();
                let generated = generated_builder
                    .binder(application_type(DEPTH), origin.clone())
                    .expect("the generated binder should be admitted");
                drop(generated);

                let resolved_id = resolved_id(0);
                let mut resolved_builder = CoreBuilder::new();
                resolved_builder
                    .reserve_resolved_binders([resolved_id])
                    .expect("the resolved binder should be reserved");
                let resolved = resolved_builder
                    .resolved_binder(resolved_id, application_type(DEPTH), origin)
                    .expect("the resolved binder should be admitted");
                drop(resolved);
            })
            .expect("the binder-owner thread should start")
            .join()
            .expect("successful public binder owners must dismantle their types iteratively");
    }

    #[test]
    fn public_match_arm_owner_drops_a_deep_pattern_on_a_small_stack() {
        const DEPTH: usize = 32_768;

        std::thread::Builder::new()
            .name("public-match-arm-owner-disposal".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source =
                    SourceFile::new("match-arm-owner.ash", "()").expect("the fixture should fit");
                let origin = generated_origin(&source, 0);
                let arm = CoreMatchArm::new(
                    CorePattern::new(
                        application_type(DEPTH),
                        origin.clone(),
                        CorePatternKind::Wildcard,
                    ),
                    NodeId::new(ArenaId::new(0), 0),
                    origin,
                );
                drop(arm);
            })
            .expect("the match-arm owner thread should start")
            .join()
            .expect("a public match arm must dismantle its pattern iteratively");
    }

    #[test]
    fn public_core_pattern_has_an_iterative_consuming_disposal_path() {
        const DEPTH: usize = 32_768;

        std::thread::Builder::new()
            .name("public-pattern-disposal".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source =
                    SourceFile::new("pattern-owner.ash", "()").expect("the fixture should fit");
                CorePattern::new(
                    application_type(DEPTH),
                    generated_origin(&source, 0),
                    CorePatternKind::Wildcard,
                )
                .discard_iteratively();
            })
            .expect("the pattern-owner thread should start")
            .join()
            .expect("the documented Core pattern disposal path must fit a small stack");
    }

    #[test]
    fn public_typed_expression_disposes_type_application_arguments_iteratively() {
        const DEPTH: usize = 32_768;

        std::thread::Builder::new()
            .name("public-typed-expression-disposal".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("typed-expression-owner.ash", "()")
                    .expect("the fixture should fit");
                TypedExpr {
                    effects: (),
                    ty: Type::Unit,
                    origin: generated_origin(&source, 0),
                    kind: PureExprKind::Computation(PureComputation::TypeApplication(
                        TypeApplicationNode::new_with_row_arguments(
                            NodeId::new(ArenaId::new(0), 0),
                            vec![application_type(DEPTH)],
                            vec![EffectRow::singleton(crate::types::EffectInstance::new(
                                crate::types::EffectId::new(ModuleId::new(0), 0),
                                Box::new([application_type(DEPTH)]),
                            ))],
                        ),
                    )),
                }
                .discard_iteratively();
            })
            .expect("the typed-expression thread should start")
            .join()
            .expect("the public disposal path must dismantle Core type arguments iteratively");
    }

    #[test]
    fn canonical_application_core_admission_has_an_exact_cell_boundary() {
        let owner = NominalTypeId::new(ModuleId::new(0), 0);
        let application = || {
            Type::Application(
                Box::new(Type::Application(
                    Box::new(Type::Nominal(owner)),
                    Box::new(Type::Int),
                )),
                Box::new(Type::Bool),
            )
        };
        let mut exact = TypeWorkBudget::with_limit(5);
        let mut short = TypeWorkBudget::with_limit(4);

        let (admitted, exceeded) = admit_type_with_status(application(), &mut exact, true, false)
            .expect("the five canonical cells should fit exactly");
        assert!(!exceeded);
        assert_eq!(exact.used(), 5);
        discard_type_iteratively(admitted);
        assert_eq!(
            admit_type_with_status(application(), &mut short, true, false),
            Err(BuildError::TypeWorkExceeded),
        );
        // The refused two-cell reservation is atomic, so only three cells are consumed.
        assert_eq!(short.used(), 3);
    }

    #[test]
    fn validated_program_discards_a_wide_application_on_a_small_stack() {
        // The predecessor registry/envelope/scope passes consume 10W + 4;
        // Kind nodes in the envelope and scope Forall add 2W. Independent Core
        // kind synthesis consumes 7W + 2, and charged constructor-scheme
        // agreement consumes 3W + 1, for 22W + 7 total units.
        const WIDTH: usize = 32_767;

        std::thread::Builder::new()
            .name("validated-wide-type-disposal".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("wide-core.ash", "x".repeat(WIDTH + 2))
                    .expect("the Core fixture should fit");
                let span = source
                    .span(
                        ByteRange::new(
                            0,
                            u32::try_from(WIDTH + 2).expect("the fixture length should fit"),
                        )
                        .expect("the range is ordered"),
                    )
                    .expect("the range belongs to the fixture");
                let origin = Origin::Source(span);
                let module = ModuleId::new(0);
                let owner = NominalTypeId::new(module, 0);
                let constructor = ConstructorId::new(owner, 0);
                let parameters = (0..WIDTH)
                    .map(|index| {
                        let start = u32::try_from(index + 1).expect("the fixture index should fit");
                        ResolvedTypeVariable {
                            id: TypeVariableId::resolved(
                                module,
                                u32::try_from(index).expect("the fixture index should fit"),
                            ),
                            spelling: format!("A{index}"),
                            kind: crate::types::Kind::Type,
                            origin: Origin::Source(
                                source
                                    .span(
                                        ByteRange::new(start, start + 1)
                                            .expect("the range is ordered"),
                                    )
                                    .expect("the range belongs to the fixture"),
                            ),
                        }
                    })
                    .collect::<Vec<_>>();
                let parameter_ids = parameters
                    .iter()
                    .map(|parameter| parameter.id)
                    .collect::<Vec<_>>();
                let registry = ResolvedRegistry::new(
                    vec![ResolvedNominalType {
                        representation_provenance: None,
                        id: owner,
                        declaration_kind: crate::resolved::ResolvedNominalDeclarationKind::Data,
                        representation: None,
                        spelling: "Wide".to_owned(),
                        constructors: vec![constructor].into_boxed_slice(),
                        origin: origin.clone(),
                    }],
                    vec![ResolvedConstructor {
                        id: constructor,
                        owner,
                        spelling: "Wide".to_owned(),
                        payload: None,
                        origin: Origin::Source(
                            source
                                .span(ByteRange::new(0, 1).expect("the range is ordered"))
                                .expect("the range belongs to the fixture"),
                        ),
                    }],
                )
                .with_type_parameters(vec![(owner, parameters)]);
                let mut result = Type::Nominal(owner);
                for parameter in &parameter_ids {
                    result =
                        Type::Application(Box::new(result), Box::new(Type::Variable(*parameter)));
                }
                let annotation = Type::Forall(
                    parameter_ids
                        .into_iter()
                        .map(|parameter| (parameter, Kind::Type))
                        .collect(),
                    Box::new(result),
                );
                let mut builder = CoreBuilder::with_registry(Arc::new(registry));
                let root = builder
                    .constructor(constructor, annotation, origin)
                    .expect("application-spine width must not become Core structural depth");
                let program = builder
                    .finish(root)
                    .expect("the Core fixture should finish");
                let validated = super::super::validate::validate(program, &[&source])
                    .expect("the saturated wide constructor scheme should validate");
                drop(validated);
            })
            .expect("the Core disposal thread should start")
            .join()
            .expect("validated Core should dispose canonical application spines iteratively");
    }

    fn related_origin(source: &SourceFile, depth: usize) -> Origin {
        let range = ByteRange::new(0, 2).expect("ordered test range");
        let span = source.span(range).expect("test span");
        let mut origin = Origin::Source(span);
        for _ in 0..depth {
            origin = Origin::Related {
                primary: Box::new(origin),
                related: vec![span],
            };
        }
        origin
    }

    fn reset_type_admission_pending_peak() {
        TYPE_ADMISSION_PENDING_PEAK.with(|peak| peak.set(0));
    }

    fn type_admission_pending_peak() -> usize {
        TYPE_ADMISSION_PENDING_PEAK.with(std::cell::Cell::get)
    }

    fn reset_pattern_admission_peaks() {
        PATTERN_ADMISSION_PENDING_PEAK.with(|peak| peak.set(0));
        MATCH_ARM_RETAINED_CAPACITY_PEAK.with(|peak| peak.set(0));
    }

    fn pattern_admission_pending_peak() -> usize {
        PATTERN_ADMISSION_PENDING_PEAK.with(std::cell::Cell::get)
    }

    fn match_arm_retained_capacity_peak() -> usize {
        MATCH_ARM_RETAINED_CAPACITY_PEAK.with(std::cell::Cell::get)
    }

    fn nested_pattern(source: &SourceFile, depth: usize) -> CorePattern {
        let origin = generated_origin(source, 0);
        let mut pattern = CorePattern::new(Type::Unit, origin.clone(), CorePatternKind::Wildcard);
        for _ in 0..depth {
            pattern = CorePattern::new(
                Type::Unit,
                origin.clone(),
                CorePatternKind::Tuple(vec![pattern].into_boxed_slice()),
            );
        }
        pattern
    }

    #[test]
    fn pattern_payload_limit_rejects_deep_core_on_a_small_stack() {
        std::thread::Builder::new()
            .name("core-pattern-boundary".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("pattern.ash", "()").expect("test source");
                let origin = generated_origin(&source, 0);
                let mut builder = CoreBuilder::new();
                let value = builder.unit(Type::Unit, origin.clone()).expect("unit node");
                let before = builder.nodes.len();
                assert_eq!(
                    builder.match_expression(
                        value,
                        vec![CoreMatchArm::new(
                            nested_pattern(&source, 50_000),
                            value,
                            origin.clone(),
                        )],
                        Type::Unit,
                        origin.clone(),
                    ),
                    Err(BuildError::PatternDepthExceeded)
                );
                assert_eq!(builder.nodes.len(), before);

                builder
                    .match_expression(
                        value,
                        vec![CoreMatchArm::new(
                            nested_pattern(&source, CORE_PATTERN_DEPTH_LIMIT),
                            value,
                            origin.clone(),
                        )],
                        Type::Unit,
                        origin,
                    )
                    .expect("the exact pattern boundary is admitted");
            })
            .expect("pattern admission thread should start")
            .join()
            .expect("pattern admission should fit the small stack");
    }

    #[test]
    fn failed_match_arms_admit_and_dispose_deep_result_payloads_on_a_small_stack() {
        std::thread::Builder::new()
            .name("core-match-result-disposal".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("match-result.ash", "()").expect("test source");
                let shallow_origin = generated_origin(&source, 0);
                let mut builder = CoreBuilder::new();
                let value = builder
                    .unit(Type::Unit, shallow_origin.clone())
                    .expect("unit node");

                let error = builder
                    .match_expression(
                        value,
                        vec![CoreMatchArm::new(
                            nested_pattern(&source, CORE_PATTERN_DEPTH_LIMIT + 1),
                            value,
                            shallow_origin,
                        )],
                        function_type(5_000),
                        generated_origin(&source, 5_000),
                    )
                    .expect_err("the arm error retains precedence");
                assert_eq!(error, BuildError::PatternDepthExceeded);
            })
            .expect("match result disposal thread should start")
            .join()
            .expect("all failed match payloads must be disposed iteratively");
    }

    #[test]
    fn wide_pattern_admission_keeps_owned_pending_work_constant() {
        const WIDTH: usize = 100_000;
        const ALLOWANCE: usize = 64;
        let source = SourceFile::new("wide-pattern.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let element = CorePattern::new(Type::Unit, origin.clone(), CorePatternKind::Wildcard);
        let pattern = CorePattern::new(
            Type::Unit,
            origin,
            CorePatternKind::Tuple(vec![element; WIDTH].into_boxed_slice()),
        );
        let mut budget = TypeWorkBudget::default();
        budget
            .charge(crate::types::TYPE_WORK_LIMIT - ALLOWANCE)
            .expect("test setup leaves a small exact allowance");
        reset_pattern_admission_peaks();

        assert_eq!(
            admit_pattern(pattern, &mut budget, &HashSet::new(), false),
            Err(BuildError::TypeWorkExceeded)
        );
        assert!(pattern_admission_pending_peak() <= 3);
    }

    #[test]
    fn pattern_effect_allowance_preserves_pure_rejection_and_exact_work() {
        let source = SourceFile::new("callback-pattern.ash", "()").unwrap();
        let origin = generated_origin(&source, 0);
        let callback = Type::function_computation(
            Type::Unit,
            crate::types::ComputationType::new(
                Type::Int,
                EffectRow::singleton(crate::types::EffectInstance::new(
                    crate::types::EffectId::new(crate::module::ModuleId::new(0), 0),
                    Box::new([]),
                )),
            ),
        );
        let pattern = CorePattern::new(callback, origin, CorePatternKind::Wildcard);
        assert!(matches!(
            admit_pattern(
                pattern.clone(),
                &mut TypeWorkBudget::default(),
                &HashSet::new(),
                false
            ),
            Err(BuildError::InvalidPayload)
        ));
        let mut measured = TypeWorkBudget::unbounded();
        admit_pattern(pattern.clone(), &mut measured, &HashSet::new(), true).unwrap();
        assert!(matches!(
            admit_pattern(
                pattern.clone(),
                &mut TypeWorkBudget::with_limit(measured.used() - 1),
                &HashSet::new(),
                true
            ),
            Err(BuildError::TypeWorkExceeded)
        ));
        let mut retry = TypeWorkBudget::with_limit(measured.used());
        admit_pattern(pattern, &mut retry, &HashSet::new(), true).unwrap();
        assert_eq!(retry.used(), measured.used());
    }

    #[test]
    fn huge_match_arm_groups_retain_only_charged_admitted_arms() {
        const WIDTH: usize = 100_000;
        const ALLOWANCE: usize = 64;
        let source = SourceFile::new("wide-arms.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let arena = ArenaId::new(77);
        let body = NodeId::new(arena, 0);
        let arm = CoreMatchArm::new(
            CorePattern::new(Type::Unit, origin.clone(), CorePatternKind::Wildcard),
            body,
            origin,
        );
        let mut budget = TypeWorkBudget::default();
        budget
            .charge(crate::types::TYPE_WORK_LIMIT - ALLOWANCE)
            .expect("test setup leaves an exact arm allowance");
        reset_pattern_admission_peaks();

        assert_eq!(
            admit_match_arms(vec![arm; WIDTH], &mut budget, &HashSet::new(), false),
            Err(BuildError::TypeWorkExceeded)
        );
        assert!(match_arm_retained_capacity_peak() <= ALLOWANCE);
        assert!(pattern_admission_pending_peak() <= 1);
    }

    #[test]
    fn over_budget_type_admission_dismantles_the_remainder_on_a_small_stack() {
        std::thread::Builder::new()
            .name("core-type-work-boundary".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("type-work.ash", "()").expect("test source");
                let origin = generated_origin(&source, 0);
                let mut builder = CoreBuilder::new();

                assert_eq!(
                    builder.unit(function_type(crate::types::TYPE_WORK_LIMIT + 1), origin,),
                    Err(BuildError::TypeWorkExceeded)
                );
                assert!(builder.arena.is_none());
                assert!(builder.nodes.is_empty());
            })
            .expect("type-work admission thread should start")
            .join()
            .expect("over-budget type admission must fit the small stack");
    }

    #[test]
    fn type_application_dismantles_unvisited_arguments_after_resource_failure() {
        std::thread::Builder::new()
            .name("core-type-argument-boundary".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("type-arguments.ash", "()").expect("test source");
                let origin = generated_origin(&source, 0);
                let mut builder = CoreBuilder::new();
                let function = builder
                    .unit(Type::Unit, origin.clone())
                    .expect("function placeholder");
                builder
                    .type_work
                    .charge(crate::types::TYPE_WORK_LIMIT - 1)
                    .expect("test setup exhausts the type-work budget");
                let before = builder.nodes.len();

                assert_eq!(
                    builder.type_application(
                        function,
                        vec![Type::Int, function_type(crate::types::TYPE_WORK_LIMIT + 1),],
                        Type::Unit,
                        origin,
                    ),
                    Err(BuildError::TypeWorkExceeded)
                );
                assert_eq!(builder.nodes.len(), before);
            })
            .expect("type-argument admission thread should start")
            .join()
            .expect("rejected type arguments must fit the small stack");
    }

    #[test]
    fn type_application_dismantles_result_payload_after_argument_failure() {
        std::thread::Builder::new()
            .name("core-type-application-result-boundary".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("type-result.ash", "()").expect("test source");
                let origin = generated_origin(&source, 0);
                let mut builder = CoreBuilder::new();
                let function = builder
                    .unit(Type::Unit, origin.clone())
                    .expect("function placeholder");
                builder
                    .type_work
                    .charge(crate::types::TYPE_WORK_LIMIT - 1)
                    .expect("test setup exhausts the type-work budget");
                let before = builder.nodes.len();

                assert_eq!(
                    builder.type_application(
                        function,
                        vec![Type::Int],
                        function_type(crate::types::TYPE_WORK_LIMIT + 1),
                        origin,
                    ),
                    Err(BuildError::TypeWorkExceeded)
                );
                assert_eq!(builder.nodes.len(), before);
            })
            .expect("type-application result admission thread should start")
            .join()
            .expect("rejected type-application result must fit the small stack");
    }

    #[test]
    fn type_application_discards_an_admitted_deep_argument_before_a_later_rejection() {
        const DEPTH: usize = 32_768;
        const DEEP_CELLS: usize = DEPTH * 2 + 1;

        std::thread::Builder::new()
            .name("admitted-argument-before-rejection".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("argument-before-error.ash", "()")
                    .expect("the fixture should fit");
                let origin = generated_origin(&source, 0);
                let mut builder = CoreBuilder::new();
                let function = builder
                    .unit(Type::Unit, origin.clone())
                    .expect("the function placeholder should fit");
                builder
                    .type_work
                    .charge(
                        crate::types::TYPE_WORK_LIMIT
                            .saturating_sub(builder.type_work.used())
                            .saturating_sub(DEEP_CELLS),
                    )
                    .expect("the setup should leave exactly one deep argument");

                assert_eq!(
                    builder.type_application(
                        function,
                        vec![application_type(DEPTH), Type::Unit],
                        Type::Unit,
                        origin,
                    ),
                    Err(BuildError::TypeWorkExceeded)
                );
            })
            .expect("the admitted-argument thread should start")
            .join()
            .expect("an admitted argument must be dismantled iteratively after a later error");
    }

    #[test]
    fn type_application_discards_a_deep_argument_admitted_after_an_earlier_rejection() {
        const DEPTH: usize = 32_768;

        std::thread::Builder::new()
            .name("rejection-before-admitted-argument".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("error-before-argument.ash", "()")
                    .expect("the fixture should fit");
                let origin = generated_origin(&source, 0);
                let mut builder = CoreBuilder::new();
                let function = builder
                    .unit(Type::Unit, origin.clone())
                    .expect("the function placeholder should fit");

                assert_eq!(
                    builder.type_application(
                        function,
                        vec![
                            function_type(CORE_PAYLOAD_DEPTH_LIMIT + 1),
                            application_type(DEPTH),
                        ],
                        Type::Unit,
                        origin,
                    ),
                    Err(BuildError::TypeDepthExceeded)
                );
            })
            .expect("the rejected-then-admitted thread should start")
            .join()
            .expect("a later admitted argument must be dismantled iteratively");
    }

    #[test]
    fn type_application_discards_an_admitted_deep_result_after_argument_failure() {
        const DEPTH: usize = 32_768;

        std::thread::Builder::new()
            .name("argument-error-with-admitted-result".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("argument-error-result.ash", "()")
                    .expect("the fixture should fit");
                let origin = generated_origin(&source, 0);
                let mut builder = CoreBuilder::new();
                let function = builder
                    .unit(Type::Unit, origin.clone())
                    .expect("the function placeholder should fit");

                assert_eq!(
                    builder.type_application(
                        function,
                        vec![function_type(CORE_PAYLOAD_DEPTH_LIMIT + 1)],
                        application_type(DEPTH),
                        origin,
                    ),
                    Err(BuildError::TypeDepthExceeded)
                );
            })
            .expect("the admitted-result thread should start")
            .join()
            .expect("an admitted result must be dismantled iteratively after argument failure");
    }

    #[test]
    fn type_abstraction_discards_an_admitted_deep_result_after_parameter_failure() {
        const DEPTH: usize = 32_768;
        const DEEP_CELLS: usize = DEPTH * 2 + 1;

        std::thread::Builder::new()
            .name("parameter-error-with-admitted-result".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("parameter-error-result.ash", "()")
                    .expect("the fixture should fit");
                let origin = generated_origin(&source, 0);
                let mut builder = CoreBuilder::new();
                let body = builder
                    .unit(Type::Unit, origin.clone())
                    .expect("the abstraction body should fit");
                builder
                    .type_work
                    .charge(
                        crate::types::TYPE_WORK_LIMIT
                            .saturating_sub(builder.type_work.used())
                            .saturating_sub(DEEP_CELLS),
                    )
                    .expect("the setup should leave exactly one deep result");
                let parameters = (0..=DEEP_CELLS)
                    .map(|index| {
                        (
                            TypeVariableId::new(
                                u32::try_from(index).expect("the parameter identity should fit"),
                            ),
                            Kind::Type,
                        )
                    })
                    .collect();

                assert_eq!(
                    builder.type_abstraction(parameters, body, application_type(DEPTH), origin,),
                    Err(BuildError::TypeWorkExceeded)
                );
            })
            .expect("the parameter-failure thread should start")
            .join()
            .expect("an admitted abstraction result must be dismantled iteratively");
    }

    #[test]
    fn wide_type_admission_keeps_pending_fan_out_constant() {
        const WIDTH: usize = 4_096;
        let mut type_work = TypeWorkBudget::default();
        type_work
            .charge(crate::types::TYPE_WORK_LIMIT - 2)
            .expect("test setup leaves two type-work cells");
        reset_type_admission_pending_peak();

        let error = admit_type(
            Type::Tuple(vec![Type::Int; WIDTH].into_boxed_slice()),
            &mut type_work,
        )
        .expect_err("wide input must exhaust the cumulative budget");

        assert_eq!(error, BuildError::TypeWorkExceeded);
        assert!(
            type_admission_pending_peak() <= 3,
            "wide fan-out retained {} pending tasks",
            type_admission_pending_peak()
        );
    }

    #[test]
    fn forall_quantifiers_consume_the_exact_admission_budget() {
        let mut type_work = TypeWorkBudget::default();
        type_work
            .charge(crate::types::TYPE_WORK_LIMIT - 6)
            .expect("test setup leaves six type-work cells");
        let parameters = vec![
            (TypeVariableId::new(0), Kind::Type),
            (TypeVariableId::new(1), Kind::Type),
        ]
        .into_boxed_slice();

        admit_type(
            Type::Forall(parameters, Box::new(Type::Unit)),
            &mut type_work,
        )
        .expect(
            "one forall cell, two binder records, two Kind nodes, and one body cell fit exactly",
        );
        assert_eq!(
            admit_type(Type::Unit, &mut type_work),
            Err(BuildError::TypeWorkExceeded)
        );
    }

    #[test]
    fn type_abstraction_binders_consume_the_exact_builder_budget() {
        let source = SourceFile::new("type-abstraction.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let parameters = vec![
            (TypeVariableId::new(0), Kind::Type),
            (TypeVariableId::new(1), Kind::Type),
        ];
        let mut builder = CoreBuilder::new();
        let body = builder
            .unit(Type::Unit, origin.clone())
            .expect("small body");
        builder
            .type_work
            .charge(crate::types::TYPE_WORK_LIMIT - 6)
            .expect("test setup leaves five cells after the body");

        builder
            .type_abstraction(parameters, body, Type::Unit, origin.clone())
            .expect("two binder records, two Kind nodes, and one result type fit exactly");
        assert_eq!(
            builder.unit(Type::Unit, origin),
            Err(BuildError::TypeWorkExceeded)
        );
    }

    #[test]
    fn type_application_arguments_charge_quantifiers_at_the_exact_boundary() {
        let source = SourceFile::new("type-application.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let parameters = vec![
            (TypeVariableId::new(0), Kind::Type),
            (TypeVariableId::new(1), Kind::Type),
        ]
        .into_boxed_slice();
        let mut builder = CoreBuilder::new();
        let function = builder
            .unit(Type::Unit, origin.clone())
            .expect("small function placeholder");
        builder
            .type_work
            .charge(crate::types::TYPE_WORK_LIMIT - 8)
            .expect("test setup leaves seven cells after the function");

        builder
            .type_application(
                function,
                vec![Type::Forall(parameters, Box::new(Type::Unit))],
                Type::Unit,
                origin.clone(),
            )
            .expect(
                "the argument Forall, binder records, Kind nodes, body, and result fit exactly",
            );
        assert_eq!(
            builder.unit(Type::Unit, origin),
            Err(BuildError::TypeWorkExceeded)
        );
    }

    #[test]
    fn rewritten_forall_quantifiers_cross_the_same_admission_boundary() {
        let source = SourceFile::new("rewrite.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let parameters = (0..=crate::types::TYPE_WORK_LIMIT)
            .map(|index| {
                (
                    TypeVariableId::new(u32::try_from(index).expect("parameter identity")),
                    Kind::Type,
                )
            })
            .collect::<Vec<_>>()
            .into_boxed_slice();
        let mut builder = CoreBuilder::new();
        builder.unit(Type::Unit, origin).expect("small stored node");
        let mut replacement = Some(Type::Forall(parameters, Box::new(Type::Unit)));

        let error = builder
            .rewrite_types(|_| Ok(replacement.take().expect("one stored type")))
            .expect_err("rewritten quantifiers must be admitted before storage");

        assert_eq!(error, BuildError::TypeWorkExceeded);
    }

    #[test]
    fn rewritten_type_application_arguments_charge_quantifiers() {
        let source = SourceFile::new("rewrite-argument.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let parameters = (0..=crate::types::TYPE_WORK_LIMIT)
            .map(|index| {
                (
                    TypeVariableId::new(u32::try_from(index).expect("parameter identity")),
                    Kind::Type,
                )
            })
            .collect::<Vec<_>>()
            .into_boxed_slice();
        let mut builder = CoreBuilder::new();
        let function = builder
            .unit(Type::Unit, origin.clone())
            .expect("small function placeholder");
        builder
            .type_application(function, vec![Type::Int], Type::Unit, origin)
            .expect("small type application");
        let mut replacement = Some(Type::Forall(parameters, Box::new(Type::Unit)));
        let mut visited = 0_usize;

        let error = builder
            .rewrite_types(|ty| {
                visited += 1;
                if visited == 3 {
                    Ok(replacement.take().expect("one application argument"))
                } else {
                    Ok(ty.clone())
                }
            })
            .expect_err("rewritten argument quantifiers must be admitted before storage");

        assert_eq!(error, BuildError::TypeWorkExceeded);
    }

    #[test]
    fn pending_cleanup_equations_cannot_escape_source_builder() {
        let source = SourceFile::new("pending-cleanup.ash", "()").unwrap();
        let mut builder = CoreBuilder::new();
        let root = builder
            .unit(Type::Unit, generated_origin(&source, 0))
            .unwrap();
        builder
            .defer_cleanup_row(crate::types::InferenceVariableId::new(0))
            .unwrap();
        assert!(matches!(
            builder.finish(root),
            Err(BuildError::InvalidPayload)
        ));
    }

    #[test]
    fn pending_cleanup_row_requires_rewrite_without_type_inference() {
        let mut builder = CoreBuilder::new();
        assert!(!builder.requires_type_rewrite());
        builder
            .defer_cleanup_row(crate::types::InferenceVariableId::new(0))
            .unwrap();
        assert!(builder.requires_type_rewrite());
        builder.rewrite_types(|ty| Ok(ty.clone())).unwrap();
        assert!(builder.requires_type_rewrite());
        builder.finish_cleanup_rows();
        assert!(!builder.requires_type_rewrite());
    }

    #[test]
    fn builder_tracks_inference_in_patterns_and_type_arguments_during_admission() {
        let source = SourceFile::new("rewrite-status.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let inference = crate::types::InferenceVariableId::new(999);
        let mut builder = CoreBuilder::new();
        let scrutinee = builder
            .unit(Type::Unit, origin.clone())
            .expect("small scrutinee");
        let body = builder
            .unit(Type::Unit, origin.clone())
            .expect("small arm body");
        assert!(!builder.requires_type_rewrite());

        let pattern = CorePattern::new(
            Type::Inference(inference),
            origin.clone(),
            CorePatternKind::Wildcard,
        );
        let matched = builder
            .match_expression(
                scrutinee,
                vec![CoreMatchArm::new(pattern, body, origin.clone())],
                Type::Unit,
                origin.clone(),
            )
            .expect("unchecked pattern admission should retain the type");
        assert!(builder.requires_type_rewrite());

        builder
            .rewrite_types(|ty| match ty {
                Type::Inference(_) => Ok(Type::Unit),
                _ => Ok(ty.clone()),
            })
            .expect("rewriting should remove the admitted inference type");
        assert!(!builder.requires_type_rewrite());

        builder
            .type_application(
                matched,
                vec![Type::Inference(inference)],
                Type::Unit,
                origin,
            )
            .expect("unchecked type argument admission should retain the type");
        assert!(builder.requires_type_rewrite());
    }

    #[test]
    fn storing_an_inference_binder_restores_rewrite_status_after_rewrite() {
        let source = SourceFile::new("binder-rewrite-status.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let mut builder = CoreBuilder::new();
        let binder = builder
            .binder(
                Type::Inference(crate::types::InferenceVariableId::new(999)),
                origin.clone(),
            )
            .expect("unchecked binder admission should retain the type");
        let body = builder
            .unit(Type::Unit, origin.clone())
            .expect("small function body");
        assert!(builder.requires_type_rewrite());

        builder
            .rewrite_types(|ty| Ok(ty.clone()))
            .expect("the stored body has no inference type");
        assert!(!builder.requires_type_rewrite());

        builder
            .function(
                binder,
                body,
                Type::Function(Box::new(Type::Unit), Box::new(Type::Unit)),
                origin,
            )
            .expect("the binder belongs to this arena");
        assert!(builder.requires_type_rewrite());
    }

    #[test]
    fn quantifier_failures_dismantle_unadmitted_types_on_a_small_stack() {
        std::thread::Builder::new()
            .name("core-quantifier-boundary".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("quantifiers.ash", "()").expect("test source");
                let origin = generated_origin(&source, 0);
                let parameters = vec![
                    (TypeVariableId::new(0), Kind::Type),
                    (TypeVariableId::new(1), Kind::Type),
                ];
                let mut builder = CoreBuilder::new();
                let body = builder
                    .unit(Type::Unit, origin.clone())
                    .expect("small abstraction body");
                builder
                    .type_work
                    .charge(crate::types::TYPE_WORK_LIMIT - 2)
                    .expect("test setup leaves one type-work cell after the body");

                assert_eq!(
                    builder.type_abstraction(parameters, body, function_type(50_000), origin,),
                    Err(BuildError::TypeWorkExceeded)
                );
            })
            .expect("quantifier admission thread should start")
            .join()
            .expect("quantifier rejection must fit the small stack");
    }

    #[test]
    fn payload_limit_and_deep_rejection_are_stack_safe_and_transactional() {
        std::thread::Builder::new()
            .name("core-payload-boundary".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("payload.ash", "()").expect("test source");
                let shallow = generated_origin(&source, 0);

                let mut builder = CoreBuilder::new();
                assert_eq!(
                    builder.unit(function_type(CORE_PAYLOAD_DEPTH_LIMIT + 1), shallow.clone(),),
                    Err(BuildError::TypeDepthExceeded)
                );
                assert!(builder.arena.is_none());
                assert!(builder.nodes.is_empty());

                assert_eq!(
                    builder.unit(
                        Type::Unit,
                        generated_origin(&source, CORE_PAYLOAD_DEPTH_LIMIT + 1),
                    ),
                    Err(BuildError::OriginDepthExceeded)
                );
                assert_eq!(
                    builder.unit(
                        Type::Unit,
                        related_origin(&source, CORE_PAYLOAD_DEPTH_LIMIT + 1),
                    ),
                    Err(BuildError::OriginDepthExceeded)
                );

                assert_eq!(
                    builder.unit(function_type(50_000), shallow.clone(),),
                    Err(BuildError::TypeDepthExceeded)
                );
                assert!(builder.arena.is_none());
                assert!(builder.nodes.is_empty());

                assert_eq!(
                    builder.unit(Type::Unit, generated_origin(&source, 50_000)),
                    Err(BuildError::OriginDepthExceeded)
                );
                assert_eq!(
                    builder.unit(Type::Unit, related_origin(&source, 50_000)),
                    Err(BuildError::OriginDepthExceeded)
                );
                assert_eq!(
                    builder.unit(function_type(50_000), generated_origin(&source, 50_000),),
                    Err(BuildError::TypeDepthExceeded)
                );
                assert_eq!(
                    builder.binder(Type::Unit, generated_origin(&source, 50_000)),
                    Err(BuildError::OriginDepthExceeded)
                );
                assert!(builder.arena.is_none());
                assert!(builder.nodes.is_empty());
                assert_eq!(builder.next_binder, 0);
                assert!(builder.reserved_resolved.is_empty());
                assert!(builder.materialized_resolved.is_empty());
                assert!(builder.generated_binders.is_empty());
                assert!(!builder.binder_phase_started);
            })
            .expect("test thread should start")
            .join()
            .expect("payload admission should not overflow its small stack");
    }

    #[test]
    fn exact_payload_limit_validates_and_drops_on_a_small_stack() {
        std::thread::Builder::new()
            .name("core-payload-exact-limit".to_owned())
            .stack_size(256 * 1024)
            .spawn(|| {
                let source = SourceFile::new("payload.ash", "()").expect("test source");
                let shallow = generated_origin(&source, 0);
                let mut builder = CoreBuilder::new();
                let mut root = builder
                    .unit(
                        Type::Unit,
                        generated_origin(&source, CORE_PAYLOAD_DEPTH_LIMIT),
                    )
                    .expect("exact origin depth is admitted");
                for depth in 1..=CORE_PAYLOAD_DEPTH_LIMIT {
                    let parameter = builder
                        .binder(Type::Unit, shallow.clone())
                        .expect("bounded binder");
                    root = builder
                        .function(parameter, root, function_type(depth), shallow.clone())
                        .expect("exact type depth is admitted");
                }
                let related = builder
                    .unit(
                        Type::Unit,
                        related_origin(&source, CORE_PAYLOAD_DEPTH_LIMIT),
                    )
                    .expect("exact related-origin depth is admitted");
                let binder = builder
                    .binder(Type::Unit, shallow.clone())
                    .expect("bounded binder");
                let root = builder
                    .binding(
                        binder,
                        related,
                        root,
                        function_type(CORE_PAYLOAD_DEPTH_LIMIT),
                        shallow,
                    )
                    .expect("exact result type depth is admitted");
                let program = builder.finish(root).expect("valid root");
                super::super::validate::validate(program, &[&source])
                    .expect("exact-limit Core validates");
            })
            .expect("test thread should start")
            .join()
            .expect("exact-limit Core should validate and drop on a small stack");
    }

    #[test]
    fn reserved_resolved_namespace_and_generated_identities_do_not_collide() {
        let source = SourceFile::new("binder.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let mut builder = CoreBuilder::new();
        builder
            .reserve_resolved_binders([resolved_id(0), resolved_id(1)])
            .expect("complete resolved namespace is reserved");
        assert_eq!(
            builder.resolved_binder(
                resolved_id(0),
                function_type(CORE_PAYLOAD_DEPTH_LIMIT + 1),
                origin.clone(),
            ),
            Err(BuildError::TypeDepthExceeded)
        );
        let resolved = builder
            .resolved_binder(resolved_id(0), Type::Unit, origin.clone())
            .expect("first resolved identity is admitted");
        let generated = builder
            .binder(Type::Unit, origin.clone())
            .expect("fresh generated identity");
        let second_resolved = builder
            .resolved_binder(resolved_id(1), Type::Unit, origin.clone())
            .expect("later reserved identity remains materializable");

        assert_ne!(resolved.id(), generated.id());
        assert_ne!(second_resolved.id(), generated.id());
        assert_eq!(generated.id(), BinderId::generated(0));
        assert_eq!(
            builder.resolved_binder(resolved_id(0), Type::Unit, origin),
            Err(BuildError::DuplicateResolvedBinder)
        );
    }

    #[test]
    fn sparse_high_reservation_keeps_low_generated_ids_available() {
        let source = SourceFile::new("binder.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let mut builder = CoreBuilder::new();
        builder
            .reserve_resolved_binders([resolved_id(u32::MAX - 1)])
            .expect("high resolved identity is reserved");

        let generated = builder
            .binder(Type::Unit, origin)
            .expect("low generated identity remains available");
        assert_eq!(generated.id(), BinderId::generated(0));
    }

    #[test]
    fn reservation_is_transactional_and_closes_after_allocation_starts() {
        let source = SourceFile::new("binder.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let mut builder = CoreBuilder::new();
        builder
            .reserve_resolved_binders([resolved_id(2)])
            .expect("first reservation");
        assert_eq!(
            builder.reserve_resolved_binders([resolved_id(3), resolved_id(3)]),
            Err(BuildError::DuplicateBinderReservation)
        );
        assert!(!builder.reserved_resolved.contains(&resolved_id(3)));

        builder
            .binder(Type::Unit, origin)
            .expect("generated allocation starts the binder phase");
        assert_eq!(
            builder.reserve_resolved_binders([resolved_id(4)]),
            Err(BuildError::BinderReservationPhaseStarted)
        );
        assert!(!builder.reserved_resolved.contains(&resolved_id(4)));
    }

    #[test]
    fn resolved_materialization_requires_reservation_and_is_unique() {
        let source = SourceFile::new("binder.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let mut builder = CoreBuilder::new();
        assert_eq!(
            builder.resolved_binder(resolved_id(0), Type::Unit, origin.clone()),
            Err(BuildError::UnreservedResolvedBinder)
        );
        builder
            .reserve_resolved_binders([resolved_id(0)])
            .expect("resolved identity is reserved");
        builder
            .resolved_binder(resolved_id(0), Type::Unit, origin.clone())
            .expect("first materialization");
        assert_eq!(
            builder.resolved_binder(resolved_id(0), Type::Unit, origin),
            Err(BuildError::DuplicateResolvedBinder)
        );
    }

    #[test]
    fn binder_allocator_reserves_maximum_as_its_exhaustion_sentinel() {
        let source = SourceFile::new("binder.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let mut builder = CoreBuilder::new();
        builder.next_binder = u32::MAX - 1;

        let last = builder
            .binder(Type::Unit, origin.clone())
            .expect("last allocatable binder");
        assert_eq!(last.id(), BinderId::generated(u32::MAX - 1));
        assert_eq!(
            builder.binder(Type::Unit, origin),
            Err(BuildError::BinderIdExhausted)
        );
        assert!(!builder.generated_binders.contains(&BinderId::new(u32::MAX)));
    }

    #[test]
    fn failed_reserved_payload_admission_can_be_retried() {
        let source = SourceFile::new("binder.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let id = resolved_id(7);
        let mut builder = CoreBuilder::new();
        builder
            .reserve_resolved_binders([id])
            .expect("resolved identity is reserved");
        assert_eq!(
            builder.resolved_binder(
                id,
                function_type(CORE_PAYLOAD_DEPTH_LIMIT + 1),
                origin.clone(),
            ),
            Err(BuildError::TypeDepthExceeded)
        );
        assert!(!builder.materialized_resolved.contains(&id));

        let binder = builder
            .resolved_binder(id, Type::Unit, origin)
            .expect("retry materializes the reserved identity");
        assert_eq!(binder.id(), id);
    }

    #[test]
    fn effect_clause_admission_is_exact_atomic_and_retryable() {
        use crate::{
            core::effect::{EffectClause, EffectOperationFamily, HandlerId},
            resolved::ResumeId,
            types::{EffectId, EffectInstance, EffectRow, OperationId},
        };

        let source = SourceFile::new("effect-clause-budget.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let effect = EffectId::new(ModuleId::new(0), 0);
        let prepare = || {
            let mut builder = CoreBuilder::<EffectOperationFamily>::with_effect_registry(Arc::new(
                ResolvedRegistry::default(),
            ));
            let body = builder
                .unit(Type::Unit, origin.clone())
                .expect("handler body should fit");
            let clause = EffectClause::new(
                OperationId::new(effect, 0),
                ResumeId::new(0),
                CoreMatchArm::new(
                    CorePattern::new(Type::Unit, origin.clone(), CorePatternKind::Wildcard),
                    body,
                    origin.clone(),
                ),
            );
            (builder, body, clause)
        };
        let admit = |builder: &mut CoreBuilder<EffectOperationFamily>, body, clause| {
            builder.handler(
                HandlerId::new(0),
                body,
                EffectInstance::new(effect, Box::new([])),
                vec![clause],
                Type::Unit,
                EffectRow::empty(),
                origin.clone(),
            )
        };

        let (mut measured, body, clause) = prepare();
        let before = measured.type_work.used();
        admit(&mut measured, body, clause).expect("measured clause admission should fit");
        let admission_work = measured.type_work.used() - before;
        assert_eq!(
            admission_work, 4,
            "one clause carrier plus pattern, result-type, and result-row admission"
        );

        let (mut short, body, clause) = prepare();
        let retained_before = short.nodes.len();
        short
            .charge_type_work_for_test(
                TYPE_WORK_LIMIT - short.type_work.used() - (admission_work - 1),
            )
            .expect("one-short prefix should fit");
        assert_eq!(
            admit(&mut short, body, clause),
            Err(BuildError::TypeWorkExceeded)
        );
        assert_eq!(
            short.nodes.len(),
            retained_before,
            "failure publishes no node"
        );

        for _ in 0..2 {
            let (mut exact, body, clause) = prepare();
            exact
                .charge_type_work_for_test(
                    TYPE_WORK_LIMIT - exact.type_work.used() - admission_work,
                )
                .expect("exact prefix should fit");
            admit(&mut exact, body, clause).expect("a fresh exact admission should retry");
            assert_eq!(exact.type_work.used(), TYPE_WORK_LIMIT);
        }
    }

    #[test]
    fn effect_row_type_application_admission_is_exact_atomic_and_retryable() {
        use crate::core::effect::EffectOperationFamily;

        let source = SourceFile::new("row-application-budget.ash", "()").expect("test source");
        let origin = generated_origin(&source, 0);
        let prepare = || {
            let mut builder = CoreBuilder::<EffectOperationFamily>::with_effect_registry(Arc::new(
                ResolvedRegistry::default(),
            ));
            let function = builder
                .unit(Type::Unit, origin.clone())
                .expect("function placeholder");
            (builder, function)
        };
        let admit = |builder: &mut CoreBuilder<EffectOperationFamily>, function| {
            builder.type_application_with_row_arguments(
                function,
                Vec::new(),
                vec![EffectRow::open(
                    EffectRowVariable::rigid(TypeVariableId::new(0)),
                    Box::new([]),
                )],
                Type::Unit,
                origin.clone(),
            )
        };

        let (mut measured, function) = prepare();
        let before = measured.type_work.used();
        admit(&mut measured, function).expect("measured row admission");
        let work = measured.type_work.used() - before;

        let (mut short, function) = prepare();
        let retained = short.nodes.len();
        short
            .charge_type_work_for_test(TYPE_WORK_LIMIT - short.type_work.used() - (work - 1))
            .expect("one-short prefix");
        assert_eq!(
            admit(&mut short, function),
            Err(BuildError::TypeWorkExceeded)
        );
        assert_eq!(short.nodes.len(), retained);

        for _ in 0..2 {
            let (mut exact, function) = prepare();
            exact
                .charge_type_work_for_test(TYPE_WORK_LIMIT - exact.type_work.used() - work)
                .expect("exact prefix");
            admit(&mut exact, function).expect("fresh exact retry");
            assert_eq!(exact.type_work.used(), TYPE_WORK_LIMIT);
        }
    }
}
