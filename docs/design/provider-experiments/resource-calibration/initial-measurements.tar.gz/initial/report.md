# Resource calibration measurements

Experimental measurements; no production policy change.

| Case | Accepted for model | Work Source | Work Core | Wall on/off median seconds | Peak RSS on/off KiB |
| --- | --- | ---: | ---: | --- | --- |
| flat-width1 | True | 141 | 232 | 0.0 / 0.0 | 12672 / 12464 |
| flat-width2 | True | 221 | 337 | 0.0 / 0.0 | 12784 / 12572 |
| flat-width4 | True | 381 | 547 | 0.0 / 0.0 | 12440 / 12568 |
| flat-width8 | True | 701 | 967 | 0.0 / 0.0 | 12408 / 12580 |
| flat-width16 | True | 1341 | 1807 | 0.0 / 0.0 | 12808 / 12568 |
| flat-width32 | True | 2621 | 3487 | 0.0 / 0.0 | 12812 / 12980 |
| flat-width64 | True | 5181 | 6847 | 0.01 / 0.01 | 13524 / 13388 |
| flat-width128 | True | 10301 | 13567 | 0.01 / 0.01 | 14288 / 13952 |
| nested_type-depth1 | True | 673 | 748 | 0.0 / 0.0 | 12948 / 13200 |
| nested_type-depth2 | True | 990 | 1101 | 0.0 / 0.0 | 12960 / 13156 |
| nested_type-depth4 | True | 1714 | 1975 | 0.0 / 0.0 | 13000 / 13336 |
| nested_type-depth8 | True | 3522 | 4395 | 0.0 / 0.0 | 13408 / 13280 |
| nested_type-depth12 | True | 5810 | 7711 | 0.0 / 0.0 | 13376 / 13004 |
| nested_type-depth16 | True | 8578 | 11923 | 0.0 / 0.0 | 13272 / 13176 |
| prerequisite-depth1 | True | 2536 | 1266 | 0.0 / 0.0 | 14468 / 14472 |
| prerequisite-depth2 | True | 2957 | 1813 | 0.0 / 0.0 | 14516 / 14784 |
| prerequisite-depth4 | True | 3949 | 3378 | 0.0 / 0.0 | 14656 / 14888 |
| prerequisite-depth8 | True | 6533 | 8392 | 0.0 / 0.0 | 15168 / 14556 |
| prerequisite-depth12 | True | 9917 | 15918 | 0.01 / 0.0 | 14872 / 14964 |
| prerequisite-depth16 | True | 14101 | 25956 | 0.01 / 0.01 | 15176 / 14792 |
| reexport_width-width1-depth2 | True | 698 | 223 | 0.0 / 0.0 | 14488 / 14484 |
| reexport_width-width2-depth2 | True | 1165 | 273 | 0.0 / 0.0 | 13984 / 14536 |
| reexport_width-width4-depth2 | True | 2099 | 373 | 0.0 / 0.0 | 13992 / 14220 |
| reexport_width-width8-depth2 | True | 3967 | 573 | 0.0 / 0.0 | 14408 / 14100 |
| reexport_width-width16-depth2 | True | 7703 | 973 | 0.01 / 0.0 | 14124 / 14652 |
| reexport_width-width32-depth2 | True | 15175 | 1773 | 0.01 / 0.01 | 14676 / 14584 |
| reexport_depth-width1-depth1 | True | 605 | 223 | 0.0 / 0.0 | 14420 / 14460 |
| reexport_depth-width1-depth2 | True | 698 | 223 | 0.0 / 0.0 | 13848 / 13860 |
| reexport_depth-width1-depth4 | True | 887 | 223 | 0.0 / 0.0 | 14428 / 13956 |
| reexport_depth-width1-depth8 | True | 1277 | 223 | 0.01 / 0.0 | 14152 / 14480 |
| reexport_depth-width1-depth12 | True | 1683 | 223 | 0.01 / 0.0 | 14064 / 13964 |
| reexport_depth-width1-depth16 | True | 2105 | 223 | 0.01 / 0.0 | 13964 / 14088 |
| string_payload-payload_bytes16 | True | 69 | 168 | 0.0 / 0.0 | 12408 / 12564 |
| string_payload-payload_bytes1024 | True | 69 | 1176 | 0.0 / 0.0 | 12616 / 12472 |
| string_payload-payload_bytes65536 | True | 69 | 65688 | 0.0 / 0.0 | 12872 / 12664 |
| sqlite-copying | True | 1212707 | 903995 | 0.19 / 0.18 | 34184 / 34416 |
| sqlite-persistence | True | 597882 | 1609087 | 0.22 / 0.22 | 43116 / 43284 |
| sqlite-resume | True | 203215 | 289063 | 0.06 / 0.06 | 23332 / 23196 |
| sqlite-bound_nul | True | 1212707 | 903990 | 0.21 / 0.2 | 34224 / 34212 |
| sqlite-forwarding | True | 216584 | 315193 | 0.06 / 0.06 | 22492 / 22788 |
| resource_width-width1 | True | 111611 | 11811 | 0.02 / 0.02 | 18604 / 18744 |
| resource_width-width2 | True | 117567 | 19066 | 0.03 / 0.02 | 18516 / 18632 |
| resource_width-width4 | True | 129654 | 33984 | 0.03 / 0.03 | 19004 / 19016 |
| resource_width-width8 | True | 154388 | 65788 | 0.03 / 0.03 | 19488 / 19760 |

Each six-owner work vector, phase boundary RSS, median/min/max, observer overhead, failures, models, residuals and held-out coverage is in `summary.json`.

Models use case medians. The simple model uses source nodes; the enriched model uses named immutable graph features. A fitted model is provisional: its envelope is twice the sum of its fitted value and training-only positive residual cushion, with a finite cap. Rank or sample insufficiency prevents an allowance estimate.

- resolution: size provisional; complexity provisional.
- source-checking: size provisional; complexity provisional.
- module-linking: size provisional; complexity provisional.
- linked-interface: size provisional; complexity provisional.
- final-elaboration: size provisional; complexity provisional.
- independent-effect-core: size provisional; complexity provisional.

External time excludes builds; each observation has a fresh process.
Boundary RSS is not a phase peak; process peak RSS is cumulative.
Phase wall sums can overlap with containing phases; do not sum them into pipeline time.
Missing or aborted work endpoints are absent, never zero.
Envelopes use each case maximum raw work, preserving fresh-process capacity variation.
GNU time wall and CPU values have centisecond resolution; phase timers have finer resolution.
Both observer modes retain feature-enabled budget override machinery.
Controls use the same executable and finite diagnostic allowance as observation-on.
Models exclude failed, uncontrolled and held-out cases from fitting.
Family growth must be reviewed before adopting any empirical envelope.
