main : Unit -> Int
main () = {
let payload = "xxxxxxxxxxxxxxxx"
42
}
