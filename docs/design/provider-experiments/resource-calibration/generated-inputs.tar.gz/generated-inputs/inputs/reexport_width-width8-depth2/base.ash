pub interface Marker0<A> {
mark0 : A -> A
}

pub impl Marker0<Int> {
mark0 value = value
}

pub interface Marker1<A> {
mark1 : A -> A
}

pub impl Marker1<Int> {
mark1 value = value
}

pub interface Marker2<A> {
mark2 : A -> A
}

pub impl Marker2<Int> {
mark2 value = value
}

pub interface Marker3<A> {
mark3 : A -> A
}

pub impl Marker3<Int> {
mark3 value = value
}

pub interface Marker4<A> {
mark4 : A -> A
}

pub impl Marker4<Int> {
mark4 value = value
}

pub interface Marker5<A> {
mark5 : A -> A
}

pub impl Marker5<Int> {
mark5 value = value
}

pub interface Marker6<A> {
mark6 : A -> A
}

pub impl Marker6<Int> {
mark6 value = value
}

pub interface Marker7<A> {
mark7 : A -> A
}

pub impl Marker7<Int> {
mark7 value = value
}

