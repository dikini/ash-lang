pub import layer1 (Marker0, mark0, impl Marker0, Marker1, mark1, impl Marker1, Marker2, mark2, impl Marker2, Marker3, mark3, impl Marker3, Marker4, mark4, impl Marker4, Marker5, mark5, impl Marker5, Marker6, mark6, impl Marker6, Marker7, mark7, impl Marker7)
pub import layer1 (impl Marker0, impl Marker1, impl Marker2, impl Marker3, impl Marker4, impl Marker5, impl Marker6, impl Marker7)
main : Unit -> Int
main () = mark0(42)
