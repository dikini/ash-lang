identity0 : Int -> Int
identity0 value = value

identity1 : Int -> Int
identity1 value = value

main : Unit -> Int
main () = {
let ignored0 = identity0 42
let ignored1 = identity1 42
42
}
