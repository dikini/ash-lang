pub import layer15 (Marker0, mark0, impl Marker0)
pub import layer15 (impl Marker0)
main : Unit -> Int
main () = mark0(42)
