pub interface Marker0<A> {
mark0 : A -> A
}

pub impl Marker0<Int> {
mark0 value = value
}

pub interface Marker1<A> {
mark1 : A -> A
}

pub impl Marker1<Int> {
mark1 value = value
}

pub interface Marker2<A> {
mark2 : A -> A
}

pub impl Marker2<Int> {
mark2 value = value
}

pub interface Marker3<A> {
mark3 : A -> A
}

pub impl Marker3<Int> {
mark3 value = value
}

