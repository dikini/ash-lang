pub import layer1 (Marker0, mark0, impl Marker0, Marker1, mark1, impl Marker1, Marker2, mark2, impl Marker2, Marker3, mark3, impl Marker3)
pub import layer1 (impl Marker0, impl Marker1, impl Marker2, impl Marker3)
main : Unit -> Int
main () = mark0(42)
