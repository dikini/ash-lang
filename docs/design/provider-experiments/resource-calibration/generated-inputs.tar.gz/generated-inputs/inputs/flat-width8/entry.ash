identity0 : Int -> Int
identity0 value = value

identity1 : Int -> Int
identity1 value = value

identity2 : Int -> Int
identity2 value = value

identity3 : Int -> Int
identity3 value = value

identity4 : Int -> Int
identity4 value = value

identity5 : Int -> Int
identity5 value = value

identity6 : Int -> Int
identity6 value = value

identity7 : Int -> Int
identity7 value = value

main : Unit -> Int
main () = {
let ignored0 = identity0 42
let ignored1 = identity1 42
let ignored2 = identity2 42
let ignored3 = identity3 42
let ignored4 = identity4 42
let ignored5 = identity5 42
let ignored6 = identity6 42
let ignored7 = identity7 42
42
}
