type Option<A> =
None
| Some(A)

identity<A> : A -> A
identity value = value

probe : Option<Option<Int>> -> Option<Option<Int>>
probe value = identity value

main : Unit -> Int
main () = {
let value : Option<Option<Int>> = Some(Some(42))
let kept : Option<Option<Int>> = probe value
42
}
