identity0 : Int -> Int
identity0 value = value

main : Unit -> Int
main () = {
let ignored0 = identity0 42
42
}
