pub interface Marker0<A> {
mark0 : A -> A
}

pub impl Marker0<Int> {
mark0 value = value
}

pub interface Marker1<A> {
mark1 : A -> A
}

pub impl Marker1<Int> {
mark1 value = value
}

pub interface Marker2<A> {
mark2 : A -> A
}

pub impl Marker2<Int> {
mark2 value = value
}

pub interface Marker3<A> {
mark3 : A -> A
}

pub impl Marker3<Int> {
mark3 value = value
}

pub interface Marker4<A> {
mark4 : A -> A
}

pub impl Marker4<Int> {
mark4 value = value
}

pub interface Marker5<A> {
mark5 : A -> A
}

pub impl Marker5<Int> {
mark5 value = value
}

pub interface Marker6<A> {
mark6 : A -> A
}

pub impl Marker6<Int> {
mark6 value = value
}

pub interface Marker7<A> {
mark7 : A -> A
}

pub impl Marker7<Int> {
mark7 value = value
}

pub interface Marker8<A> {
mark8 : A -> A
}

pub impl Marker8<Int> {
mark8 value = value
}

pub interface Marker9<A> {
mark9 : A -> A
}

pub impl Marker9<Int> {
mark9 value = value
}

pub interface Marker10<A> {
mark10 : A -> A
}

pub impl Marker10<Int> {
mark10 value = value
}

pub interface Marker11<A> {
mark11 : A -> A
}

pub impl Marker11<Int> {
mark11 value = value
}

pub interface Marker12<A> {
mark12 : A -> A
}

pub impl Marker12<Int> {
mark12 value = value
}

pub interface Marker13<A> {
mark13 : A -> A
}

pub impl Marker13<Int> {
mark13 value = value
}

pub interface Marker14<A> {
mark14 : A -> A
}

pub impl Marker14<Int> {
mark14 value = value
}

pub interface Marker15<A> {
mark15 : A -> A
}

pub impl Marker15<Int> {
mark15 value = value
}

pub interface Marker16<A> {
mark16 : A -> A
}

pub impl Marker16<Int> {
mark16 value = value
}

pub interface Marker17<A> {
mark17 : A -> A
}

pub impl Marker17<Int> {
mark17 value = value
}

pub interface Marker18<A> {
mark18 : A -> A
}

pub impl Marker18<Int> {
mark18 value = value
}

pub interface Marker19<A> {
mark19 : A -> A
}

pub impl Marker19<Int> {
mark19 value = value
}

pub interface Marker20<A> {
mark20 : A -> A
}

pub impl Marker20<Int> {
mark20 value = value
}

pub interface Marker21<A> {
mark21 : A -> A
}

pub impl Marker21<Int> {
mark21 value = value
}

pub interface Marker22<A> {
mark22 : A -> A
}

pub impl Marker22<Int> {
mark22 value = value
}

pub interface Marker23<A> {
mark23 : A -> A
}

pub impl Marker23<Int> {
mark23 value = value
}

pub interface Marker24<A> {
mark24 : A -> A
}

pub impl Marker24<Int> {
mark24 value = value
}

pub interface Marker25<A> {
mark25 : A -> A
}

pub impl Marker25<Int> {
mark25 value = value
}

pub interface Marker26<A> {
mark26 : A -> A
}

pub impl Marker26<Int> {
mark26 value = value
}

pub interface Marker27<A> {
mark27 : A -> A
}

pub impl Marker27<Int> {
mark27 value = value
}

pub interface Marker28<A> {
mark28 : A -> A
}

pub impl Marker28<Int> {
mark28 value = value
}

pub interface Marker29<A> {
mark29 : A -> A
}

pub impl Marker29<Int> {
mark29 value = value
}

pub interface Marker30<A> {
mark30 : A -> A
}

pub impl Marker30<Int> {
mark30 value = value
}

pub interface Marker31<A> {
mark31 : A -> A
}

pub impl Marker31<Int> {
mark31 value = value
}

