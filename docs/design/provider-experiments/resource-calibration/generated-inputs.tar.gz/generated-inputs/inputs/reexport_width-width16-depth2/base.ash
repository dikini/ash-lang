pub interface Marker0<A> {
mark0 : A -> A
}

pub impl Marker0<Int> {
mark0 value = value
}

pub interface Marker1<A> {
mark1 : A -> A
}

pub impl Marker1<Int> {
mark1 value = value
}

pub interface Marker2<A> {
mark2 : A -> A
}

pub impl Marker2<Int> {
mark2 value = value
}

pub interface Marker3<A> {
mark3 : A -> A
}

pub impl Marker3<Int> {
mark3 value = value
}

pub interface Marker4<A> {
mark4 : A -> A
}

pub impl Marker4<Int> {
mark4 value = value
}

pub interface Marker5<A> {
mark5 : A -> A
}

pub impl Marker5<Int> {
mark5 value = value
}

pub interface Marker6<A> {
mark6 : A -> A
}

pub impl Marker6<Int> {
mark6 value = value
}

pub interface Marker7<A> {
mark7 : A -> A
}

pub impl Marker7<Int> {
mark7 value = value
}

pub interface Marker8<A> {
mark8 : A -> A
}

pub impl Marker8<Int> {
mark8 value = value
}

pub interface Marker9<A> {
mark9 : A -> A
}

pub impl Marker9<Int> {
mark9 value = value
}

pub interface Marker10<A> {
mark10 : A -> A
}

pub impl Marker10<Int> {
mark10 value = value
}

pub interface Marker11<A> {
mark11 : A -> A
}

pub impl Marker11<Int> {
mark11 value = value
}

pub interface Marker12<A> {
mark12 : A -> A
}

pub impl Marker12<Int> {
mark12 value = value
}

pub interface Marker13<A> {
mark13 : A -> A
}

pub impl Marker13<Int> {
mark13 value = value
}

pub interface Marker14<A> {
mark14 : A -> A
}

pub impl Marker14<Int> {
mark14 value = value
}

pub interface Marker15<A> {
mark15 : A -> A
}

pub impl Marker15<Int> {
mark15 value = value
}

