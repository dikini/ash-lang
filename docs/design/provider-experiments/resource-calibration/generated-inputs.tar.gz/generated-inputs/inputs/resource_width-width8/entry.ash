import provider as Provider
import sqlite as Sqlite

session0 : Unit -> Provider.Scope<Sqlite.OpenError, Sqlite.CloseError, Int>
session0 () = resource Sqlite.Connection<C0> db0 = Sqlite.InMemory {
42
}

session1 : Unit -> Provider.Scope<Sqlite.OpenError, Sqlite.CloseError, Int>
session1 () = resource Sqlite.Connection<C1> db1 = Sqlite.InMemory {
42
}

session2 : Unit -> Provider.Scope<Sqlite.OpenError, Sqlite.CloseError, Int>
session2 () = resource Sqlite.Connection<C2> db2 = Sqlite.InMemory {
42
}

session3 : Unit -> Provider.Scope<Sqlite.OpenError, Sqlite.CloseError, Int>
session3 () = resource Sqlite.Connection<C3> db3 = Sqlite.InMemory {
42
}

session4 : Unit -> Provider.Scope<Sqlite.OpenError, Sqlite.CloseError, Int>
session4 () = resource Sqlite.Connection<C4> db4 = Sqlite.InMemory {
42
}

session5 : Unit -> Provider.Scope<Sqlite.OpenError, Sqlite.CloseError, Int>
session5 () = resource Sqlite.Connection<C5> db5 = Sqlite.InMemory {
42
}

session6 : Unit -> Provider.Scope<Sqlite.OpenError, Sqlite.CloseError, Int>
session6 () = resource Sqlite.Connection<C6> db6 = Sqlite.InMemory {
42
}

session7 : Unit -> Provider.Scope<Sqlite.OpenError, Sqlite.CloseError, Int>
session7 () = resource Sqlite.Connection<C7> db7 = Sqlite.InMemory {
42
}

main : Unit -> Int
main () = {
let report0 = session0 ()
let report1 = session1 ()
let report2 = session2 ()
let report3 = session3 ()
let report4 = session4 ()
let report5 = session5 ()
let report6 = session6 ()
let report7 = session7 ()
42
}
