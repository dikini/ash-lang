pub import layer1 (Marker0, mark0, impl Marker0, Marker1, mark1, impl Marker1)
pub import layer1 (impl Marker0, impl Marker1)
main : Unit -> Int
main () = mark0(42)
