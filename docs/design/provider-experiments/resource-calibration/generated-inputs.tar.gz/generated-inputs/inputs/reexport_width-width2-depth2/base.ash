pub interface Marker0<A> {
mark0 : A -> A
}

pub impl Marker0<Int> {
mark0 value = value
}

pub interface Marker1<A> {
mark1 : A -> A
}

pub impl Marker1<Int> {
mark1 value = value
}

