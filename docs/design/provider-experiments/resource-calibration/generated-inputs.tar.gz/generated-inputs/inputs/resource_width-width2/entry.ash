import provider as Provider
import sqlite as Sqlite

session0 : Unit -> Provider.Scope<Sqlite.OpenError, Sqlite.CloseError, Int>
session0 () = resource Sqlite.Connection<C0> db0 = Sqlite.InMemory {
42
}

session1 : Unit -> Provider.Scope<Sqlite.OpenError, Sqlite.CloseError, Int>
session1 () = resource Sqlite.Connection<C1> db1 = Sqlite.InMemory {
42
}

main : Unit -> Int
main () = {
let report0 = session0 ()
let report1 = session1 ()
42
}
