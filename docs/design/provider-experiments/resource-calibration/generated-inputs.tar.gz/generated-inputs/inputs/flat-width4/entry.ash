identity0 : Int -> Int
identity0 value = value

identity1 : Int -> Int
identity1 value = value

identity2 : Int -> Int
identity2 value = value

identity3 : Int -> Int
identity3 value = value

main : Unit -> Int
main () = {
let ignored0 = identity0 42
let ignored1 = identity1 42
let ignored2 = identity2 42
let ignored3 = identity3 42
42
}
