import provider as Provider
import sqlite as Sqlite

session0 : Unit -> Provider.Scope<Sqlite.OpenError, Sqlite.CloseError, Int>
session0 () = resource Sqlite.Connection<C0> db0 = Sqlite.InMemory {
42
}

main : Unit -> Int
main () = {
let report0 = session0 ()
42
}
