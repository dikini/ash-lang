# Resource calibration measurements

Experimental measurements; no production policy change.

| Case | Accepted for model | Work Source | Work Core | Wall on/off median seconds | Peak RSS on/off KiB |
| --- | --- | ---: | ---: | --- | --- |
| flat-width1 | True | 141 | 232 | 0.0 / 0.0 | 12500 / 12516 |
| nested_type-depth1 | True | 673 | 748 | 0.0 / 0.0 | 12656 / 12968 |
| prerequisite-depth1 | True | 2536 | 1266 | 0.0 / 0.0 | 14328 / 14476 |
| reexport_width-width1-depth2 | True | 698 | 223 | 0.01 / 0.0 | 14432 / 13644 |
| reexport_depth-width1-depth1 | True | 605 | 223 | 0.0 / 0.0 | 13880 / 13904 |
| string_payload-payload_bytes16 | True | 69 | 168 | 0.0 / 0.0 | 12600 / 12472 |
| sqlite-copying | True | 1212707 | 903995 | 0.24 / 0.24 | 34636 / 34268 |
| sqlite-persistence | True | 597882 | 1609085 | 0.28 / 0.28 | 43140 / 43332 |
| sqlite-resume | True | 203215 | 289063 | 0.08 / 0.07 | 23260 / 22764 |
| sqlite-bound_nul | True | 1212707 | 903990 | 0.24 / 0.25 | 34472 / 33916 |
| sqlite-forwarding | True | 216584 | 315193 | 0.08 / 0.08 | 22976 / 22672 |
| resource_width-width1 | True | 111611 | 11811 | 0.03 / 0.03 | 18912 / 18748 |

Each six-owner work vector, phase boundary RSS, median/min/max, observer overhead, failures, models, residuals and held-out coverage is in `summary.json`.

Models use case medians. The simple model uses source nodes; the enriched model uses named immutable graph features. A fitted model is provisional: its envelope is twice the sum of its fitted value and training-only positive residual cushion, with a finite cap. Rank or sample insufficiency prevents an allowance estimate.

- resolution: size sample-insufficient; complexity rank-insufficient.
- source-checking: size sample-insufficient; complexity rank-insufficient.
- module-linking: size sample-insufficient; complexity rank-insufficient.
- linked-interface: size sample-insufficient; complexity rank-insufficient.
- final-elaboration: size sample-insufficient; complexity rank-insufficient.
- independent-effect-core: size sample-insufficient; complexity rank-insufficient.

External time excludes builds; each observation has a fresh process.
Boundary RSS is not a phase peak; process peak RSS is cumulative.
Phase wall sums can overlap with containing phases; do not sum them into pipeline time.
Missing or aborted work endpoints are absent, never zero.
Envelopes use each case maximum raw work, preserving fresh-process capacity variation.
GNU time wall and CPU values have centisecond resolution; phase timers have finer resolution.
Both observer modes retain feature-enabled budget override machinery.
Controls use the same executable and finite diagnostic allowance as observation-on.
Models exclude failed, uncontrolled and held-out cases from fitting.
Family growth must be reviewed before adopting any empirical envelope.
