# Resource calibration measurements

Experimental measurements; no production policy change.

| Case | Eligible for fitting | Charged Source | Charged Core | Wall on/off median seconds | Peak RSS on/off KiB |
| --- | --- | ---: | ---: | --- | --- |
| flat-width1 | True | 141 | 232 | 0.0 / 0.0 | 12748 / 12556 |
| flat-width2 | True | 221 | 337 | 0.01 / 0.0 | 12248 / 12620 |
| flat-width4 | True | 381 | 547 | 0.01 / 0.0 | 12648 / 12680 |
| flat-width8 | True | 701 | 967 | 0.01 / 0.0 | 12752 / 12496 |
| flat-width16 | True | 1341 | 1807 | 0.0 / 0.0 | 12584 / 12464 |
| flat-width32 | True | 2621 | 3487 | 0.01 / 0.01 | 13076 / 12888 |
| flat-width64 | True | 5181 | 6847 | 0.01 / 0.01 | 13140 / 13052 |
| flat-width128 | True | 10301 | 13567 | 0.02 / 0.02 | 13916 / 13888 |
| nested_type-depth1 | True | 673 | 748 | 0.0 / 0.0 | 13040 / 12976 |
| nested_type-depth2 | True | 990 | 1101 | 0.01 / 0.0 | 12952 / 13092 |
| nested_type-depth4 | True | 1714 | 1975 | 0.0 / 0.0 | 12864 / 13044 |
| nested_type-depth8 | True | 3522 | 4395 | 0.0 / 0.0 | 12920 / 13244 |
| nested_type-depth12 | True | 5810 | 7711 | 0.01 / 0.0 | 13364 / 13300 |
| nested_type-depth16 | True | 8578 | 11923 | 0.01 / 0.0 | 13280 / 13228 |
| prerequisite-depth1 | True | 2536 | 1266 | 0.0 / 0.0 | 14644 / 14720 |
| prerequisite-depth2 | True | 2957 | 1813 | 0.0 / 0.0 | 14488 / 14708 |
| prerequisite-depth4 | True | 3949 | 3378 | 0.01 / 0.0 | 14912 / 14532 |
| prerequisite-depth8 | True | 6533 | 8392 | 0.0 / 0.0 | 14920 / 14560 |
| prerequisite-depth12 | True | 9917 | 15918 | 0.01 / 0.01 | 14872 / 15168 |
| prerequisite-depth16 | True | 14101 | 25956 | 0.01 / 0.0 | 14724 / 14988 |
| reexport_width-width1-depth2 | True | 698 | 223 | 0.01 / 0.0 | 13788 / 14176 |
| reexport_width-width2-depth2 | True | 1165 | 273 | 0.0 / 0.0 | 13972 / 14460 |
| reexport_width-width4-depth2 | True | 2099 | 373 | 0.01 / 0.0 | 13884 / 14300 |
| reexport_width-width8-depth2 | True | 3967 | 573 | 0.0 / 0.0 | 13980 / 13932 |
| reexport_width-width16-depth2 | True | 7703 | 973 | 0.01 / 0.01 | 14340 / 14128 |
| reexport_width-width32-depth2 | True | 15175 | 1773 | 0.01 / 0.0 | 14624 / 14688 |
| reexport_depth-width1-depth1 | True | 605 | 223 | 0.01 / 0.0 | 13916 / 13944 |
| reexport_depth-width1-depth2 | True | 698 | 223 | 0.0 / 0.0 | 14064 / 14076 |
| reexport_depth-width1-depth4 | True | 887 | 223 | 0.01 / 0.0 | 13936 / 13792 |
| reexport_depth-width1-depth8 | True | 1277 | 223 | 0.01 / 0.0 | 14060 / 14520 |
| reexport_depth-width1-depth12 | True | 1683 | 223 | 0.01 / 0.0 | 14516 / 14336 |
| reexport_depth-width1-depth16 | True | 2105 | 223 | 0.01 / 0.0 | 14216 / 13848 |
| string_payload-payload_bytes16 | True | 69 | 168 | 0.0 / 0.0 | 12496 / 12272 |
| string_payload-payload_bytes1024 | True | 69 | 1176 | 0.0 / 0.0 | 12600 / 12552 |
| string_payload-payload_bytes65536 | True | 69 | 65688 | 0.0 / 0.0 | 12896 / 12812 |
| sqlite-copying | True | 1212707 | 903995 | 0.18 / 0.18 | 34488 / 34380 |
| sqlite-persistence | True | 597882 | 1609087 | 0.23 / 0.23 | 43460 / 43400 |
| sqlite-resume | True | 203215 | 289063 | 0.06 / 0.06 | 22964 / 23076 |
| sqlite-bound_nul | True | 1212707 | 903990 | 0.19 / 0.18 | 34292 / 34300 |
| sqlite-forwarding | True | 216584 | 315193 | 0.06 / 0.06 | 22828 / 22680 |
| resource_width-width1 | True | 111611 | 11811 | 0.03 / 0.03 | 18616 / 18520 |
| resource_width-width2 | True | 117567 | 19066 | 0.02 / 0.02 | 18700 / 18752 |
| resource_width-width4 | True | 129654 | 33984 | 0.04 / 0.03 | 19012 / 19116 |
| resource_width-width8 | True | 154388 | 65788 | 0.03 / 0.03 | 19420 / 19552 |

Each six-owner work vector, phase boundary RSS, median/min/max, observer overhead, failures, models, residuals and held-out coverage is in `summary.json`.

CPU summaries preserve GNU time's target measurements and separately report wrapper-inclusive child user/system/total CPU seconds from native-precision `RUSAGE_CHILDREN` deltas. The latter include GNU time and reaped descendants, exclude Python runner CPU, and measure no individual compiler phase. Raw cumulative before/after CPU readings and deltas are retained in each run. Older evidence without these fields stays missing.

Models use each case's maximum observed admission charge. Held-out cases remain excluded from fitting even when eligible. Charges include precharged capacity and are not machine instruction counts. The simple model uses source nodes; the enriched model uses named immutable graph features. A fitted model is provisional: its envelope is twice the sum of its fitted value and training-only positive residual cushion, with a finite cap. Rank or sample insufficiency prevents an allowance estimate.

- resolution: size provisional; complexity provisional.
- source-checking: size provisional; complexity provisional.
- module-linking: size provisional; complexity provisional.
- linked-interface: size provisional; complexity provisional.
- final-elaboration: size provisional; complexity provisional.
- independent-effect-core: size provisional; complexity provisional.

External time excludes builds; each observation has a fresh process.
GNU time target user/system CPU seconds and process peak RSS remain separate measurements; printed CPU precision may round short runs to zero.
Wrapper-inclusive child CPU uses serial RUSAGE_CHILDREN before/after deltas in seconds, retaining native platform precision without decimal rounding.
These child CPU deltas include GNU time and reaped target descendants, exclude Python runner CPU, and do not isolate individual compiler phases.
Child accounting requires descendants to be waited for; a killed wrapper can omit orphaned descendants after timeout. Failed runs remain evidence, not model inputs.
CPU is scheduled processor time, separate from wall duration, structural work units and allocation counts; threaded child CPU can exceed wall duration.
Boundary RSS is not a phase peak; process peak RSS is cumulative.
Phase wall sums can overlap with containing phases; do not sum them into pipeline time.
Missing or aborted work endpoints are absent, never zero.
Envelopes use each case maximum raw work, preserving fresh-process capacity variation.
GNU time wall and CPU values have centisecond resolution; phase timers have finer resolution.
Both observer modes retain feature-enabled budget override machinery.
Controls use the same executable and finite diagnostic allowance as observation-on.
Models exclude failed, uncontrolled and held-out cases from fitting.
Family growth must be reviewed before adopting any empirical envelope.
