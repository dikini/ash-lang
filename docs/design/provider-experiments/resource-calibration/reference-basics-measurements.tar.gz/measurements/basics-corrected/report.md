# Resource calibration measurements

Experimental measurements; no production policy change.

| Case | Eligible for fitting | Charged Source | Charged Core | Wall on/off median seconds | Peak RSS on/off KiB |
| --- | --- | ---: | ---: | --- | --- |
| basic-higher-order | True | 180 | 326 | 0.0 / 0.0 | 12528 / 12572 |
| basic-global-recursion | True | 238 | 377 | 0.0 / 0.0 | 12788 / 12604 |
| basic-local-recursion | True | 166 | 388 | 0.01 / 0.0 | 12272 / 12368 |
| basic-combined-effects | True | 5159 | 1993 | 0.01 / 0.01 | 14532 / 14564 |
| basic-newtype-facade | True | 275 | 346 | 0.0 / 0.0 | 13016 / 12588 |
| basic-higher-kinded-linked | True | 1390 | 783 | 0.01 / 0.0 | 14192 / 14600 |
| basic-polymorphic-methods | True | 5486 | 4147 | 0.01 / 0.0 | 15212 / 15460 |
| basic-relational-bundle | True | 9244 | 5032 | 0.01 / 0.01 | 15236 / 15212 |

Each six-owner work vector, phase boundary RSS, median/min/max, observer overhead, failures, models, residuals and held-out coverage is in `summary.json`.

CPU summaries preserve GNU time's target measurements and separately report wrapper-inclusive child user/system/total CPU seconds from native-precision `RUSAGE_CHILDREN` deltas. The latter include GNU time and reaped descendants, exclude Python runner CPU, and measure no individual compiler phase. Raw cumulative before/after CPU readings and deltas are retained in each run. Older evidence without these fields stays missing.

Models use each case's maximum observed admission charge. Held-out cases remain excluded from fitting even when eligible. Charges include precharged capacity and are not machine instruction counts. The simple model uses source nodes; the enriched model uses named immutable graph features. A fitted model is provisional: its envelope is twice the sum of its fitted value and training-only positive residual cushion, with a finite cap. Rank or sample insufficiency prevents an allowance estimate.

- resolution: size insufficient-data; complexity insufficient-data.
- source-checking: size insufficient-data; complexity insufficient-data.
- module-linking: size insufficient-data; complexity insufficient-data.
- linked-interface: size insufficient-data; complexity insufficient-data.
- final-elaboration: size insufficient-data; complexity insufficient-data.
- independent-effect-core: size insufficient-data; complexity insufficient-data.

External time excludes builds; each observation has a fresh process.
GNU time target user/system CPU seconds and process peak RSS remain separate measurements; printed CPU precision may round short runs to zero.
Wrapper-inclusive child CPU uses serial RUSAGE_CHILDREN before/after deltas in seconds, retaining native platform precision without decimal rounding.
These child CPU deltas include GNU time and reaped target descendants, exclude Python runner CPU, and do not isolate individual compiler phases.
Child accounting requires descendants to be waited for; a killed wrapper can omit orphaned descendants after timeout. Failed runs remain evidence, not model inputs.
CPU is scheduled processor time, separate from wall duration, structural work units and allocation counts; threaded child CPU can exceed wall duration.
Boundary RSS is not a phase peak; process peak RSS is cumulative.
Phase wall sums can overlap with containing phases; do not sum them into pipeline time.
Missing or aborted work endpoints are absent, never zero.
Envelopes use each case maximum raw work, preserving fresh-process capacity variation.
GNU time wall and CPU values have centisecond resolution; phase timers have finer resolution.
Both observer modes retain feature-enabled budget override machinery.
Controls use the same executable and finite diagnostic allowance as observation-on.
Models exclude failed, uncontrolled and held-out cases from fitting.
Family growth must be reviewed before adopting any empirical envelope.
