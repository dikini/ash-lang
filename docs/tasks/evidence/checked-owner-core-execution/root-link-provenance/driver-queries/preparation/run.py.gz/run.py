import os,sys,json,time,hashlib,subprocess,selectors,signal
from pathlib import Path
P=Path(__file__).resolve().parent
assert hashlib.sha256((P/'proposal.json').read_bytes()).hexdigest()=='afc839ed8fc1a0a6fc067dafa594ac360c81e13556d37214e98cdf68224b2221'
proposal=json.loads((P/'proposal.json').read_text());out=P.parent/'checked-owner-link-provenance-driver-query';out.mkdir(exist_ok=False)
def pin(path):
 p=Path(path).resolve();s=p.stat();return dict(path=str(p),bytes=s.st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),device=s.st_dev,inode=s.st_ino)
def tools():return {p:pin(p) for p in ['/usr/bin/cc','/usr/bin/python3']}
before=tools();(out/'tools-before.json').write_text(json.dumps(before,indent=2)+'\n')
assert before['/usr/bin/cc']['sha256']=='b5f1b773a7c733738352000c92a077dc5852a1a2fc6d836b1e411be1e9ec5f88'
assert before['/usr/bin/python3']['sha256']=='52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41'
results=[]
for n,args in enumerate(proposal['commands'],1):
 child=None;sel=None;data=[bytearray(),bytearray()];error=None;empty=False;code=None
 try:
  child=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=proposal['environment'],start_new_session=True)
  sel=selectors.DefaultSelector();sel.register(child.stdout,selectors.EVENT_READ,0);sel.register(child.stderr,selectors.EVENT_READ,1);end=time.monotonic()+5
  while sel.get_map():
   if time.monotonic()>end:raise RuntimeError('deadline')
   for key,_ in sel.select(.05):
    b=os.read(key.fileobj.fileno(),4096)
    if not b:sel.unregister(key.fileobj);continue
    if len(data[key.data])+len(b)>65536:raise RuntimeError('output bound')
    data[key.data].extend(b)
  code=child.wait(timeout=max(.01,end-time.monotonic()))
 except BaseException as e:error=repr(e)
 finally:
  if child is not None:
   for sig in [signal.SIGTERM,signal.SIGKILL]:
    try:os.killpg(child.pid,sig)
    except ProcessLookupError:pass
    except BaseException as e:error=error or repr(e)
   try:
    if child.poll() is None:child.kill()
   except BaseException as e:error=error or repr(e)
   try:child.wait(timeout=2)
   except BaseException as e:error=error or repr(e)
   try:os.killpg(child.pid,0)
   except ProcessLookupError:empty=True
   except BaseException as e:error=error or repr(e)
   if sel is not None:sel.close()
   for f in [child.stdout,child.stderr]:
    if f is not None:f.close()
  for k,label in enumerate(['stdout','stderr']):(out/f'query-{n}.{label}').write_bytes(data[k])
  record=dict(argv=args,exit_code=code,error=error,child_reaped=child is not None and child.returncode is not None,owned_group_empty=empty,output_absent=not(out/'never-built').exists())
  (out/f'query-{n}.receipt.json').write_text(json.dumps(record,indent=2)+'\n');results.append(record);print(json.dumps(record),flush=True)
 assert code==0 and error is None and empty and record['child_reaped'] and record['output_absent']
after=tools();(out/'tools-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
