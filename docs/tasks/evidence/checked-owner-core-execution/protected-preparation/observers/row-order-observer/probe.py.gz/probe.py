# Read-only GDB observation of ONE fresh canonical request on the pinned binary.
import gdb,json,hashlib,pathlib,os
HERE=pathlib.Path('/home/dikini/Projects/ash-lang/.worktree/generic-cells/target/checked-owner-protected-preparation-row-order-observer')
P=json.loads((HERE/'proposal.json').read_text());DATA=HERE/'host'/'data';DATA.mkdir()
rows=callbacks=read_bytes=stored_bytes=0
active=False;closed=False;found=False;entry_seen=False;invalid=False
original={}
finish_holder=[]
def emit(event,**values):
 global rows,invalid
 rows+=1
 if rows>80:
  invalid=True;raise RuntimeError('row cap')
 print('REQUEST_OBSERVER '+json.dumps(dict(event=event,**values),sort_keys=True),flush=True)
def typename(value):return str(value.type)[:160]
def fields(value):
 try:return [f.name for f in value.type.strip_typedefs().fields() if f.name][:16]
 except Exception:return []
def pointer(value,depth=0):
 if depth>8:raise RuntimeError('pointer depth')
 if value.type.strip_typedefs().code==gdb.TYPE_CODE_PTR:return int(value)
 for name in ['data_ptr','pointer','ptr','buf','inner','vec']:
  if name in fields(value):
   try:return pointer(value[name],depth+1)
   except Exception:pass
 raise RuntimeError('no bounded pointer path')
def byte_view(value,depth=0):
 if depth>8:raise RuntimeError('view depth')
 names=fields(value)
 for length in ['length','len']:
  if length in names:
   n=int(value[length]);address=pointer(value)
   if n<0 or n>8*1024*1024 or (n and address==0):raise RuntimeError('slice bound')
   return address,n
 for name in ['vec','__0','Some']:
  if name in names:
   try:return byte_view(value[name],depth+1)
   except Exception:pass
 raise RuntimeError('no byte slice/Vec view: '+typename(value))
def take(value):
 global read_bytes
 address,n=byte_view(value)
 if read_bytes+n>16*1024*1024:raise RuntimeError('memory byte cap')
 read_bytes+=n
 return bytes(gdb.selected_inferior().read_memory(address,n))
def keep(name,raw):
 global stored_bytes
 if len(raw)>8*1024*1024 or stored_bytes+len(raw)>16*1024*1024:raise RuntimeError('stored byte cap')
 stored_bytes+=len(raw);path=DATA/name
 with path.open('xb') as f:f.write(raw)
 return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def callback():
 global callbacks
 callbacks+=1
 if callbacks>128:raise RuntimeError('callback cap')
def frames():
 result=[];frame=gdb.newest_frame()
 for _ in range(20):
  if frame is None:break
  sal=frame.find_sal();result.append(dict(function=(frame.name() or '')[:240],file=sal.symtab.fullname() if sal.symtab else None,line=sal.line,pc=int(frame.pc())))
  frame=frame.older()
 return result
def decode_frame():
 frame=gdb.newest_frame()
 for _ in range(20):
  if frame is None:break
  if frame.name()=='ash::build::checked_request::decode_with_work':return frame
  frame=frame.older()
 return None
def capture_request(frame):
 global original
 raw=take(frame.read_var('bytes'));pin=keep('fresh-request.json',raw)
 # This parses only bounded bytes actually read from this fresh inferior. It
 # cannot recover the failed 80556 request or establish protected applicability.
 record=json.loads(raw)
 parts=record.get('parts',[])
 if len(parts)>14:raise RuntimeError('part count')
 total=sum(len(p.get('bytes',[])) for p in parts)
 if total>8*1024*1024:raise RuntimeError('part bytes')
 pins=[]
 for part in parts:
  i=part['id'];values=part['bytes']
  if not isinstance(i,int) or i<1 or i>14 or i in original:raise RuntimeError('part identity')
  if not all(type(v) is int and 0<=v<=255 for v in values):raise RuntimeError('part bytes type')
  data=bytes(values);original[i]=data;pins.append(dict(id=i,**keep('original-part-'+str(i)+'.bin',data)))
 emit('fresh_request',request=pin,parts=pins)
def capture_comparisons(frame):
 for name,part in [('reimage',2),('refacts',3),('regenerated',4),('rerust',5)]:
  try:
   raw=take(frame.read_var('emission')['rust_source'] if name=='rerust' else frame.read_var(name));record=keep('reconstructed-'+name+'.bin',raw);before=original.get(part)
   first=next((i for i,(a,b) in enumerate(zip(before or b'',raw)) if a!=b),None)
   if first is None and before is not None and len(before)!=len(raw):first=min(len(before),len(raw))
   record.update(local=name,original_part=part,first_difference=first,equal=before==raw,original_bytes=len(before) if before is not None else None)
   if first is not None:record['window_original']=list((before or b'')[max(0,first-8):first+16]);record['window_reconstructed']=list(raw[max(0,first-8):first+16])
   emit('comparison',**record)
  except Exception as e:emit('local_unavailable',local=name,error=str(e)[:180])
def resolution(bp,expected=None):
 locations=[]
 for loc in bp.locations:
  address=int(loc.address or 0);sal=gdb.find_pc_line(address) if address else None
  locations.append(dict(address=address,enabled=bool(loc.enabled),line=sal.line if sal else None))
 if len(locations)>32:raise RuntimeError('location cap')
 return dict(number=bp.number,valid=bp.is_valid(),pending=bool(bp.pending),enabled=bp.enabled,expected_line=expected,locations=locations)
class Finish(gdb.FinishBreakpoint):
 def __init__(self,frame):super().__init__(frame,internal=True)
 def stop(self):
  global active,closed
  callback();active=False;closed=True
  for bp in failures:bp.enabled=False
  emit('first_decode_returned',return_value_available=self.return_value is not None)
  return False
 def out_of_scope(self):
  global invalid,active
  active=False;invalid=True;emit('finish_out_of_scope')
class Failure(gdb.Breakpoint):
 def __init__(self,line,kind):
  self.line=line;self.kind=kind
  super().__init__(P['source']+':'+str(line),internal=True)
  self.enabled=False
 def stop(self):
  global found
  callback()
  if not active or found:return False
  frame=gdb.newest_frame();name=frame.name() or '';sal=frame.find_sal()
  # A map_err source line in the outer function is NOT evidence of error. Only
  # the actual generated error closure frame is eligible for that site.
  if self.kind in ['closure','reencode-error-arm'] and 'closure' not in name:return False
  if sal.line!=self.line:return False
  found=True
  emit('first_association_site',kind=self.kind,line=self.line,function=name[:240],stack=frames(),qualification='fresh observed executed source site/propagation; not recovery of80556 bytes')
  parent=decode_frame()
  if parent:capture_comparisons(parent)
  for bp in failures:bp.enabled=False
  return False
class Entry(gdb.Breakpoint):
 def __init__(self):super().__init__('ash::build::checked_request::decode_with_work',internal=True)
 def stop(self):
  global entry_seen,active
  callback()
  if entry_seen:return False
  entry_seen=True;self.enabled=False;active=True
  try:capture_request(gdb.newest_frame())
  except Exception as e:emit('request_unavailable',error=str(e)[:180])
  readback=[]
  for bp in failures:
   r=resolution(bp,bp.line)
   exact=r['valid'] and not r['pending'] and r['locations'] and all(x['address'] and x['line']==bp.line for x in r['locations'])
   if exact:
    bp.enabled=True;r=resolution(bp,bp.line)
    if not r['enabled'] or any(not x['enabled'] for x in r['locations']):raise RuntimeError('enabled location mismatch')
   readback.append(r)
  emit('root_active_resolution',breakpoints=readback)
  finish_holder.append(Finish(gdb.newest_frame()));return False
failures=[]
for row in P['sites']:
 failures.append(Failure(row['line'],row['kind']))
if len(failures)>48:raise RuntimeError('breakpoint cap')
entry=Entry();r=resolution(entry)
if not r['valid'] or r['pending'] or not r['locations'] or not r['enabled'] or any(not x['address'] or not x['enabled'] for x in r['locations']):raise RuntimeError('entry unresolved')
emit('load_resolution',entry=r,disabled_sites=[resolution(bp,bp.line) for bp in failures])
def exited(event):
 emit('inferior_exit',code=event.exit_code if hasattr(event,'exit_code') else None,entry_seen=entry_seen,first_decode_closed=closed,association_site_found=found,read_bytes=read_bytes,stored_bytes=stored_bytes,invalid=invalid)
gdb.events.exited.connect(exited)
