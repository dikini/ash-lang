from pathlib import Path
import hashlib,json,subprocess,os,time,signal,sys
OUT=Path(__file__).parent
P=json.loads((OUT/'proposal.json').read_text());ROOT=Path(P['cwd'])
assert not sys.argv[1:],'One exact assigned observation only'
DEST=OUT/'host'
assert not DEST.exists(),'No retry or overwrite'
def identity(s):return {k:getattr(s,k) for k in ('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns')}
def digest(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  initial=identity(os.fstat(f.fileno()))
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
  final=identity(os.fstat(f.fileno()))
 assert initial==final==identity(p.stat()),'Changed file identity during streaming read'
 return dict(path=str(p),sha256=h.hexdigest(),size=final['st_size'],identity=final)
def inputs():
 names=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=ROOT).decode().split('\0')
 full={n:digest(ROOT/n)['sha256'] for n in sorted(set(names)) if n and (ROOT/n).is_file()}
 runtime={n:full[n] for n in P['inputs']['runtime']}
 return dict(full=full,runtime=runtime)
def tools():
 result={}
 for name,record in P['tools'].items():
  resolved=str(Path(name).resolve());actual=digest(resolved)
  result[name]=dict(resolved=resolved,sha256=actual['sha256'],size=actual['size'],identity=actual['identity'])
 return result
def group_exists(pgid):
 try:os.killpg(pgid,0);return True
 except ProcessLookupError:return False
before=inputs();assert before==P['inputs']
assert digest(P['artifact']['path'])==P['artifact']
assert digest(P['script']['path'])==P['script']
assert tools()==P['tools']
assert {k:os.environ.get(k) for k in P['environment']}==P['environment']
env=os.environ.copy()
DEST.mkdir()
freeze=dict(inputs=before,artifact=digest(P['artifact']['path']),script=digest(P['script']['path']),tools=tools(),proposal=digest(OUT/'proposal.json'),runner=digest(__file__),environment={k:env.get(k) for k in P['environment']},argv=P['argv'],cwd=str(ROOT))
(DEST/'before.json').write_text(json.dumps(freeze,indent=2)+'\n')
started=time.monotonic();abort=None
with (DEST/'raw.log').open('wb') as log:
 proc=subprocess.Popen(P['argv'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 pgid=proc.pid
 try:
  pgid=proc.pid
  assert os.getpgid(proc.pid)==pgid
  (DEST/'process.json').write_text(json.dumps(dict(pid=proc.pid,pgid=pgid,runner_pid=os.getpid(),started_unix=time.time(),argv=P['argv']),indent=2)+'\n')
  print('LIVE '+str(proc.pid),flush=True)
  while proc.poll() is None:
   if (DEST/'raw.log').stat().st_size>P['bounds']['raw_bytes']:abort='raw cap'
   if time.monotonic()-started>P['bounds']['outer_seconds']:abort='outer deadline'
   if abort:
    os.killpg(pgid,signal.SIGTERM)
    try:proc.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(pgid,signal.SIGKILL);proc.wait()
    break
   try:proc.wait(timeout=0.25)
   except subprocess.TimeoutExpired:pass
 except BaseException as e:
  abort='runner error: '+type(e).__name__+': '+str(e)[:160]
 finally:
  if proc.poll() is None or group_exists(pgid):
   try:os.killpg(pgid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:
    try:os.killpg(pgid,signal.SIGKILL)
    except ProcessLookupError:pass
    proc.kill();proc.wait()
  for _ in range(20):
   if not group_exists(pgid):break
   time.sleep(0.1)
  if group_exists(pgid):
   try:os.killpg(pgid,signal.SIGKILL)
   except ProcessLookupError:pass
   for _ in range(20):
    if not group_exists(pgid):break
    time.sleep(0.1)
  proc.wait()
  cleanup=dict(child_reaped=proc.poll() is not None,owned_group_exists=group_exists(pgid),observed_unix=time.time())

after=dict(inputs=inputs(),artifact=digest(P['artifact']['path']),script=digest(P['script']['path']),tools=tools(),cleanup=cleanup)
(DEST/'after.json').write_text(json.dumps(after,indent=2)+'\n')
raw=(DEST/'raw.log').read_text(errors='replace')
rows=[json.loads(line[len('REQUEST_OBSERVER '):]) for line in raw.splitlines() if line.startswith('REQUEST_OBSERVER ')]
exit_rows=[r for r in rows if r.get('event')=='inferior_exit']
equal=before==after['inputs'] and after['artifact']==P['artifact'] and after['script']==P['script'] and after['tools']==P['tools']
errors=['Traceback (most recent call last)', 'REQUEST_OBSERVER_ERROR', 'Error while executing Python code', 'Python Exception']
valid=abort is None and proc.returncode==0 and equal and cleanup['child_reaped'] and not cleanup['owned_group_exists'] and not any(e in raw for e in errors) and len(rows)<=P['bounds']['rows'] and len(exit_rows)==1 and exit_rows[0].get('code') in [0,101] and exit_rows[0].get('entry_seen') and exit_rows[0].get('first_decode_closed') and not exit_rows[0].get('invalid')
request_captured=any(r.get('event')=='fresh_request' for r in rows)
resolution_rows=[r for r in rows if r.get('event')=='root_active_resolution']
site_rows=[r for r in rows if r.get('event')=='first_association_site']
resolutions=resolution_rows[0]['breakpoints'] if len(resolution_rows)==1 else []
disabled_sites=[r for r in resolutions if not r['enabled'] or r['pending'] or not r['locations'] or any(not x['address'] or x['line']!=r['expected_line'] for x in r['locations'])]
comparisons=[r for r in rows if r.get('event')=='comparison']
site=site_rows[0]['line'] if len(site_rows)==1 else None
needed={355:{'regenerated'},383:{'reimage','refacts'}}.get(site,set())
comparison_data_complete=bool(needed and needed.issubset({r['local'] for r in comparisons}))
mismatch_observed=any(r['local'] in needed and r.get('equal') is False for r in comparisons)
sufficient=bool(valid and exit_rows[0].get('association_site_found') and request_captured and comparison_data_complete and mismatch_observed)
receipt=dict(debugger_exit=proc.returncode,seconds=round(time.monotonic()-started,3),abort=abort,all_inputs_tools_equal=equal,cleanup=cleanup,observer_valid=bool(valid),association_site_observed=bool(valid and site_rows),fresh_request_captured=request_captured,disabled_or_unresolved_sites=disabled_sites,comparison_data_complete=comparison_data_complete,mismatch_observed=mismatch_observed,comparison_cause_evidence=sufficient,evidence_level=('comparison-data' if sufficient else 'stage-only' if valid and site_rows else 'insufficient'),comparisons_available=[r['local'] for r in rows if r.get('event')=='comparison'],rows=len(rows),raw=digest(DEST/'raw.log'),inferior_exit=exit_rows,scope=P['scope'],qualification='Fresh regenerated request only; prelaunch input hashing is outside the run deadline. Log cap is sampled, not a strict disk quota. Missing locals or failure sites cannot establish the historical cause.')
(DEST/'rows.json').write_text(json.dumps(rows,indent=2)+'\n');(DEST/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
sys.exit(0 if valid else 1)
