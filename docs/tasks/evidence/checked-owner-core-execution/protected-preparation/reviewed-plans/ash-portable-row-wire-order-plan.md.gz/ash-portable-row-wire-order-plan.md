# Wire-only portable ordering of unordered row members

The fresh77549 parse identifies only37 `type_children` differences in16 closed Row known sets. The facts/policy and every other image record are byte-exact. `EffectRow` is an unordered canonical set; native ModuleId namespace ordering changes when admitted ordinary sources restore as DirectCoreSource. Ordered instance arguments did not change.

## Private order key; existing serializer remains sole emitter

Add an image-private order-key helper, operating on borrowed existing Type/KindedArgument/EffectInstance/EffectRow/Kind data. It creates no Type, ModuleId, registry, authority or image. Actual payloads still pass through the existing `encode_structural`, WireWriter, full facts comparison, original reconstruction and Core validation. This key is not a second image format/admission path or a hash commitment.

A key is an unambiguous flat sequence of fixed-size tagged scalar tokens: exact portable category/module/local identities, variant tags, lengths and child keys. No hash or image/table slot is an ordering key. Portable identities use the current Encoder.modules map (already authenticated provenance/source order) and the same nominal/resource/effect/type-variable conversion helpers. Unknown module and unsupported inference/role forms refuse. Resolved/generated and rigid/allowed-pending tags remain distinct.

Use one explicit postorder task/result stack, with borrowed inputs and Finish tasks. Every Type constructor, ordered Type/Row actual, Kind arrow, ordered forall parameter identity+full Kind and body is included. The task stack is iterative. Match the codec's current depth rules and CORE_PAYLOAD_DEPTH_LIMIT; no recursive comparison or owned Type/Row clones.

For functions use the current `Type::function_view` semantic components: common function tag, ordered domain/value, and normalized latent effects (pure and explicit closed-empty have the same ordering key under retained #114). Do not change the actual TypeTag emitted by the serializer or resolved equality. Two equal keys in one row partition refuse as duplicate input; known and lacks partitions are distinct and may overlap as the existing algebra requires.

For nested Row keys, finish all complete member keys first. Sort the known keys and lacks keys separately using their full lexicographic token sequences, preserve each partition's count and exact tail variable tag/identity, then assemble that Row key. Instance keys include the complete effect identity and full ordered argument keys. No Type argument vector, Row argument vector, quantifier vector, tuple/member vector or parameter vector is sorted.

## Integration before child encoding

When the existing encoder visits StructuralInput::Row, obtain borrowed known/lacks member lists with these complete portable keys, sort each partition, then schedule existing Visit(Instance) tasks in that order. The helper must not call encode_type/encode_kind/encode_quantifiers or otherwise mutate image tables while discovering keys. Thus actual child interning/first-encounter order follows the canonical portable set order, including same-effect members with different complete actuals. No global row comparator/algebra change and no manufactured admitted ModuleId.

## Bounded payment

Charge before every task/result/token storage allocation and portable identity lookup. Checked lengths precede every reserve/copy. Finish prepays the complete child-key concatenation before copying tokens. Lexicographic comparison charges each token visited before reading it; lengths/tags are paid too. Use paid finite merge passes over indices/references for set sorting, with scratch/output storage charged before allocation and each index move charged. Duplicate checks pay the complete key comparison. Any work/storage/depth exhaustion returns existing Resource; limits/tariffs/allowances are unchanged and no decoder meter is reset. Flattening key copies is explicitly charged, never expansion credit or an unmetered recursive walk.

## Controls and gates

Canonical-first: cross-module known/lacks rows with relocated process modules; same-effect members differing in nested complete Type/Row arguments; forall identity/arrow Kind differences; ordered actual permutation remains unequal; pure/closed-empty function key equality; generated/resolved tail distinction; full resulting wire restore/reencode equality; exact/one-short/spent/fresh work. Unknown module/inference and duplicate keys refuse at their intended boundary. Keep the genuine request canonical and existing hostiles exact, plus prior four lossless carrier controls and trusted5/both-package Clippy. Old5321/77549 results remain separately scoped; current full producer/request/ELF data+19 affected gates remain mandatory.
