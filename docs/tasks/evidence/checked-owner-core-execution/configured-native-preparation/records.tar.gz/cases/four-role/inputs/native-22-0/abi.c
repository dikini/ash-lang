#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include "owner.h"
#if !defined(__x86_64__) || !defined(__linux__) || !defined(__GLIBC__)
#error unsupported_target
#endif
_Static_assert(sizeof(void*)==8 && sizeof(size_t)==8 && sizeof(int)==4,"target layout");
_Static_assert(__builtin_types_compatible_p(__typeof__(&ash_checked_owner_view), void * (*)(void *, size_t)), "bridge 0 prototype");
_Static_assert(__builtin_types_compatible_p(__typeof__(&ash_checked_owner_release), void (*)(void *)), "bridge 1 prototype");
_Static_assert(__builtin_types_compatible_p(__typeof__(&ash_checked_owner_length), size_t (*)(void *, size_t)), "bridge 2 prototype");
_Static_assert(__builtin_types_compatible_p(__typeof__(&ash_checked_owner_acquire), void * (*)(size_t, size_t)), "bridge 3 prototype");
