//! Fixed owner transport for the generated initialized-eight-byte whole image.
//! This crate has no Ash dependency and grants no CP24 execution permission.
#![deny(unsafe_op_in_unsafe_fn)]
#![deny(missing_docs)]
#[cfg(not(all(target_arch = "x86_64", target_os = "linux", target_env = "gnu", target_pointer_width = "64")))]
compile_error!("unsupported checked owner leaf target");
use std::{ffi::c_void, ptr::NonNull, sync::atomic::{AtomicU64, Ordering}};

unsafe extern "C" {
    #[link_name = "ash_checked_owner_acquire"]
    fn native_acquire(capacity: usize, initialized: usize) -> *mut c_void;
    #[link_name = "ash_checked_owner_view"]
    fn native_query(owner: *mut c_void, key: usize) -> *mut c_void;
    #[link_name = "ash_checked_owner_length"]
    fn native_length(owner: *mut c_void, key: usize) -> usize;
    #[link_name = "ash_checked_owner_release"]
    fn native_release(owner: *mut c_void);
}
static NEXT_OWNER: AtomicU64 = AtomicU64::new(1);

/// A pre-entry refusal or a post-query range mismatch. No variant retries C.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Refusal {
    /// The selected fixed allocation profile was not requested.
    Profile,
    /// The process-local transport serial cannot advance without reuse.
    Identity,
    /// Native query output is outside the live initialized owner interval.
    Range,
    /// A descriptor came from another acquisition or a stale owner.
    Owner,
}
/// Unique opaque native backing. There is intentionally no foreign Drop.
pub struct Owner {
    address: NonNull<c_void>,
    initialized: usize,
    serial: u64,
}
/// Exactly one returning acquisition, distinct from pre-entry refusal.
pub enum AcquireReply {
    /// No C entry occurred.
    NotEntered(Refusal),
    /// C returned a nullable owner. Non-null backing is immediately representable.
    Returned(Option<Owner>),
}
/// A checked relative native view, tied to one acquisition. No raw address escapes.
pub struct ViewDescriptor {
    serial: u64,
    offset: usize,
    available: usize,
}
/// A lexical borrow from the actual live owner, preventing release during copy.
pub struct View<'a> {
    owner: &'a Owner,
    offset: usize,
    available: usize,
}
impl std::fmt::Debug for ViewDescriptor {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.write_str("ViewDescriptor { .. }")
    }
}
/// Only a returning release of a consumed Owner can construct this fact.
pub struct ReleaseReturned {
    _serial: u64,
}

/// Fixed transport preparation, not source permission or protected admission.
/// Dropping it consumes only a fresh serial and never calls native code.
pub struct PreparedAcquire {
    capacity: usize,
    initialized: usize,
    serial: u64,
}
/// Reserve the fixed profile and a nonreused serial before native entry.
pub fn prepare_acquire(capacity: usize, initialized: usize) -> Result<PreparedAcquire, Refusal> {
    if capacity != 8 || initialized != 8 { return Err(Refusal::Profile); }
    let serial = NEXT_OWNER.fetch_update(Ordering::Relaxed, Ordering::Relaxed, |n| n.checked_add(1))
        .map_err(|_| Refusal::Identity)?;
    Ok(PreparedAcquire { capacity, initialized, serial })
}
/// Invoke an already prepared acquisition. No pre-entry refusal remains.
/// The root holds its vacant destination borrow and arms the returned Owner first.
pub fn invoke_acquire(prepared: PreparedAcquire) -> Option<Owner> {
    let PreparedAcquire { capacity, initialized, serial } = prepared;
    // SAFETY: the fixed ABI is established by the native plan/header checks;
    // actual allocation/initialization validity remains an AD16 image premise.
    let address = unsafe { native_acquire(capacity, initialized) };
    match NonNull::new(address) {
        Some(address) => Some(Owner { address, initialized, serial }),
        None => None,
    }
}
/// Compatibility transport entry; checked evaluator entry uses prepare/invoke
/// so its pending native fact is committed only after all pre-entry refusals.
pub fn acquire(capacity: usize, initialized: usize) -> AcquireReply {
    match prepare_acquire(capacity, initialized) {
        Ok(prepared) => AcquireReply::Returned(invoke_acquire(prepared)),
        Err(reason) => AcquireReply::NotEntered(reason),
    }
}
/// Observe a native view and validate integer address bounds before arithmetic.
pub fn query(owner: &Owner, key: usize) -> Result<Option<ViewDescriptor>, Refusal> {
    let begin = owner.address.as_ptr() as usize;
    let end = begin.checked_add(owner.initialized).ok_or(Refusal::Range)?;
    // SAFETY: Owner is live, unique backing supplied by the fixed acquisition;
    // the admitted ABI and non-consuming query contract remain AD16 premises.
    let address = unsafe { native_query(owner.address.as_ptr(), key) };
    if address.is_null() { return Ok(None); }
    let address = address as usize;
    if address < begin || address > end { return Err(Refusal::Range); }
    let offset = address.checked_sub(begin).ok_or(Refusal::Range)?;
    let available = owner.initialized.checked_sub(offset).ok_or(Refusal::Range)?;
    Ok(Some(ViewDescriptor {serial: owner.serial, offset, available}))
}
/// Observe the exact native scalar; the root separately authenticates its extent.
pub fn length(owner: &Owner, key: usize) -> usize {
    // SAFETY: the fixed length ABI and live non-consuming owner contract are
    // established by the exact generated plan and finite native premises.
    unsafe { native_length(owner.address.as_ptr(), key) }
}
/// Borrow only a descriptor from this same live acquisition.
pub fn borrow_view<'a>(owner: &'a Owner, descriptor: &ViewDescriptor) -> Result<View<'a>, Refusal> {
    if owner.serial != descriptor.serial { return Err(Refusal::Owner); }
    if descriptor.offset.checked_add(descriptor.available).is_none_or(|end| end > owner.initialized) {
        return Err(Refusal::Range);
    }
    Ok(View {owner, offset: descriptor.offset, available: descriptor.available})
}
/// Copy into an existing Rust destination after checked initialized-range bounds.
pub fn copy(view: &View<'_>, offset: usize, destination: &mut [u8]) -> Result<(), Refusal> {
    let end = offset.checked_add(destination.len()).ok_or(Refusal::Range)?;
    if end > view.available { return Err(Refusal::Range); }
    let start = view.offset.checked_add(offset).ok_or(Refusal::Range)?;
    let end = start.checked_add(destination.len()).ok_or(Refusal::Range)?;
    if end > view.owner.initialized { return Err(Refusal::Range); }
    // SAFETY: integer checks precede pointer arithmetic. The pointer is derived
    // from the live Owner, not the query pointer; the admitted initialized-eight
    // contract bounds all arithmetic. Opaque transport exposes no alias into a
    // Rust destination, and its exclusive borrow excludes destination aliases.
    unsafe {
        std::ptr::copy_nonoverlapping(
            view.owner.address.as_ptr().cast::<u8>().add(start),
            destination.as_mut_ptr(), destination.len(),
        );
    }
    Ok(())
}
/// Release exactly the moved owner; neither replay nor automatic foreign Drop exists.
pub fn release(owner: Owner) -> ReleaseReturned {
    let Owner {address, serial, ..} = owner;
    // SAFETY: the consumed unique handle supplies the exact fixed release ABI.
    // Actual native consumption is the separately approved finite callee premise.
    unsafe { native_release(address.as_ptr()); }
    ReleaseReturned {_serial: serial}
}

/// Fixed typed scalar DATA; no owner, address or invocation authority.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RawScalar {
    /// Signed eight-bit observation.
    I8(i8),
    /// Unsigned eight-bit observation.
    U8(u8),
    /// Signed32 observation.
    I32(i32),
    /// Unsigned32 observation.
    U32(u32),
    /// Signed64 observation.
    I64(i64),
    /// Unsigned64 observation.
    U64(u64),
    /// Target-resolved size_t observation.
    USize(usize),
}
/// One actual teardown return. Constructor remains private to this leaf.
pub struct DisposalReturned {
    disposition: Option<bool>,
    status: Option<RawScalar>,
    readable: bool,
}
impl DisposalReturned {
    /// None establishes no admitted O4; it is never known retention.
    pub fn disposition(&self) -> Option<bool> { self.disposition }
    /// Only an admitted outcome supplies a new independent status.
    pub fn status(&self) -> Option<RawScalar> { self.status }
    /// Source payload readability is independent of the raw observation.
    pub fn readable(&self) -> bool { self.readable }
}

/// Unsupported output profile preparation, never a raw callback fallback.
pub struct PreparedOutputAcquire<'slot, 'input> {
    _destination: &'slot mut Option<Owner>,
    _input: &'input [u8],
}
/// Fixed output acquisition observations after destination arming.
pub struct OutputAcquireReturned { nonnull: bool, status: RawScalar }
impl OutputAcquireReturned {
    /// Nullness is not a source success classification.
    pub fn nonnull(&self) -> bool { self.nonnull }
    /// Actual typed scalar DATA.
    pub fn status(&self) -> RawScalar { self.status }
}
/// This profile has no output acquisition operation.
pub fn prepare_output_acquire<'slot, 'input>(destination: &'slot mut Option<Owner>, input: &'input [u8])
    -> Result<PreparedOutputAcquire<'slot, 'input>, Refusal> {
    let _ = (destination, input); Err(Refusal::Profile)
}
impl PreparedOutputAcquire<'_, '_> {
    /// An unsupported profile cannot construct this preparation.
    pub fn invoke(self) -> OutputAcquireReturned { unreachable!("unsupported output profile") }
}
/// Exact occupied destination loan, retained through C and disposition.
pub struct PreparedTeardown<'slot> { destination: &'slot mut Option<Owner> }
/// This byte profile admits only its consuming void release.
pub fn prepare_teardown(destination: &mut Option<Owner>) -> Result<PreparedTeardown<'_>, Refusal> {
    if destination.is_none() { return Err(Refusal::Owner); }
    Ok(PreparedTeardown { destination })
}
impl PreparedTeardown<'_> {
    /// Clears backing only after the actual consuming void call returns.
    pub fn invoke(self) -> DisposalReturned {
        let owner = self.destination.take().expect("exclusive prepared owner");
        let _returned = release(owner);
        DisposalReturned { disposition: Some(true), status: None, readable: true }
    }
}

/// Whether this exact emitted profile has byte view operations.
pub fn supports_byte_views() -> bool { true }
