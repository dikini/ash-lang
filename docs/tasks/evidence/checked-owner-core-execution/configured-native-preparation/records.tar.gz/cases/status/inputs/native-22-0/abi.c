#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include "owner.h"
#if !defined(__x86_64__) || !defined(__linux__) || !defined(__GLIBC__)
#error unsupported_target
#endif
_Static_assert(sizeof(void*)==8 && sizeof(size_t)==8 && sizeof(int)==4,"target layout");
_Static_assert(__builtin_types_compatible_p(__typeof__(&sqlite3_open_v2), int32_t (*)(const unsigned char *, void **, int32_t, const unsigned char *)), "bridge 0 prototype");
_Static_assert(__builtin_types_compatible_p(__typeof__(&sqlite3_close), int32_t (*)(void *)), "bridge 1 prototype");
