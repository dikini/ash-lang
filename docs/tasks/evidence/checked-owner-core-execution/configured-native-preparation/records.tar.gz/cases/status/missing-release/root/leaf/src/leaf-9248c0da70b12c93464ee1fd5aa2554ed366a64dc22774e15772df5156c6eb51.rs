//! Generated independent opaque output/status transport. No Ash authority.
#![deny(unsafe_op_in_unsafe_fn)]
#![deny(missing_docs)]
#[cfg(not(all(target_arch = "x86_64", target_os = "linux", target_env = "gnu", target_pointer_width = "64")))]
compile_error!("unsupported checked owner leaf target");
use std::{ffi::c_void, ptr::NonNull, sync::atomic::{AtomicU64, Ordering}};
unsafe extern "C" {
    #[link_name = "sqlite3_open_v2"]
    fn native_acquire(input: *const u8, output: *mut *mut c_void, flags: i32, context: *const u8) -> i32;
    #[link_name = "sqlite3_close"]
    fn native_release(owner: *mut c_void) -> i32;
}
static NEXT_OWNER: AtomicU64 = AtomicU64::new(1);
/// Pre-entry refusal; no variant retries a native call.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Refusal {
    /// Unsupported role or input profile.
    Profile,
    /// Nonreused serial exhausted.
    Identity,
    /// Unsupported view range.
    Range,
    /// Wrong, missing or unresolved owner.
    Owner,
}
/// Opaque unique backing; there is no foreign Drop.
pub struct Owner { address: NonNull<c_void>, serial: u64, unresolved: bool }
/// No byte view is constructible for the opaque profile.
pub struct ViewDescriptor { _private: () }
/// No byte borrow is constructible for the opaque profile.
pub struct View<'a> { _owner: &'a Owner }
impl std::fmt::Debug for ViewDescriptor {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result { f.write_str("ViewDescriptor { .. }") }
}

/// Fixed typed scalar DATA; no owner, address or invocation authority.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RawScalar {
    /// Signed eight-bit observation.
    I8(i8),
    /// Unsigned eight-bit observation.
    U8(u8),
    /// Signed32 observation.
    I32(i32),
    /// Unsigned32 observation.
    U32(u32),
    /// Signed64 observation.
    I64(i64),
    /// Unsigned64 observation.
    U64(u64),
    /// Target-resolved size_t observation.
    USize(usize),
}
/// One actual teardown return. Constructor remains private to this leaf.
pub struct DisposalReturned {
    disposition: Option<bool>,
    status: Option<RawScalar>,
    readable: bool,
}
impl DisposalReturned {
    /// None establishes no admitted O4; it is never known retention.
    pub fn disposition(&self) -> Option<bool> { self.disposition }
    /// Only an admitted outcome supplies a new independent status.
    pub fn status(&self) -> Option<RawScalar> { self.status }
    /// Source payload readability is independent of the raw observation.
    pub fn readable(&self) -> bool { self.readable }
}

/// Actual vacant destination and stable owned NUL input, borrowed only at invoke.
pub struct PreparedOutputAcquire<'slot, 'input> {
    destination: &'slot mut Option<Owner>, input: &'input [u8], serial: u64,
}
/// Fixed acquisition DATA, constructed only after first destination arming.
pub struct OutputAcquireReturned { nonnull: bool, status: RawScalar }
impl OutputAcquireReturned {
    /// Nullness alone never selects a source success branch.
    pub fn nonnull(&self) -> bool { self.nonnull }
    /// Actual typed return, independent of source output construction.
    pub fn status(&self) -> RawScalar { self.status }
}
/// Validate vacancy/NUL and reserve identity before the ledger enters C.
pub fn prepare_output_acquire<'slot, 'input>(destination: &'slot mut Option<Owner>, input: &'input [u8])
    -> Result<PreparedOutputAcquire<'slot, 'input>, Refusal> {
    if destination.is_some() { return Err(Refusal::Owner); }
    let Some((&0, prefix)) = input.split_last() else { return Err(Refusal::Profile); };
    if prefix.contains(&0) { return Err(Refusal::Profile); }
    let serial = NEXT_OWNER.fetch_update(Ordering::Relaxed, Ordering::Relaxed, |n| n.checked_add(1))
        .map_err(|_|Refusal::Identity)?;
    Ok(PreparedOutputAcquire { destination, input, serial })
}
impl PreparedOutputAcquire<'_, '_> {
    /// No conversion, allocation, refusal or reborrow follows C before arming.
    pub fn invoke(self) -> OutputAcquireReturned {
        let mut output = std::ptr::null_mut();
        // SAFETY: exact typed original ABI, prepaid NUL input and initialized
        // output slot; validity/retention are the independently approved premise.
        let status = unsafe { native_acquire(self.input.as_ptr(), &mut output, 6_i32, std::ptr::null()) };
        *self.destination = NonNull::new(output).map(|address| Owner { address, serial: self.serial, unresolved: false }); // FIRST backing action.
        OutputAcquireReturned { nonnull: self.destination.is_some(), status: RawScalar::I32(status) }
    }
}
/// Loan of the same live occupied destination. No eager consuming take.
pub struct PreparedTeardown<'slot> { destination: &'slot mut Option<Owner> }
/// Validate liveness before ledger entry; dropping preparation performs no C.
pub fn prepare_teardown(destination: &mut Option<Owner>) -> Result<PreparedTeardown<'_>, Refusal> {
    if destination.as_ref().is_none_or(|owner| owner.unresolved) { return Err(Refusal::Owner); }
    Ok(PreparedTeardown { destination })
}
impl PreparedTeardown<'_> {
    /// Return disposition under the original finite typed outcome matcher.
    pub fn invoke(self) -> DisposalReturned {
        let owner = self.destination.as_ref().expect("exclusive prepared owner");
        let _serial = owner.serial;
        // SAFETY: same actual live owner and exact original typed teardown ABI;
        // the status-to-disposition contract is an independently approved premise.
        let status = unsafe { native_release(owner.address.as_ptr()) };
        let classification: Option<(bool, bool)> = if status == (0 as i32) { Some((true, true)) } else { Some((false, true)) };
        match classification {
            Some((consumed, readable)) => {
                if consumed { *self.destination = None; }
                DisposalReturned { disposition: Some(consumed), status: Some(RawScalar::I32(status)), readable }
            }
            None => {
                self.destination.as_mut().expect("held owner").unresolved = true;
                DisposalReturned { disposition: None, status: None, readable: false }
            }
        }
    }
}
/// Unsupported direct acquisition, retained for the common private interface.
pub struct PreparedAcquire { _private: () }
/// Unsupported direct profile result, not a nullable success fallback.
pub enum AcquireReply {
    /// No native entry.
    NotEntered(Refusal),
    /// A returning direct acquisition, unavailable in this profile.
    Returned(Option<Owner>),
}
/// This profile cannot construct a direct acquisition preparation.
pub fn prepare_acquire(_: usize, _: usize) -> Result<PreparedAcquire, Refusal> { Err(Refusal::Profile) }
/// An unsupported preparation cannot reach invocation.
pub fn invoke_acquire(_: PreparedAcquire) -> Option<Owner> { unreachable!("unsupported direct profile") }
/// Unsupported direct acquisition refuses before C.
pub fn acquire(_: usize, _: usize) -> AcquireReply { AcquireReply::NotEntered(Refusal::Profile) }
/// Opaque profile refuses byte query before C.
pub fn query(_: &Owner, _: usize) -> Result<Option<ViewDescriptor>, Refusal> { Err(Refusal::Profile) }
/// Opaque profile never returns a byte length.
pub fn length(_: &Owner, _: usize) -> usize { unreachable!("opaque profile has no length call") }
/// Opaque profile has no admitted byte descriptor.
pub fn borrow_view<'a>(_: &'a Owner, _: &ViewDescriptor) -> Result<View<'a>, Refusal> { Err(Refusal::Profile) }
/// Opaque profile refuses copies before any native or memory access.
pub fn copy(_: &View<'_>, _: usize, _: &mut [u8]) -> Result<(), Refusal> { Err(Refusal::Profile) }

/// Whether this exact emitted profile has byte view operations.
pub fn supports_byte_views() -> bool { false }
