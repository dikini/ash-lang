// Artifact-local safe transport. Only the generated root can name these types.
// CP24 policy and pre-funded observation remain in the evaluator; this module
// neither authenticates a context nor admits a source operation.
use checked_owner_leaf as leaf;
pub(crate) use leaf::{ViewDescriptor, Refusal, RawScalar, DisposalReturned};

pub(crate) struct PreparedAcquire<'cell> {
    destination: &'cell mut OwnerCell,
    native: leaf::PreparedAcquire,
}
pub(crate) enum AcquirePreparationFailure {
    DestinationOccupied,
    Leaf(Refusal),
}
pub(crate) struct AcquireReturned {
    nonnull: bool,
}
impl AcquireReturned {
    pub(crate) fn nonnull(&self) -> bool { self.nonnull }
}
impl PreparedAcquire<'_> {
    pub(crate) fn invoke(self) -> AcquireReturned {
        let Self { destination, native } = self;
        destination.owner = leaf::invoke_acquire(native); // FIRST root action after native return.
        AcquireReturned { nonnull: destination.owner.is_some() }
    }
}


pub(crate) struct OwnerCell {
    owner: Option<leaf::Owner>,
}
pub(crate) enum AcquireObservation {
    DestinationOccupied,
    NotEntered(leaf::Refusal),
    Returned { nonnull: bool },
}
pub(crate) enum FreeObservation {
    NoOwner,
    Returned(DisposalReturned),
    Retained(OwnerCell, DisposalReturned),
}
impl std::fmt::Debug for OwnerCell {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.debug_struct("OwnerCell").field("occupied", &self.owner.is_some()).finish_non_exhaustive()
    }
}
impl OwnerCell {
    pub(crate) fn is_occupied(&self) -> bool { self.owner.is_some() }
    pub(crate) fn prepare_acquire(&mut self, capacity: usize, initialized: usize) -> Result<PreparedAcquire<'_>, AcquirePreparationFailure> {
        if self.owner.is_some() { return Err(AcquirePreparationFailure::DestinationOccupied); }
        let native = leaf::prepare_acquire(capacity, initialized).map_err(AcquirePreparationFailure::Leaf)?;
        Ok(PreparedAcquire { destination: self, native })
    }

    /// Construct before native entry and reserve its enclosing storage then.
    pub(crate) fn vacant() -> Self { Self { owner: None } }
    /// The caller must already own the pending-call and mandatory report slots.
    pub(crate) fn acquire(&mut self, capacity: usize, initialized: usize) -> AcquireObservation {
        match self.prepare_acquire(capacity, initialized) {
            Ok(prepared) => AcquireObservation::Returned { nonnull: prepared.invoke().nonnull() },
            Err(AcquirePreparationFailure::DestinationOccupied) => AcquireObservation::DestinationOccupied,
            Err(AcquirePreparationFailure::Leaf(reason)) => AcquireObservation::NotEntered(reason),
        }
    }
    pub(crate) fn query(&self, key: usize) -> Result<Option<leaf::ViewDescriptor>, leaf::Refusal> {
        let owner = self.owner.as_ref().ok_or(leaf::Refusal::Owner)?;
        leaf::query(owner, key)
    }
    pub(crate) fn length(&self, key: usize) -> Result<usize, leaf::Refusal> {
        if !leaf::supports_byte_views() { return Err(leaf::Refusal::Profile); }
        let owner = self.owner.as_ref().ok_or(leaf::Refusal::Owner)?;
        Ok(leaf::length(owner, key))
    }
    pub(crate) fn copy(&self, descriptor: &leaf::ViewDescriptor, offset: usize, destination: &mut [u8]) -> Result<(), leaf::Refusal> {
        let owner = self.owner.as_ref().ok_or(leaf::Refusal::Owner)?;
        let view = leaf::borrow_view(owner, descriptor)?;
        leaf::copy(&view, offset, destination)
    }
    /// Consumes this exact transport cell. There is no foreign Drop or retry.
    /// The caller records the returned fact before optional source output.
    pub(crate) fn free(mut self) -> FreeObservation {
        let Ok(prepared) = leaf::prepare_teardown(&mut self.owner) else { return FreeObservation::NoOwner; };
        let returned = prepared.invoke();
        if returned.disposition() == Some(true) { FreeObservation::Returned(returned) }
        else { FreeObservation::Retained(self, returned) }
    }
    pub(crate) fn prepare_output_acquire<'s, 'i>(&'s mut self, input: &'i [u8])
        -> Result<leaf::PreparedOutputAcquire<'s, 'i>, Refusal> {
        leaf::prepare_output_acquire(&mut self.owner, input)
    }
    pub(crate) fn prepare_teardown(&mut self) -> Result<leaf::PreparedTeardown<'_>, Refusal> {
        leaf::prepare_teardown(&mut self.owner)
    }
}

// image-library, library-module, library-ordinal, image-symbol, symbol-index, operation-module, effect, local
pub(crate) const CHECKED_PROFILE: u8 = 1;
pub(crate) const CHECKED_ROLES: [[u32; 8]; 2] = [
[0, 1, 0, 0, 0, 1, 0, 0],
[0, 1, 0, 1, 1, 1, 1, 0],
];
