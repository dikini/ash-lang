import gdb,json
active=False
sequence=0
restore_number=0
MAX=400

def emit(row):
 global sequence
 sequence+=1
 if sequence<=MAX:print('EXACT_LEDGER '+json.dumps(dict(sequence=sequence,**row),sort_keys=True))
 elif sequence==MAX+1:print('EXACT_LEDGER '+json.dumps({'overflow':True}))

def meter(ptr):
 obj=ptr.dereference();return {'pointer':int(ptr),'used':int(obj['used']),'limit':int(obj['limit'])}

class End(gdb.FinishBreakpoint):
 def __init__(self,frame,ptr,row,is_restore):
  super().__init__(frame,internal=True);self.ptr,self.row,self.is_restore=ptr,row,is_restore
 def stop(self):
  global active
  try:
   after=meter(self.ptr);emit(dict(event='exit',after=after,cost=after['used']-self.row['before']['used'],**self.row))
  except Exception as e:emit({'error':str(e),'label':self.row['label']})
  if self.is_restore:active=False
  return False

class Start(gdb.Breakpoint):
 def __init__(self,name,label,expression,is_restore=False):
  super().__init__(name,internal=True);self.label,self.meter_expr,self.is_restore=label,expression,is_restore
 def stop(self):
  global active,restore_number
  if self.is_restore:active=True;restore_number+=1
  if not active:return False
  try:
   frame=gdb.newest_frame();ptr=gdb.parse_and_eval(self.meter_expr)
   row={'label':self.label,'restore':restore_number,'before':meter(ptr),'caller':frame.older().name() if frame.older() else None}
   emit(dict(event='entry',**row));End(frame,ptr,row,self.is_restore)
  except Exception as e:emit({'error':str(e),'label':self.label})
  return False

class FailedCharge(gdb.Breakpoint):
 def stop(self):
  if not active:return False
  try:
   ptr=gdb.parse_and_eval('self');cells=int(gdb.parse_and_eval('cells'));state=meter(ptr)
   if cells<=state['limit']-state['used']:raise RuntimeError('line breakpoint did not select refused charge')
   frames=[];f=gdb.newest_frame()
   for _ in range(12):
    if f is None:break
    frames.append((f.name() or '')[:400]);f=f.older()
   emit({'event':'failed_charge','restore':restore_number,'meter':state,'requested':cells,'stack':frames})
  except Exception as e:emit({'error':str(e),'label':'failed_charge'})
  return False

Start('ash::build::image::PureImage::restore_effect','restore','work',True)
Start('ash::core::validate::validate_effect_modules_with_work','independent_core','work')
FailedCharge('src/types.rs:80',internal=True)
